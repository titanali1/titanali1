<?php
/**
 * titanali — بک‌اند PHP 7.0+؛ نیازمند بستهٔ کامل، بدون دیتابیس و Composer
 * -----------------------------------------------------------------------------
 * چه کاری می‌کند؟
 *   • محتوای سایت (طرح‌ها، پروفایل، کاربران،…) را روی سرور نگه می‌دارد تا
 *     هر دستگاهی همان نسخه را ببیند و ادمین از موبایل هم بتواند ویرایش کند.
 *   • صندوق مشترک (inbox): پیام‌های بازدیدکننده‌ها در سرور می‌نشیند، ادمین
 *     پاسخ می‌دهد و پاسخ در گفتگوی همان بازدیدکننده ظاهر می‌شود.
 *   • شمارنده‌های لایک/دانلود/بازدید و کامنت‌ها بین همه مشترک است.
 *   • ورود ادمین سمت سرور (bcrypt + توکن) — دیگر رمز در سورس نیست.
 *
 * نصب: همین فایل را کنار index.html در public_html بگذارید. پوشهٔ
 *   titanali-data/ خودکار ساخته و با .htaccess بسته می‌شود.
 *   سپس با کلید خصوصی File Manager در titanali-install.php مدیر بسازید.
 *
 * فایل‌ها همه JSON تخت‌اند و با flock + نوشتن اتمی (tmp + rename) ذخیره می‌شوند.
 * بدون API، پیش‌نویس محلی به‌معنای ذخیره یا انتشار روی هاست نیست.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
require_once __DIR__.'/titanali-bootstrap.php';
ta_require_secure_transport();

define('TA_VER', '1.0.34');
define('TA_TOKEN_TTL', 43200);          /* ۱۲ ساعت نشست ادمین */

/* =====================================================================
 *  تنظیمات و مسیرها
 * ===================================================================== */
function ta_cfg()
{
    static $cached=null;
    if($cached!==null)return $cached;
    $base=__DIR__;
    $c=array('dataDir'=>$base.'/titanali-data','maxJson'=>6*1024*1024,
        'maxArchive'=>64*1024*1024,'maxFile'=>6*1024*1024,'origin'=>'',
        'appOrigins'=>array('https://app.titanali1.ir'),'proxyTrusted'=>false,
        'publishFile'=>'titanali-content.json','publishMax'=>2000000);
    if(is_file($base.'/titanali-config.php')){
        $custom=include $base.'/titanali-config.php';
        if(!is_array($custom))throw new Exception('فایل تنظیمات باید یک آرایهٔ PHP برگرداند.');
        $c=array_merge($c,$custom);
    }
    if($c['origin']===''&&isset($c['allowOrigin']))$c['origin']=(string)$c['allowOrigin'];
    $c['dataDir']=ta_private_path($c['dataDir'],$base);
    if(!is_dir($c['dataDir']))@mkdir($c['dataDir'],0775,true);
    ta_harden($c['dataDir']);
    $cached=$c;
    return $cached;
}

/* Never harden the public root. Upgrade only our exact legacy guard, not a
   custom administrator policy. No chmod or public-file rewrites occur here. */
function ta_harden($dir)
{
    if(!is_dir($dir))return;
    ta_private_path($dir,__DIR__);
    $deny=ta_private_guard();
    $legacy="Require all denied\nDeny from all\nOptions -Indexes\n";
    foreach(array($dir,$dir.'/uploads') as $folder){
        if(!is_dir($folder))@mkdir($folder,0775,true);
        if(!is_dir($folder))continue;
        $guard=$folder.'/.htaccess';
        $old=is_file($guard)?@file_get_contents($guard):null;
        $ours=$old===$legacy||$old===$legacy."<FilesMatch \"\\.(php|phtml|phar|pl|py|cgi)$\">\n  Require all denied\n</FilesMatch>\n";
        if($old===null||$ours)ta_write_private_guard($guard,$deny);
    }
    if(!is_file($dir.'/index.php'))@file_put_contents($dir.'/index.php',"<?php /* Private data; no output. */\n");
    if(!is_dir($dir.'/backups'))@mkdir($dir.'/backups',0775,true);
}

function ta_file($name)
{
    $c = ta_cfg();
    return $c['dataDir'] . '/' . $name;
}

/* =====================================================================
 *  خواندن/نوشتن JSON (قفل‌شده و اتمی)
 * ===================================================================== */
function ta_read($name, $def)
{
    $p = ta_file($name);
    if (!is_file($p)) return $def;
    $fp = @fopen($p, 'rb');
    if (!$fp) return $def;
    @flock($fp, LOCK_SH);
    $s = '';
    while (!feof($fp)) { $chunk = fread($fp, 262144); if ($chunk === false) break; $s .= $chunk; }
    @flock($fp, LOCK_UN);
    fclose($fp);
    if ($s === '') return $def;
    $j = json_decode($s, true);
    if ($name === "content.json" && is_array($j)) { unset($j["ig"], $j["feed"]); }
    return is_array($j) ? $j : $def;
}

function ta_put($name, $data)
{
    if ($name === "content.json" && is_array($data)) { unset($data["ig"], $data["feed"]); $data=ta_design_ids($data); }
    $p = ta_file($name);
    $tmp = $p . '.' . getmypid() . '.tmp';
    $s = json_encode($data, JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES);
    if ($s === false) return false;
    if (@file_put_contents($tmp, $s, LOCK_EX) === false) return false;
    @chmod($tmp, 0644);
    if (!@rename($tmp, $p)) { @unlink($tmp); return false; }
    clearstatcache(true, $p);
    return true;
}

function ta_lock()
{
    $c = ta_cfg();
    $fp = @fopen($c['dataDir'] . '/_lock', 'cb');
    if (!$fp) ta_out(500, array('ok' => false, 'error' => 'پوشهٔ داده‌ها نوشتنی نیست: ' . $c['dataDir']));
    @flock($fp, LOCK_EX);
    return $fp;
}
function ta_unlock($fp)
{
    if ($fp) { @flock($fp, LOCK_UN); fclose($fp); }
}

/* =====================================================================
 *  لایهٔ HTTP
 * ===================================================================== */
function ta_out($code, $arr)
{
    if (!headers_sent()) {
        @http_response_code($code);
        @header('Content-Type: application/json; charset=utf-8');
        @header('Cache-Control: no-store, max-age=0');
        @header('X-Content-Type-Options: nosniff');
        @header('Referrer-Policy: no-referrer');
        $c = ta_cfg();
        if ($c['origin'] !== '') {
            @header('Access-Control-Allow-Origin: ' . $c['origin']);
            @header('Vary: Origin');
        }
    }
    echo json_encode($arr, JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES);
    exit;
}

/* CORS برای پوستهٔ اندروید / هر مبدأ دلخواهِ مجاز در config */
function ta_origin_ok()
{
    $o = isset($_SERVER['HTTP_ORIGIN']) ? trim((string) $_SERVER['HTTP_ORIGIN']) : '';
    if ($o === '') return '';
    $c = ta_cfg();
    if ($c['origin'] === '*') return '';                 /* حالت «همه‌چیز مجاز» را ta_out مدیریت می‌کند */
    $list = array();
    if ($c['origin'] !== '') $list[] = (string) $c['origin'];
    if (!empty($c['appOrigins']) && is_array($c['appOrigins'])) $list = array_merge($list, $c['appOrigins']);
    $o = rtrim($o, '/');
    foreach ($list as $x) {
        $x = rtrim(trim((string) $x), '/');
        if ($x !== '' && strcasecmp($x, $o) === 0) return $x;
    }
    return '';
}
function ta_cors()
{
    if (headers_sent()) return;
    $o = ta_origin_ok();
    if ($o === '') return;
    @header('Access-Control-Allow-Origin: ' . $o);
    @header('Vary: Origin');
    @header('Access-Control-Allow-Headers: Content-Type, X-TA-Token, X-TA-Member-Phone, X-TA-Member-Token, If-None-Match');
    @header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    @header('Access-Control-Max-Age: 600');
    @header('Access-Control-Expose-Headers: ETag');
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS')
        { @http_response_code(204); exit; }
}

function ta_ip()
{
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0';
    $c = ta_cfg();
    if ($c['proxyTrusted'] && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $p = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $x = trim($p[0]);
        if ($x !== '') $ip = $x;
    }
    return substr($ip, 0, 45);
}

/* No mutation occurs in this decoder. Only these explicit failures may be
   retried by the client using a different body encoding. Never echo payloads. */
function ta_ini_bytes($value) {
    $v=trim((string)$value);
    if(!preg_match('/^([0-9]+)\s*([KMG]?)$/i',$v,$m))return 0;
    $n=(float)$m[1];$u=isset($m[2])?strtoupper($m[2]):'';
    return (int)min(PHP_INT_MAX,$n*($u==='G'?1073741824:($u==='M'?1048576:($u==='K'?1024:1))));
}
function ta_media_chunk_size() {
    $max=ta_cfg()['maxJson'];$post=ta_ini_bytes(ini_get('post_max_size'));
    if($post>0)$max=min($max,$post);
    /* Worst-case URL-encoded base64 costs four bytes per source byte.
       Leave space for JSON/job metadata and form overhead. Keep legacy 12KiB
       chunks accepted, but negotiate smaller parts for both old/new clients. */
    return max(1,min(4096,(int)floor(max(0,$max-1024)/4)));
}
function ta_decode_body($post,$raw,$length,$max,$postMax) {
    $fail=function($status,$code,$message){return array('ok'=>false,'status'=>$status,'code'=>$code,'error'=>$message);};
    if($length>$max||strlen($raw)>$max)return $fail(413,'body_too_large','بدنهٔ درخواست از سقف مجاز برنامه بزرگ‌تر است؛ پیش‌نویس محفوظ است.');
    if($postMax>0&&max($length,strlen($raw))>$postMax)return $fail(413,'post_limit','اندازهٔ درخواست از post_max_size هاست بیشتر است؛ پیش‌نویس محفوظ است.');
    if(isset($post['payload'])) {
        if(!is_string($post['payload']))return $fail(400,'body_invalid','فیلد درخواست باید متن JSON باشد.');
        $s=$post['payload'];
    } else {
        $s=ltrim($raw);
        /* php://input can still contain valid form bytes when PHP did not
           populate $_POST (disabled POST reader or missing/misrouted MIME).
           Detect only our exact payload envelope; do not trust Content-Type. */
        if($s!==''&&$s[0]!=='{'&&$s[0]!=='['&&preg_match('/(?:^|&)payload=/',$s)) {
            $form=array();parse_str($s,$form);
            if(!isset($form['payload'])||!is_string($form['payload']))return $fail(400,'body_invalid','فیلد درخواست معتبر نیست.');
            $s=$form['payload'];
        } elseif($s!==''&&$s[0]!=='{'&&$s[0]!=='[') {
            return $fail(400,'body_unavailable','قالب بدنه در PHP خوانده نشد؛ پیش‌نویس محفوظ است.');
        }
    }
    if($s==='')return $fail(400,'body_missing','بدنهٔ این درخواست در PHP خالی است؛ این خطا مربوط به فرمت عکس نیست. پیش‌نویس محفوظ است.');
    if(strlen($s)>$max)return $fail(413,'body_too_large','بدنهٔ درخواست از سقف مجاز برنامه بزرگ‌تر است.');
    $j=json_decode($s,true);
    if(!is_array($j))return $fail(400,'body_invalid','JSON درخواست نامعتبر است؛ پیش‌نویس محفوظ است.');
    return array('ok'=>true,'body'=>$j);
}
function ta_body() {
    $c=ta_cfg();$len=isset($_SERVER['CONTENT_LENGTH'])?(int)$_SERVER['CONTENT_LENGTH']:0;
    /* Bound raw reads even when a proxy omitted Content-Length. Normal parsed
       forms need no second copy of their potentially large encoded envelope. */
    $raw='';$postMax=ta_ini_bytes(ini_get('post_max_size'));$readMax=$postMax>0?min($c['maxJson'],$postMax):$c['maxJson'];
    if(!isset($_POST['payload'])&&$len<=$readMax) {
        $raw=file_get_contents('php://input',false,null,0,$readMax+1);
        if($raw===false)$raw='';
    }
    $r=ta_decode_body($_POST,$raw,$len,$c['maxJson'],$postMax);
    if(!$r['ok'])ta_out($r['status'],array('ok'=>false,'error'=>$r['error'],'code'=>$r['code'],'bodyRejected'=>true));
    return $r['body'];
}

function ta_str($v, $max, $keep = false)
{
    if (!is_scalar($v)) return '';
    $s = (string) $v;
    if (!$keep) {
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $s);   /* کنترل‌کاراکترها */
        $s = strip_tags($s);
    }
    $s = trim($s);
    if (function_exists('mb_substr')) return mb_substr($s, 0, $max, 'UTF-8');
    if(preg_match('/^.{0,'.(int)$max.'}/us',$s,$chars))return $chars[0];
    return substr($s, 0, $max);
}

function ta_arr($v) { return is_array($v) ? $v : array(); }

/* محدودیت نرخ ساده، فایل‌محور */
function ta_throttle($key, $max, $win)
{
    $f = ta_read('rl.json', array());
    $now = time();
    $list = isset($f[$key]) && is_array($f[$key]) ? $f[$key] : array();
    $keep = array();
    foreach ($list as $t) { if ($t > $now - $win) $keep[] = $t; }
    if (count($keep) >= $max) {
        $f[$key] = $keep; ta_put('rl.json', $f);
        return false;
    }
    $keep[] = $now;
    $f[$key] = $keep;
    if (count($f) > 400) $f = array_slice($f, -300, null, true);   /* رشد بی‌حد نکند */
    ta_put('rl.json', $f);
    return true;
}

/* =====================================================================
 *  احراز هویت
 * ===================================================================== */
function ta_conf()  { return ta_read('config.json', array()); }

function ta_secret()
{
    $c = ta_conf();
    if (isset($c['secret']) && strlen($c['secret']) >= 32) return $c['secret'];
    $s = bin2hex(random_bytes(24));
    $c['secret'] = $s;
    ta_put('config.json', $c);
    return $s;
}

function ta_users()
{
    $c = ta_conf();
    return isset($c['users']) && is_array($c['users']) ? array_values($c['users']) : array();
}
function ta_installed() { return count(ta_users()) > 0; }

function ta_hash_pw($pw)
{
    if (defined('PASSWORD_DEFAULT')) return password_hash($pw, PASSWORD_DEFAULT);
    return 'sha256$' . hash('sha256', $pw . 'titanali-salt');   /* فقط برای PHP های خیلی قدیمی */
}
function ta_check_pw($pw, $hash)
{
    if (strpos((string) $hash, 'sha256$') === 0) {
        return hash_equals($hash, 'sha256$' . hash('sha256', $pw . 'titanali-salt'));
    }
    return password_verify($pw, (string) $hash);
}

function ta_issue($u)
{
    $t = bin2hex(random_bytes(20));
    $tk = ta_read('tokens.json', array());
    $tk[$u] = array('h' => hash('sha256', $t), 'exp' => time() + TA_TOKEN_TTL);
    ta_put('tokens.json', $tk);
    return $t;
}

function ta_whoami()
{
    $h = '';
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) $h = $_SERVER['HTTP_AUTHORIZATION'];
    elseif (isset($_SERVER['HTTP_X_TA_TOKEN'])) $h = 'Bearer ' . $_SERVER['HTTP_X_TA_TOKEN'];
    elseif (!empty($_GET['t'])) $h = 'Bearer ' . $_GET['t'];
    $t = trim(preg_replace('/^Bearer\s+/i', '', $h));
    if ($t === '') return null;
    $tk = ta_read('tokens.json', array());
    $now = time();
    $dirty = false;
    $hit = null;
    foreach ($tk as $u => $r) {
        if (!is_array($r) || !isset($r['h'])) { unset($tk[$u]); $dirty = true; continue; }
        if ($r['exp'] < $now) { unset($tk[$u]); $dirty = true; continue; }
        if (hash_equals($r['h'], hash('sha256', $t))) { $hit = $u; break; }
    }
    if ($dirty) ta_put('tokens.json', $tk);
    if ($hit === null) return null;
    foreach (ta_users() as $a) { if (isset($a['u']) && $a['u'] === $hit) return array('u' => $hit, 'name' => isset($a['name']) ? $a['name'] : $hit); }
    return array('u' => $hit, 'name' => $hit);
}

function ta_need_admin()
{
    if (!ta_installed()) ta_out(423, array('ok' => false, 'error' => 'ابتدا ادمین را در تب «همگام‌سازی» بسازید (نصب روی سرور)'));
    $w = ta_whoami();
    if (!$w) ta_out(401, array('ok' => false, 'error' => 'نشست تمام شده — دوباره وارد شوید'));
    return $w;
}

/* =====================================================================
 *  محتوا / شمارنده‌ها / کامنت‌ها
 * ===================================================================== */
function ta_meta() { return ta_read('meta.json', array()); }
function ta_rev()
{
    $m = ta_meta();
    return isset($m['rev']) ? (int) $m['rev'] : 0;
}
function ta_bump()
{
    $m = ta_meta();
    $m['rev'] = (int) (isset($m['rev']) ? $m['rev'] : 0) + 1;
    $m['updated'] = time();
    ta_put('meta.json', $m);
    return $m['rev'];
}

/* =====================================================================
 *  انتشار روی هاست: فایل ایستای کنار index.html + خلاصهٔ وضعیت
 * ===================================================================== */
function ta_hash_of($v)
{
    return substr(md5(json_encode(ta_arr($v), JSON_UNESCAPED_UNICODE)), 0, 10);
}

function ta_sections_of($d)
{
    $d = ta_design_ids(ta_arr($d));
    $out = array();
    foreach (array('profile', 'tags', 'stats', 'cats', 'gallery', 'hobbies', 'quick', 'copy', 'contacts', 'settings') as $k) {
        $out[$k] = isset($d[$k]) ? ta_hash_of($d[$k]) : '';
    }
    return $out;
}

function ta_publish_path()
{
    $c = ta_cfg();
    $rel = isset($c['publishFile']) ? (string) $c['publishFile'] : '';
    if ($rel === '') return '';
    if ($rel[0] === '/') return $rel;
    return dirname(__FILE__) . '/' . $rel;
}

/* نوشتن snapshot ایستا؛ نتیجه: at/by/rev/file/bytes/changed/error */
function ta_bake($data, $rev, $by)
{
    $c = ta_cfg();
    $res = array('at' => time(), 'by' => $by, 'rev' => (int) $rev, 'file' => '', 'bytes' => 0, 'changed' => false);
    $abs = ta_publish_path();
    if ($abs === '') { $res['error'] = 'off'; return $res; }
    $raw = json_encode(array('ok' => true, 'app' => 'titanali', 'rev' => (int) $rev, 'at' => time(),
                             'data' => ta_public_content($data), 'social' => ta_social_shape()),
                       JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES);
    if ($raw === false) { $res['error'] = 'encode'; return $res; }
    $max = (int) (isset($c['publishMax']) ? $c['publishMax'] : 0);
    if ($max > 0 && strlen($raw) > $max) { $res['error'] = 'too-big'; return $res; }
    $old = @file_get_contents($abs);
    $tmp = $abs . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, $raw, LOCK_EX) === false) { $res['error'] = 'nowrite'; return $res; }
    @chmod($tmp, 0644);
    if (!@rename($tmp, $abs)) { @unlink($tmp); $res['error'] = 'nowrite'; return $res; }
    clearstatcache(true, $abs);
    $res['file'] = basename($abs);
    $res['bytes'] = strlen($raw);
    $res['changed'] = ($old === false) || ($old !== $raw);
    try { ta_push_published(ta_public_content($data), $rev); }
    catch (Throwable $e) { $res['notificationsError'] = true; error_log('Titanali push: publication queue unavailable'); }
    return $res;
}

function ta_baked_info()
{
    $abs = ta_publish_path();
    $out = array('file' => $abs === '' ? '' : basename($abs), 'exists' => false, 'bytes' => 0, 'mtime' => 0, 'rev' => 0);
    if ($abs === '' || !is_file($abs)) return $out;
    $out['exists'] = true;
    $out['bytes'] = (int) @filesize($abs);
    $out['mtime'] = (int) @filemtime($abs);
    $head = @file_get_contents($abs, false, null, 0, 2048);
    if (is_string($head) && preg_match('/"rev"\s*:\s*([0-9]+)/', $head, $mm)) $out['rev'] = (int) $mm[1];
    return $out;
}

function ta_note_publish($pub, $by, $rev)
{
    $m = ta_meta();
    $m['publish'] = array('at' => time(), 'by' => $by, 'rev' => (int) $rev,
                          'bytes' => isset($pub['bytes']) ? (int) $pub['bytes'] : 0,
                          'file'  => isset($pub['file']) ? (string) $pub['file'] : '',
                          'error' => isset($pub['error']) ? (string) $pub['error'] : '');
    ta_put('meta.json', $m);
    $lg = ta_read('log.json', array());
    array_push($lg, array('ts' => time(), 'u' => $by, 'what' => 'publish', 'rev' => (int) $rev));
    ta_put('log.json', array_slice($lg, -200));
}

function ta_public_content($data)
{
    if (!is_array($data)) return $data;
    $data=ta_design_ids($data);
    unset($data['admins'], $data['messages'], $data['sid']);
    return $data;
}

function ta_payload($withSocial)
{
    $content = ta_read('content.json', null);
    $m = ta_meta();
    $out = array('ok' => true, 'rev' => ta_rev(), 'installed' => ta_installed());
    $out['data'] = is_array($content) ? ta_public_content($content) : null;
    $out['updated'] = isset($m['updated']) ? (int) $m['updated'] : 0;
    if ($withSocial) $out['social'] = ta_social_shape();
    return $out;
}

function ta_social_shape()
{
    $s = ta_social();$s['comments']=ta_comments_all();
    if(isset($s['comments']))foreach($s['comments'] as $i=>$list)if(is_array($list))foreach($list as $n=>$row){unset($s['comments'][$i][$n]['_owner'],$s['comments'][$i][$n]['_source']);}
    return array(
        'likes'    => ta_arr($s['likes']),
        'dl'       => ta_arr($s['dl']),
        'views'    => isset($s['views']) ? (int) $s['views'] : 0,
        'comments' => ta_arr($s['comments']),
    );
}


function ta_social() { return ta_read('social.json', array('likes' => array(), 'dl' => array(), 'views' => 0, 'comments' => array())); }

/* Unified persisted comments: social plus older gallery-embedded comments. */
function ta_comment_id($c,$i,$n) {
    if(isset($c['id'])&&is_scalar($c['id'])&&preg_match('/^[A-Za-z0-9_-]{1,80}$/',(string)$c['id']))return (string)$c['id'];
    return 'legacy-'.substr(hash('sha256',$i.'|'.$n.'|'.json_encode(array(isset($c['n'])?$c['n']:'',isset($c['txt'])?$c['txt']:'',isset($c['ts'])?$c['ts']:0))),0,24);
}
function ta_comments_all() {
    $out=array();$content=ta_read('content.json',array());$social=ta_social();
    foreach(isset($content['gallery'])?$content['gallery']:array() as $i=>$g)foreach(isset($g['comments'])&&is_array($g['comments'])?$g['comments']:array() as $n=>$c) {
        if(!is_array($c))continue;$c['id']=ta_comment_id($c,$i,$n);$c['_source']='legacy';$out[$i][$c['id']]=$c;
    }
    foreach(isset($social['comments'])?$social['comments']:array() as $i=>$rows)if(is_array($rows))foreach($rows as $n=>$c) {
        if(!is_array($c))continue;$c['id']=ta_comment_id($c,$i,$n);$c['_source']='social';$out[$i][$c['id']]=$c;
    }
    foreach($out as $i=>$rows)$out[$i]=array_values($rows);
    return $out;
}
function ta_comment_change($i,$id,$txt,$remove,$by) {
    $social=ta_social();$content=ta_read('content.json',array());$found=false;$legacy=false;
    foreach(array('legacy','social') as $source) {
        $rows=$source==='legacy'?(isset($content['gallery'][$i]['comments'])?$content['gallery'][$i]['comments']:array()):(isset($social['comments'][$i])?$social['comments'][$i]:array());
        if(!is_array($rows))continue;
        foreach($rows as $n=>$row) {
            if(!is_array($row))continue;$rows[$n]['id']=ta_comment_id($row,$i,$n);if($rows[$n]['id']!==$id)continue;
            $found=true;if($source==='legacy')$legacy=true;
            if($remove){unset($rows[$n]);continue;}
            $rows[$n]['id']=$id;
            if($txt==='')unset($rows[$n]['r']);else $rows[$n]['r']=array('txt'=>$txt,'ts'=>time()*1000,'by'=>$by);
        }
        // Keep legacy numeric positions stable for generated IDs after deletion.
        if($source==='legacy'&&$legacy)$content['gallery'][$i]['comments']=array_values($rows);
        if($source==='social'&&$found)$social['comments'][$i]=$rows;
    }
    if(!$found)return false;
    if(!ta_put('social.json',$social))throw new Exception('ذخیرهٔ کامنت ممکن نشد.');
    if($legacy){if(!ta_put('content.json',$content))throw new Exception('ذخیرهٔ کامنت قدیمی ممکن نشد.');$proof=ta_bake($content,ta_rev(),$by);if(isset($proof['error']))throw new Exception('پاسخ ذخیره شد ولی نسخهٔ عمومی تأیید نشد.');}
    return true;
}

/* =====================================================================
 *  پیام‌ها
 * ===================================================================== */
function ta_inbox_all() { return ta_arr(ta_read('inbox.json', array())); }

function ta_sane_sid($s)
{
    $s = preg_replace('/[^A-Za-z0-9_-]/', '', (string) $s);
    return substr($s, 0, 24);
}

/* =====================================================================
 *  پیوست‌ها
 * ===================================================================== */
function ta_types()
{
    return array(
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif',
        'image/avif' => 'avif', 'image/svg+xml' => 'svg', 'application/pdf' => 'pdf',
        'video/mp4' => 'mp4', 'video/webm' => 'webm', 'audio/mpeg' => 'mp3', 'text/plain' => 'txt',
        'application/zip' => 'zip', 'application/octet-stream' => 'bin',
    );
}

function ta_store_file($name, $type, $b64)
{
    $c = ta_cfg();
    $raw = base64_decode(preg_replace('/\s+/', '', (string) $b64), true);
    if ($raw === false || $raw === '') return array('ok' => false, 'error' => 'پیوست رمزگشایی نشد');
    if (strlen($raw) > $c['maxFile']) return array('ok' => false, 'error' => 'حجم پیوست بیشتر از ' . round($c['maxFile'] / 1048576, 1) . ' مگابایت است');
    $types = ta_types();
    $mime = isset($types[$type]) ? $type : 'application/octet-stream';
    $ext = $types[$mime];
    $id = substr(hash('sha256', $raw . microtime() . ta_secret()), 0, 24);
    $fn = $id . '.' . $ext;
    $dir = $c['dataDir'] . '/uploads';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    if (@file_put_contents($dir . '/' . $fn, $raw) === false) return array('ok' => false, 'error' => 'ذخیرهٔ فایل روی سرور نشد (مجوز پوشهٔ titanali-data)');
    $safe = preg_replace('/[^\w.\- ]+/u', '', (string) $name);
    if ($safe === '') $safe = 'file.' . $ext;
    return array('ok' => true, 'id' => $fn, 'url' => 'api.php?action=file&f=' . rawurlencode($fn),
                 'name' => substr($safe, 0, 80), 'type' => $mime, 'size' => strlen($raw));
}

/* =====================================================================
 *  کاربر (ثبت‌نام با شماره تلفن) + پنل پیامک
 * ===================================================================== */
function ta_members() { return ta_arr(ta_read('users.json', array('list' => array()))); }

function ta_member_list()
{
    $m = ta_members();
    return isset($m['list']) && is_array($m['list']) ? $m['list'] : array();
}

function ta_norm_phone($p)
{
    $p = strtr((string) $p, array(
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9'));
    $p = preg_replace('/[^0-9+]/', '', $p);
    if (strpos($p, '98') === 0) $p = '0' . substr($p, 2);
    if (strpos($p, '+98') === 0) $p = '0' . substr($p, 3);
    if (strlen($p) === 9 && $p[0] === '9') $p = '0' . $p;
    return $p;
}

function ta_ok_phone($p) { return (bool) preg_match('/^09\d{9}$/', $p); }

function ta_sms_cfg()
{
    $d = array('prov' => 'none', 'key' => '', 'user' => '', 'from' => '', 'tpl' => '', 'debug' => 0);
    $c = ta_read('sms.json', $d);
    if (!is_array($c)) $c = $d;
    foreach ($d as $k => $v) { if (!isset($c[$k])) $c[$k] = $v; }
    return $c;
}

function ta_sms_provs()
{
    return array(
        'none'        => array('نام' => 'بدون پنل (خاموش)', 'فیلد' => array()),
        'demo'        => array('نام' => 'آزمایشی — بدون ارسال واقعی و بدون فعال‌سازی ورود/حذف', 'فیلد' => array()),
        'kavenegar'   => array('نام' => 'کاوه‌نگار (Kavenegar)', 'فیلد' => array('key' => 'Token / API Key', 'from' => 'شمارهٔ فرستنده (Line)'), 'url' => 'https://api.kavenegar.com/v1/{key}/sms/send.json'),
        'melipayamak' => array('نام' => 'ملی‌پیامک', 'فیلد' => array('user' => 'نام کاربری', 'key' => 'رمز عبور', 'from' => 'شمارهٔ فرستنده'), 'url' => 'https://api.melipayamak.com/Send/Sms/{user}/{key}/{to}/{text}'),
        'payamresan'  => array('نام' => 'پیام‌رسان', 'فیلد' => array('user' => 'نام کاربری', 'key' => 'رمز عبور', 'from' => 'شمارهٔ خط'), 'url' => 'https://api.payamresan.com/v1/send'),
        'sms_ir'      => array('نام' => 'اس‌ام‌اس دات آی‌آر (sms.ir)', 'فیلد' => array('key' => 'X-API-KEY', 'user' => 'User API Key', 'from' => 'شمارهٔ خط'), 'url' => 'https://api.sms.ir/v1/send/like'),
        'farazsms'    => array('نام' => 'فراز اس‌ام‌اس', 'فیلد' => array('user' => 'نام کاربری', 'key' => 'رمز عبور', 'from' => 'خط سرویس‌دهنده'), 'url' => 'https://sms.farazsms.com/'),
        'custom'      => array('نام' => 'دلخواه — آدرس خودتان', 'فیلد' => array('tpl' => 'الگوی آدرس: {key} {user} {from} {to} {text} {code}', 'key' => 'کلید', 'from' => 'خط'), 'url' => ''),
    );
}

/* یک درخواست HTTP ساده؛ curl اگر بود همان، وگرنه fopen */
function ta_http($url, $post = null, $hdr = array())
{
    $out = array('ok' => false, 'code' => 0, 'body' => '', 'err' => '');
    if (strtolower((string)parse_url($url,PHP_URL_SCHEME))!=='https') { $out['err']='پنل پیامک باید HTTPS معتبر داشته باشد';return $out; }
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $opt = array(CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 8,
                     CURLOPT_FOLLOWLOCATION => false, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2);
        if ($post !== null) { $opt[CURLOPT_POST] = 1; $opt[CURLOPT_POSTFIELDS] = $post; }
        if ($hdr) $opt[CURLOPT_HTTPHEADER] = $hdr;
        curl_setopt_array($ch, $opt);
        $b = curl_exec($ch);
        $out['code'] = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $out['err'] = $b === false ? (string) curl_error($ch) : '';
        $out['body'] = is_string($b) ? substr($b, 0, 4000) : '';
        curl_close($ch);
        $out['ok'] = $out['code'] >= 200 && $out['code'] < 300;
        return $out;
    }
    if (!ini_get('allow_url_fopen')) { $out['err'] = 'curl و allow_url_fopen هیچ‌کدام نیست'; return $out; }
    $ctx = stream_context_create(array('http' => array(
        'method' => $post === null ? 'GET' : 'POST', 'header' => implode("\r\n", $hdr),
        'content' => $post === null ? '' : $post, 'timeout' => 12, 'follow_location'=>0, 'ignore_errors' => true),
        'ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false)));
    $b = @file_get_contents($url, false, $ctx);
    $out['body'] = is_string($b) ? substr($b, 0, 4000) : '';
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})/', $http_response_header[0], $m)) {
        $out['code'] = (int) $m[1]; $out['ok'] = $out['code'] >= 200 && $out['code'] < 300;
    } else { $out['err'] = 'سرور پیامک پاسخ نداد'; }
    return $out;
}

/* فرستادن یک پیامک با پنل انتخابی ادمین */
function ta_sms_send($to, $text)
{
    $c = ta_sms_cfg();
    $P = ta_sms_provs();
    $prov = isset($P[$c['prov']]) ? $c['prov'] : 'none';
    if ($prov === 'none') return array('ok' => false, 'msg' => 'پنل پیامک انتخاب نشده — از تب «پنل پیامک» انتخاب کنید');
    if ($prov === 'demo') return array('ok' => true, 'msg' => 'حالت نمونه: پیامک واقعاً ارسال نشد', 'body' => $text);
    $to = rawurlencode($to);
    $tx = rawurlencode(ta_str($text,480,true));
    preg_match('/[0-9]{5,6}/',$text,$otpMatch);
    $repl = array('{key}' => rawurlencode($c['key']), '{user}' => rawurlencode($c['user']),
                  '{from}' => rawurlencode($c['from']), '{to}' => $to, '{text}' => $tx, '{code}' => isset($otpMatch[0])?$otpMatch[0]:'');
    if ($prov === 'kavenegar') {
        $u = str_replace(array('{key}'), array(rawurlencode($c['key'])), $P['kavenegar']['url']);
        $q = 'receiver=' . $to . ($c['from'] !== '' ? '&sender=' . rawurlencode($c['from']) : '') . '&text=' . $tx;
        $r = ta_http($u . '?' . $q);
        $okj = json_decode($r['body'], true);
        $bad = is_array($okj) && isset($okj['return']) && (int) $okj['return']['status'] >= 400;
        return array('ok' => $r['ok'] && !$bad, 'msg' => $bad ? 'کاوه‌نگار خطا داد' : ($r['ok'] ? 'ارسال شد ✓' : ('کارت ' . ($r['code'] ? $r['code'] : $r['err']))), 'body' => $r['body']);
    }
    if ($prov === 'melipayamak') {
        $u = strtr($P['melipayamak']['url'], array('{user}' => rawurlencode($c['user']), '{key}' => rawurlencode($c['key']), '{to}' => $to, '{text}' => $tx));
        $r = ta_http($u);
        return array('ok' => $r['ok'], 'msg' => $r['ok'] ? 'ملی‌پیامک قبول کرد ✓' : ('ملی‌پیامک: ' . ($r['code'] ? 'HTTP ' . $r['code'] : $r['err'])), 'body' => $r['body']);
    }
    if ($prov === 'payamresan') {
        $u = $P['payamresan']['url'] . '?username=' . rawurlencode($c['user']) . '&password=' . rawurlencode($c['key'])
           . '&from=' . rawurlencode($c['from']) . '&to[]=' . $to . '&text=' . $tx;
        $r = ta_http($u);
        return array('ok' => $r['ok'], 'msg' => $r['ok'] ? 'پیام‌رسان قبول کرد ✓' : ('پیام‌رسان: ' . ($r['code'] ? 'HTTP ' . $r['code'] : $r['err'])), 'body' => $r['body']);
    }
    if ($prov === 'sms_ir') {
        $body = json_encode(array('moduleId' => (int) ($c['from'] !== '' ? preg_replace('/[^0-9]/', '', $c['from']) : 14116),
                                  'to' => $to, 'text' => $text));
        $r = ta_http($P['sms_ir']['url'], $body, array('Content-Type: application/json',
                     'X-API-KEY: ' . $c['key'], 'X-USER-API-KEY: ' . $c['user'], 'Accept: application/json'));
        $j = json_decode($r['body'], true);
        $st = is_array($j) && isset($j['status']) ? (int) $j['status'] : 0;
        return array('ok' => $r['ok'] && ($st === 0 || $st === 1 || isset($j['data'])), 'msg' => $st ? ('sms.ir status=' . $st) : ($r['ok'] ? 'ارسال شد ✓' : ('sms.ir: ' . ($r['code'] ? 'HTTP ' . $r['code'] : $r['err']))), 'body' => $r['body']);
    }
    if ($prov === 'farazsms') {
        $q = 'action=send&username=' . rawurlencode($c['user']) . '&password=' . rawurlencode($c['key'])
           . '&from[]=' . rawurlencode($c['from']) . '&to[]=' . $to . '&text=' . $tx;
        $r = ta_http($P['farazsms']['url'], $q, array('Content-Type: application/x-www-form-urlencoded'));
        return array('ok' => $r['ok'], 'msg' => $r['ok'] ? 'فراز قبول کرد ✓' : ('فراز: ' . ($r['code'] ? 'HTTP ' . $r['code'] : $r['err'])), 'body' => $r['body']);
    }
    /* دلخواه: الگوی آدرس که خودش جای‌گذاری می‌شود */
    if ($c['tpl'] === '') return array('ok' => false, 'msg' => 'الگوی آدرس را در «پنل پیامک» پر کنید');
    $u = strtr($c['tpl'], $repl);
    $r = ta_http($u);
    return array('ok' => $r['ok'], 'msg' => $r['ok'] ? 'ارسال شد ✓' : ('پنل دلخواه: ' . ($r['code'] ? 'HTTP ' . $r['code'] : $r['err'])), 'body' => $r['body']);
}

function ta_otp_get() { $o = ta_read('otp.json', array()); return is_array($o) ? $o : array(); }

function ta_member_tok($phone)
{
    $nonce='';foreach(ta_member_list() as $u) if(isset($u['phone'])&&$u['phone']===$phone){$nonce=isset($u['auth'])?$u['auth']:'';break;}
    return substr(hash_hmac('sha256', $phone . '|member|' . $nonce . '|' . ta_secret(), 'ta'), 0, 32);
}

function ta_sms_provs_names()
{
    $o = array();
    foreach (ta_sms_provs() as $k => $v) { $o[$k] = $v['نام']; }
    return $o;
}
function ta_otp_put($o) { ta_put('otp.json', $o); }

/* =====================================================================
 * Private full-site backups and reviewed deployments — admin token required.
 * Nothing is extracted into the live site until a confirmed apply request.
 * ===================================================================== */
function ta_fs_limits()
{
    $c = ta_cfg();
    return array('upload' => isset($c['maxArchive']) ? (int) $c['maxArchive'] : 64 * 1024 * 1024,
                 'expanded' => 256 * 1024 * 1024, 'count' => 10000);
}
function ta_fs_rel($rel)
{
    if (!is_string($rel) || $rel === '' || strlen($rel) > 220 || preg_match('/[\x00-\x1f\x7f\\\\:]/', $rel) || $rel[0] === '/')
        throw new Exception('مسیر فایل نامعتبر یا خارج از سایت است.');
    foreach (explode('/', $rel) as $part) {
        if ($part === '' || $part === '.' || $part === '..' || trim($part) !== $part ||
            preg_match('/[<>"|?*]/', $part) || in_array(strtolower($part), array('.git', '.ssh', 'node_modules'), true))
            throw new Exception('مسیر خطرناک یا نام فایل نامعتبر است.');
    }
    return $rel;
}
function ta_fs_root($scope)
{
    if ($scope !== 'site' && $scope !== 'data') throw new Exception('مقصد نامعتبر است.');
    $root = realpath($scope === 'site' ? __DIR__ : ta_cfg()['dataDir']);
    if ($root === false) throw new Exception('پوشه مقصد در دسترس نیست.');
    return $root;
}
function ta_fs_data_excluded($rel)
{
    $first = strtolower(explode('/', $rel)[0]);
    return in_array($first, array('backups', 'file-jobs', 'media-jobs', 'group-jobs', 'setup-key.txt', 'tokens.json', 'otp.json', 'rate.json', 'rl.json', 'privacy-key.json', 'privacy-erased.json', 'privacy-index.json', 'deletion-otp.json', 'google-nonces.json', 'push-state.json', 'push-apns.json', 'apns-auth-key.p8', 'push.lock', 'push-worker.lock', '.lock', '.htaccess', 'index.php'), true);
}
function ta_fs_dest($scope, $rel)
{
    ta_fs_rel($rel);
    if ($scope === 'data' && ta_fs_data_excluded($rel)) throw new Exception('بازنویسی فایل امنیتی یا نشست مجاز نیست.');
    $root = ta_fs_root($scope); $path = $root;
    foreach (explode('/', $rel) as $part) {
        $path .= '/' . $part;
        if (is_link($path)) throw new Exception('لینک نمادین در مسیر مقصد مجاز نیست.');
    }
    $data = realpath(ta_cfg()['dataDir']);
    if ($scope === 'site' && ($path === $data || strpos($path, $data . '/') === 0))
        throw new Exception('داده‌های کاربران باید در بخش data بازیابی شوند.');
    if (is_dir($path)) throw new Exception('مقصد یک پوشه است، نه فایل.');
    return $path;
}
function ta_fs_close($z)
{
    if (!$z) return;
    try { $z->close(); } catch (Throwable $ignored) {}
}
function ta_fs_zip_required()
{
    if (!class_exists('ZipArchive')) throw new Exception('افزونه ZIP در PHP هاست فعال نیست؛ در سی‌پنل PHP Extensions، zip را فعال کنید.');
}
function ta_fs_backup($by, $reason)
{
    ta_fs_zip_required();
    $id = bin2hex(random_bytes(16));
    $dir = ta_file('backups');
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) throw new Exception('پوشه بکاپ قابل نوشتن نیست.');
    if (is_link($dir)) throw new Exception('پوشه بکاپ نباید لینک نمادین باشد.');
    $path = $dir . '/' . $id . '.zip'; $tmp = $path . '.part';
    $z = new ZipArchive();
    if ($z->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) throw new Exception('ساخت ZIP بکاپ ممکن نشد.');
    $work = $dir . '/' . $id . '.work';
    if (!@mkdir($work, 0700)) { ta_fs_close($z); @unlink($tmp); throw new Exception('فضای موقت بکاپ قابل ساخت نیست.'); }
    $limits = ta_fs_limits(); $total = 0; $files = array(); $skipped = array();
    try {
        foreach (array('site', 'data') as $scope) {
            $root = ta_fs_root($scope);
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
            foreach ($it as $entry) {
                if (!$entry->isFile() && !$entry->isLink()) continue;
                $abs = $entry->getPathname(); $rel = substr($abs, strlen($root) + 1);
                if ($entry->isLink()) { $skipped[] = $scope . '/' . $rel; continue; }
                $data = realpath(ta_cfg()['dataDir']);
                if ($scope === 'site' && strpos($abs, $data . '/') === 0) continue;
                if ($scope === 'data' && ta_fs_data_excluded($rel)) continue;
                if (preg_match('~(^|/)(\.git|node_modules|file-jobs|media-jobs)(/|$)~i', $rel)) continue;
                ta_fs_rel($rel);
                $size = $entry->getSize();
                if ($size > $limits['upload'] || $total + $size > $limits['expanded'] || count($files) >= $limits['count'])
                    throw new Exception('حجم یا تعداد فایل‌های سایت از سقف بکاپ پنل بیشتر است؛ از بکاپ کامل سی‌پنل استفاده کنید.');
                $snapshot = $work . '/' . count($files) . '.bin';
                if (!@copy($abs, $snapshot) || filesize($snapshot) !== $size) throw new Exception('خواندن یکی از فایل‌های بکاپ ممکن نشد.');
                @chmod($snapshot, 0600);
                $name = $scope . '/' . $rel;
                if (!$z->addFile($snapshot, $name)) throw new Exception('افزودن فایل به ZIP ممکن نشد.');
                $files[] = array('path' => $name, 'sha256' => hash_file('sha256', $snapshot), 'size' => $size);
                $total += $size;
            }
        }
        $manifest = array('app' => 'titanali-backup', 'schema' => 1, 'version' => TA_VER, 'at' => time(), 'files' => $files);
        if (!$z->addFromString('titanali-backup-manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)))
            throw new Exception('ساخت فهرست بکاپ ممکن نشد.');
        if (!$z->close()) throw new Exception('نهایی‌سازی ZIP بکاپ ممکن نشد.');
        foreach (glob($work . '/*.bin') as $snapshot) @unlink($snapshot);
        @rmdir($work);
        if (!@rename($tmp, $path)) throw new Exception('ذخیره بکاپ ممکن نشد.');
        @chmod($path, 0600);
        $meta = array('id' => $id, 'name' => 'titanali-backup-' . date('Ymd-His') . '-' . substr($id, 0, 6) . '.zip',
            'at' => time(), 'by' => $by, 'reason' => $reason, 'size' => filesize($path), 'files' => count($files),
            'sha256' => hash_file('sha256', $path), 'skipped' => $skipped);
        if (!ta_put('backups/' . $id . '.json', $meta)) throw new Exception('ذخیره مشخصات بکاپ ممکن نشد.');
        return $meta;
    } catch (Exception $e) {
        ta_fs_close($z); @unlink($tmp);
        foreach (glob($work . '/*.bin') as $snapshot) @unlink($snapshot);
        @rmdir($work);
        throw $e;
    }
}
function ta_fs_backup_list()
{
    $out = array();
    foreach (glob(ta_file('backups') . '/*.json') as $path) {
        $id = basename($path, '.json');
        if (!preg_match('/^[a-f0-9]{32}$/', $id)) continue;
        $m = ta_read('backups/' . $id . '.json', null);
        if (is_array($m) && is_file(ta_file('backups/' . $id . '.zip'))) $out[] = $m;
    }
    usort($out, function ($a, $b) { return $b['at'] - $a['at']; });
    return $out;
}
function ta_fs_public_plan($job)
{
    $items = array();
    foreach ($job['files'] as $f) $items[] = array('path' => $f['scope'] . '/' . $f['rel'], 'size' => $f['size'],
        'change' => $f['old'] === null ? 'new' : ($f['old'] === $f['sha256'] ? 'same' : 'replace'));
    return array('id' => $job['id'], 'kind' => $job['kind'], 'name' => $job['name'], 'at' => $job['at'],
                 'files' => $items, 'count' => count($items), 'hasData' => $job['hasData'], 'executable' => $job['executable'], 'mime' => $job['mime']);
}
function ta_fs_single_target($name, $target)
{
    $name = basename(str_replace('\\', '/', $name));
    $name = preg_replace('/[^\p{L}\p{N}_. -]/u', '_', $name);
    if ($name === '' || $name[0] === '.') throw new Exception('نام فایل قابل قبول نیست.');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = array('png', 'jpg', 'jpeg', 'webp', 'gif', 'ico', 'pdf', 'txt', 'json', 'zip', 'html', 'css', 'js');
    if (!in_array($ext, $allowed, true)) throw new Exception('این نوع فایل مجاز نیست؛ فایل اجرایی PHP فقط داخل بسته سایت بررسی‌شده پذیرفته می‌شود.');
    if ($target === '') $target = is_file(__DIR__ . '/' . $name) ? $name : 'assets/' . $name;
    ta_fs_rel($target);
    if (strtolower(pathinfo($target, PATHINFO_EXTENSION)) !== $ext) throw new Exception('پسوند مقصد باید با فایل انتخاب‌شده یکی باشد.');
    ta_fs_dest('site', $target);
    return $target;
}
function ta_fs_inspect($source, $name, $owner, $target)
{
    $limits = ta_fs_limits();
    $size = filesize($source);
    if ($size < 1 || $size > $limits['upload']) throw new Exception('فایل خالی یا بزرگ‌تر از سقف مجاز است.');
    $id = bin2hex(random_bytes(16)); $dir = ta_file('file-jobs/' . $id);
    if (is_link(ta_file('file-jobs'))) throw new Exception('پوشه موقت نباید لینک نمادین باشد.');
    if (!@mkdir($dir, 0700, true)) throw new Exception('فضای موقت آپلود قابل نوشتن نیست.');
    ta_write_private_guard(dirname($dir) . '/.htaccess', ta_private_guard());
    $job = array('id' => $id, 'owner' => $owner, 'at' => time(), 'name' => basename($name), 'kind' => 'file',
        'files' => array(), 'hasData' => false, 'executable' => false,
        'mime' => class_exists('finfo') ? (new finfo(FILEINFO_MIME_TYPE))->file($source) : 'application/octet-stream');
    $entries = array(); $z = null;
    try {
        $fh = fopen($source, 'rb'); $magic = fread($fh, 4); fclose($fh);
        if (substr($magic, 0, 2) === 'PK' || strtolower(pathinfo($name, PATHINFO_EXTENSION)) === 'zip') {
            ta_fs_zip_required(); $z = new ZipArchive();
            if ($z->open($source) !== true) throw new Exception('فایل ZIP خراب است یا قالب پشتیبانی نمی‌شود.');
            if ($z->numFiles > $limits['count'] + 1000) throw new Exception('ZIP بیش از حد فایل دارد.');
            $names = array(); $total = 0;
            for ($i = 0; $i < $z->numFiles; $i++) {
                $st = $z->statIndex($i); if ($st === false) throw new Exception('فهرست ZIP خوانده نشد.');
                $n = $st['name']; ta_fs_rel(rtrim($n, '/'));
                $opsys = 0; $attr = 0;
                if ($z->getExternalAttributesIndex($i, $opsys, $attr) && (($attr >> 16) & 0170000) === 0120000)
                    throw new Exception('ZIP دارای لینک نمادین است.');
                if (substr($n, -1) === '/') continue;
                if (isset($names[strtolower($n)])) throw new Exception('ZIP دارای نام تکراری یا مبهم است.');
                $names[strtolower($n)] = $i;
                $total += $st['size'];
                if ($st['size'] > $limits['upload'] || $total > $limits['expanded'] || count($names) > $limits['count'] ||
                    ($st['size'] > 1024 * 1024 && $st['size'] / max(1, $st['comp_size']) > 1000))
                    throw new Exception('ZIP از سقف استخراج امن بیشتر است.');
            }
            $rawManifest = $z->getFromName('titanali-backup-manifest.json');
            if ($rawManifest !== false) {
                $m = json_decode($rawManifest, true);
                if (!is_array($m) || !isset($m['app'], $m['schema'], $m['files']) || $m['app'] !== 'titanali-backup' || $m['schema'] !== 1 || !is_array($m['files']))
                    throw new Exception('فهرست بکاپ سایت معتبر نیست.');
                $job['kind'] = 'backup'; $listed = array();
                foreach ($m['files'] as $f) {
                    if (!is_array($f) || !isset($f['path'], $f['sha256'], $f['size'])) throw new Exception('مشخصات فایل بکاپ ناقص است.');
                    $n = $f['path']; $parts = explode('/', $n, 2);
                    if (count($parts) !== 2 || !in_array($parts[0], array('site', 'data'), true) || isset($listed[strtolower($n)]))
                        throw new Exception('مسیر بکاپ نامعتبر است.');
                    $listed[strtolower($n)] = true; ta_fs_dest($parts[0], $parts[1]);
                    if (!isset($names[strtolower($n)])) throw new Exception('فایل اعلام‌شده در بکاپ وجود ندارد.');
                    $entries[] = array('zip' => $n, 'scope' => $parts[0], 'rel' => $parts[1], 'sha256' => $f['sha256'], 'size' => $f['size']);
                }
                if (count($listed) + 1 !== count($names)) throw new Exception('بکاپ فایل اعلام‌نشده دارد.');
            } else {
                $prefix = isset($names['public_html/index.html'], $names['public_html/api.php']) ? 'public_html/' : '';
                if (isset($names[$prefix . 'index.html'], $names[$prefix . 'api.php'])) {
                    $html = $z->getFromName($prefix . 'index.html'); $php = $z->getFromName($prefix . 'api.php');
                    if (strpos($html, 'titanali:ver') === false || strpos($php, 'TA_VER') === false)
                        throw new Exception('این ZIP بسته قابل‌شناسایی Titanali نیست.');
                    $job['kind'] = 'site-package';
                    foreach ($names as $key => $i) {
                        $n = $z->getNameIndex($i);
                        if ($prefix !== '' && strpos($n, $prefix) !== 0) throw new Exception('ZIP دارای فایل خارج از public_html است.');
                        $rel = substr($n, strlen($prefix)); $ext = strtolower(pathinfo($rel, PATHINFO_EXTENSION));
                        $ok = in_array($ext, array('html','css','js','json','png','jpg','jpeg','gif','webp','ico','svg','txt','webmanifest','xml'), true) ||
                            in_array($rel, array('api.php', 'index.php', 'titanali-bootstrap.php', 'titanali-media.php', 'titanali-accounts.php', 'titanali-install.php', 'titanali-config.sample.php', '.htaccess'), true);
                        if (!$ok) throw new Exception('فایل غیرمجاز در بسته سایت وجود دارد.');
                        ta_fs_dest('site', $rel);
                        $entries[] = array('zip' => $n, 'scope' => 'site', 'rel' => $rel);
                    }
                }
            }
        }
        if (!$z && strtolower(pathinfo($name, PATHINFO_EXTENSION)) === 'json') {
            $json = json_decode(file_get_contents($source), true);
            if (!is_array($json)) throw new Exception('فایل JSON معتبر نیست.');
            $content = isset($json['app'], $json['data']) && $json['app'] === 'titanali' && is_array($json['data']) ? $json['data'] :
                (isset($json['profile'], $json['gallery']) && is_array($json['profile']) && is_array($json['gallery']) ? $json : null);
            if ($content !== null) {
                $job['kind'] = 'content-backup'; unset($content['ig'], $content['feed']);
                $entries[] = array('scope' => 'data', 'rel' => 'content.json', 'bytes' => json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                foreach (array('social', 'inbox') as $section) {
                    if (isset($json[$section]) && is_array($json[$section]))
                        $entries[] = array('scope' => 'data', 'rel' => $section . '.json', 'bytes' => json_encode($json[$section], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                }
            }
        }
        if (!$entries) {
            if ($job['kind'] === 'backup') throw new Exception('بکاپ خالی است.');
            $job['kind'] = $z ? 'zip-file' : 'file';
            if ($z && strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'zip') throw new Exception('محتوای فایل ZIP است ولی پسوند آن zip نیست.');
            $rel = ta_fs_single_target($name, $target);
            $entries[] = array('scope' => 'site', 'rel' => $rel, 'source' => true);
        }
        foreach ($entries as $f) {
            $bytes = isset($f['bytes']) ? $f['bytes'] : (isset($f['source']) ? file_get_contents($source) : $z->getFromName($f['zip']));
            if ($bytes === false || strlen($bytes) > $limits['upload']) throw new Exception('خواندن فایل آپلودشده ممکن نشد.');
            $hash = hash('sha256', $bytes);
            if (isset($f['sha256']) && ($hash !== $f['sha256'] || strlen($bytes) !== (int) $f['size']))
                throw new Exception('امضای بکاپ یا اندازه فایل تطابق ندارد.');
            $dst = ta_fs_dest($f['scope'], $f['rel']);
            $stage = count($job['files']) . '.bin';
            if (file_put_contents($dir . '/' . $stage, $bytes, LOCK_EX) !== strlen($bytes)) throw new Exception('ذخیره موقت فایل ممکن نشد.');
            @chmod($dir . '/' . $stage, 0600);
            $job['files'][] = array('scope' => $f['scope'], 'rel' => $f['rel'], 'stage' => $stage,
                'sha256' => $hash, 'size' => strlen($bytes), 'old' => is_file($dst) ? hash_file('sha256', $dst) : null);
            if ($f['scope'] === 'data') $job['hasData'] = true;
            if (preg_match('/\.(php|html|js)$/i', $f['rel']) || $f['rel'] === '.htaccess') $job['executable'] = true;
        }
        if ($z) $z->close();
        if (!ta_put('file-jobs/' . $id . '/plan.json', $job)) throw new Exception('ثبت بررسی فایل ممکن نشد.');
        return ta_fs_public_plan($job);
    } catch (Exception $e) {
        if ($z) ta_fs_close($z);
        foreach (glob($dir . '/*') as $f) if (is_file($f)) @unlink($f);
        @rmdir($dir); throw $e;
    }
}
function ta_fs_prune_jobs()
{
    foreach (glob(ta_file('file-jobs') . '/*', GLOB_ONLYDIR) as $dir) {
        if (is_link($dir) || !preg_match('/^[a-f0-9]{32}$/', basename($dir))) continue;
        $plan = ta_read('file-jobs/' . basename($dir) . '/plan.json', null);
        $at = is_array($plan) && isset($plan['at']) ? (int) $plan['at'] : filemtime($dir);
        if (time() - $at < 3600) continue;
        foreach (glob($dir . '/*') as $file) if (is_file($file) && !is_link($file)) @unlink($file);
        @rmdir($dir);
    }
}
function ta_fs_job($id, $owner)
{
    if (!preg_match('/^[a-f0-9]{32}$/', $id)) throw new Exception('شناسه آپلود نامعتبر است.');
    $j = ta_read('file-jobs/' . $id . '/plan.json', null);
    if (!is_array($j) || $j['owner'] !== $owner) throw new Exception('آپلود پیدا نشد یا متعلق به مدیر دیگری است.');
    if (time() - $j['at'] > 3600) throw new Exception('زمان بررسی آپلود تمام شده؛ دوباره آپلود کنید.');
    return $j;
}
function ta_fs_cancel($id, $owner)
{
    ta_fs_job($id, $owner); $dir = ta_file('file-jobs/' . $id);
    foreach (glob($dir . '/*') as $f) if (is_file($f)) @unlink($f);
    @rmdir($dir);
}
function ta_fs_apply($id, $owner, $includeData)
{
    $job = ta_fs_job($id, $owner); $dir = ta_file('file-jobs/' . $id); $selected = array();
    if ($job['kind'] === 'content-backup' && !$includeData) throw new Exception('بکاپ JSON فقط داده‌ای است؛ بازیابی داده‌ها را صریحاً تأیید کنید.');
    foreach ($job['files'] as $f) {
        if ($f['scope'] === 'data' && !$includeData) continue;
        if ($f['scope']==='data') { $raw=file_get_contents($dir.'/'.$f['stage']);$j=json_decode($raw,true);ta_privacy_restore_guard($f['rel'],$j);$ledger=ta_read('privacy-erased.json',array());foreach($ledger as $r)if(in_array(ta_privacy_hash(basename($f['rel'])),$r['files'],true))throw new Exception('پیوست حذف‌شده قابل بازیابی نیست.'); }
        $dest = ta_fs_dest($f['scope'], $f['rel']);
        $old = is_file($dest) ? hash_file('sha256', $dest) : null;
        if ($old !== $f['old']) throw new Exception('یکی از فایل‌های هاست پس از بررسی عوض شده؛ برای جلوگیری از حذف تغییرات تازه، دوباره آپلود کنید.');
        if (hash_file('sha256', $dir . '/' . $f['stage']) !== $f['sha256']) throw new Exception('امضای فایل موقت عوض شده است.');
        if ($old === $f['sha256']) continue;
        $f['dest'] = $dest; $selected[] = $f;
    }
    if (!$selected) { ta_fs_cancel($id, $owner); return array('ok' => true, 'changed' => 0, 'backup' => null, 'reLogin' => false); }
    // Fail closed if a complete recovery backup cannot be created.
    $backup = ta_fs_backup($owner, 'before-replace');
    $prepared = array(); $applied = array();
    try {
        foreach ($selected as $i => $f) {
            $parent = dirname($f['dest']);
            if (!is_dir($parent) && !@mkdir($parent, 0755, true)) throw new Exception('پوشه مقصد قابل ساخت نیست.');
            if (!is_writable($parent)) throw new Exception('پوشه مقصد قابل نوشتن نیست.');
            $tmp = $f['dest'] . '.ta-' . $id . '.tmp';
            if (file_exists($tmp) || is_link($tmp)) throw new Exception('فایل موقت مقصد از قبل وجود دارد.');
            if (!@copy($dir . '/' . $f['stage'], $tmp)) throw new Exception('آماده‌سازی جایگزینی ممکن نشد.');
            @chmod($tmp, $f['scope'] === 'data' ? 0600 : 0644);
            if (hash_file('sha256', $tmp) !== $f['sha256']) { @unlink($tmp); throw new Exception('نسخه مقصد ناقص نوشته شد.'); }
            $f['tmp'] = $tmp; $f['rollback'] = $dir . '/rollback-' . $i . '.bin';
            if ($f['old'] !== null && !@copy($f['dest'], $f['rollback'])) { @unlink($tmp); throw new Exception('آماده‌سازی بازگشت ممکن نشد.'); }
            $prepared[] = $f;
        }
        // api.php is replaced last; the current request continues using this loaded code.
        usort($prepared, function ($a, $b) { return ($a['rel'] === 'api.php' ? 1 : 0) - ($b['rel'] === 'api.php' ? 1 : 0); });
        foreach ($prepared as $f) {
            ta_fs_dest($f['scope'], $f['rel']);
            if (!@rename($f['tmp'], $f['dest'])) throw new Exception('جایگزینی فایل روی هاست انجام نشد.');
            $applied[] = $f;
        }
    } catch (Exception $e) {
        $rollbackOk = true;
        foreach (array_reverse($applied) as $f) {
            if ($f['old'] === null) { if (is_file($f['dest']) && !@unlink($f['dest'])) $rollbackOk = false; }
            elseif (!@copy($f['rollback'], $f['dest'])) $rollbackOk = false;
        }
        foreach ($prepared as $f) if (is_file($f['tmp'])) @unlink($f['tmp']);
        if (!$rollbackOk) throw new Exception('بازگشت خودکار کامل نشد. بکاپ ایمنی محفوظ است: ' . $backup['id']);
        throw $e;
    }
    ta_harden(ta_cfg()['dataDir']);
    $reLogin = $includeData && $job['hasData'];
    if ($reLogin) { ta_put('tokens.json', array()); ta_put('otp.json', array()); }
    ta_fs_cancel($id, $owner);
    return array('ok' => true, 'changed' => count($applied), 'backup' => $backup, 'reLogin' => $reLogin);
}
function ta_fs_routes($action)
{
    $actions = array('files_status','backup_create','backup_download','backup_delete','files_inspect','files_apply','files_cancel');
    if (!in_array($action, $actions, true)) return;
    $w = ta_need_admin();
    if (empty($_SERVER['HTTP_X_TA_TOKEN']) && empty($_SERVER['HTTP_AUTHORIZATION']))
        ta_out(401, array('ok' => false, 'error' => 'نشست مدیر باید در هدر درخواست ارسال شود، نه در لینک دانلود.'));
    if (!in_array($action, array('files_status', 'backup_download'), true) && $_SERVER['REQUEST_METHOD'] !== 'POST')
        ta_out(405, array('ok' => false, 'error' => 'این عملیات فقط با POST مجاز است.'));
    $lock = null;
    try {
        if ($action === 'files_status') {
            $limits = ta_fs_limits();
            ta_out(200, array('ok'=>true,'zip'=>class_exists('ZipArchive'),'writable'=>is_writable(__DIR__),
                'maxUpload'=>$limits['upload'],'phpUpload'=>ini_get('upload_max_filesize'),'phpPost'=>ini_get('post_max_size'),
                'backups'=>ta_fs_backup_list()));
        }
        if ($action === 'backup_download') {
            $id = isset($_GET['id']) ? (string) $_GET['id'] : '';
            if (!preg_match('/^[a-f0-9]{32}$/', $id)) throw new Exception('شناسه بکاپ نامعتبر است.');
            $m = ta_read('backups/' . $id . '.json', null); $path = ta_file('backups/' . $id . '.zip');
            if (!is_array($m) || !is_file($path)) throw new Exception('بکاپ پیدا نشد.');
            header('Content-Type: application/zip'); header('Content-Disposition: attachment; filename="' . $m['name'] . '"');
            header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . filesize($path));
            readfile($path); exit;
        }
        if ($action === 'files_inspect') {
            if (!isset($_FILES['file']) || !is_array($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name']))
                throw new Exception('آپلود کامل نشد؛ سقف upload_max_filesize و post_max_size در سی‌پنل را بررسی کنید.');
            $f = $_FILES['file']; $target = isset($_POST['target']) ? trim((string) $_POST['target']) : '';
            $lock = ta_lock();
            ta_fs_prune_jobs();
            $plan = ta_fs_inspect($f['tmp_name'], $f['name'], $w['u'], $target);
            ta_unlock($lock); $lock = null;
            ta_out(200, array('ok'=>true,'plan'=>$plan));
        }
        $b = ta_body(); $id = isset($b['id']) ? (string) $b['id'] : '';
        $lock = ta_lock();
        if ($action === 'backup_create') {
            $m = ta_fs_backup($w['u'], 'manual'); ta_unlock($lock); $lock=null;
            ta_out(200, array('ok'=>true,'backup'=>$m,'backups'=>ta_fs_backup_list()));
        }
        if ($action === 'backup_delete') {
            if (empty($b['confirm']) || !preg_match('/^[a-f0-9]{32}$/', $id)) throw new Exception('حذف بکاپ نیاز به تأیید دارد.');
            $zip=ta_file('backups/'.$id.'.zip');$meta=ta_file('backups/'.$id.'.json');
            if (is_file($zip) && !@unlink($zip)) throw new Exception('حذف بکاپ ممکن نشد.');
            if (is_file($meta)) @unlink($meta);
            ta_unlock($lock);$lock=null;ta_out(200,array('ok'=>true,'backups'=>ta_fs_backup_list()));
        }
        if ($action === 'files_cancel') {
            ta_fs_cancel($id,$w['u']);ta_unlock($lock);$lock=null;ta_out(200,array('ok'=>true));
        }
        if ($action === 'files_apply') {
            if (empty($b['confirm'])) throw new Exception('جایگزینی فایل‌ها نیاز به تأیید صریح دارد.');
            $res=ta_fs_apply($id,$w['u'],!empty($b['includeData']));
            ta_unlock($lock);$lock=null;ta_out(200,$res);
        }
    } catch (Exception $e) {
        if ($lock) ta_unlock($lock);
        ta_out(400, array('ok'=>false,'error'=>$e->getMessage()));
    }
}

/* Privacy/account erasure. All destructive operations require a fresh, purpose-bound SMS code. */
function ta_privacy_key()
{
    static $cached = null;
    if ($cached !== null) return $cached;
    $p = ta_file('privacy-key.json'); $fp = @fopen($p, 'c+b');
    if (!$fp || !flock($fp, LOCK_EX)) throw new Exception('کلید حریم خصوصی قابل دسترس نیست.');
    $raw = stream_get_contents($fp); $j = json_decode($raw, true);
    if ($raw !== '' && (!is_array($j) || empty($j['key']))) { flock($fp, LOCK_UN); fclose($fp); throw new Exception('کلید حریم خصوصی خراب است.'); }
    $key = !empty($j['key']) ? $j['key'] : bin2hex(random_bytes(32));
    if ($raw === '') { rewind($fp); $bytes = json_encode(array('key'=>$key)); if (fwrite($fp,$bytes)!==strlen($bytes)) { flock($fp,LOCK_UN);fclose($fp);throw new Exception('ذخیره کلید ممکن نشد.'); } fflush($fp); }
    @chmod($p,0600);flock($fp,LOCK_UN);fclose($fp);$cached=$key;return $key;
}
function ta_privacy_hash($v) { return hash_hmac('sha256', (string) $v, ta_privacy_key()); }
function ta_privacy_phone_is($v, $phone) { return is_string($v) && ta_identity($v) === $phone; }
function ta_privacy_member($b)
{
    $p = ta_identity(isset($b['memberPhone']) ? $b['memberPhone'] : '');
    $t = isset($b['memberToken']) && is_string($b['memberToken']) ? $b['memberToken'] : '';
    if (!ta_identity_ok($p) || $t === '') return '';
    foreach (ta_member_list() as $u) {
        if (isset($u['phone']) && $u['phone'] === $p && empty($u['off']) && hash_equals(ta_member_tok($p), $t)) return $p;
    }
    if($p!==''&&$t!=='')ta_out(401,array('ok'=>false,'error'=>'نشست عضویت باطل شده؛ شماره را دوباره تأیید کنید.'));
    return '';
}
function ta_privacy_json_names()
{
    return array('users.json','inbox.json','who.json','seen.json','social.json','content.json','smslog.json','otp.json','rl.json','privacy-index.json','upload-owners.json','group.json','ready-orders.json','bookmarks.json');
}
function ta_privacy_scrub($data, $phone, $extraSids = array())
{
    $owner = ta_privacy_hash($phone); $sids = array_fill_keys($extraSids, true); $files = array();
    $box = isset($data['inbox.json']) && is_array($data['inbox.json']) ? $data['inbox.json'] : array();
    foreach ($box as $r) if (is_array($r) && ((!empty($r['phone']) && ta_privacy_phone_is($r['phone'], $phone)) || (isset($r['_owner']) && $r['_owner'] === $owner))) {
        if (!empty($r['sid'])) $sids[$r['sid']] = true;
    }
    foreach (isset($data['who.json']) ? $data['who.json'] : array() as $sid => $r)
        if (is_array($r) && isset($r['phone']) && ta_privacy_phone_is($r['phone'], $phone)) $sids[$sid] = true;
    $idx = isset($data['privacy-index.json'][$owner]) ? $data['privacy-index.json'][$owner] : array();
    foreach (isset($idx['sids']) ? $idx['sids'] : array() as $sid) $sids[$sid] = true;
    foreach (isset($idx['files']) ? $idx['files'] : array() as $id) $files[$id] = true;
    foreach ($box as $r) if (is_array($r) && isset($r['sid']) && isset($sids[$r['sid']]) && (!isset($r['from']) || $r['from'] !== 'admin') && ((isset($r['_owner']) && $r['_owner'] !== $owner) || (isset($r['phone']) && ta_ok_phone(ta_norm_phone($r['phone'])) && !ta_privacy_phone_is($r['phone'],$phone)))) unset($sids[$r['sid']]);
    $keep = array();
    foreach ($box as $r) {
        if (is_array($r) && ((isset($r['phone']) && ta_privacy_phone_is($r['phone'],$phone)) || (isset($r['_owner']) && $r['_owner']===$owner) || (isset($r['sid']) && isset($sids[$r['sid']])))) {
            if (isset($r['file']['id'])) $files[$r['file']['id']] = true;
        } else $keep[] = $r;
    }
    if (isset($data['inbox.json'])) $data['inbox.json'] = $keep;
    if(isset($data['who.json'])) foreach($data['who.json'] as $sid=>$r) if(isset($r['phone'])&&ta_privacy_phone_is($r['phone'],$phone)) unset($data['who.json'][$sid]);
    foreach (array('who.json','seen.json') as $name) if (isset($data[$name])) foreach ($sids as $sid => $_) unset($data[$name][$sid]);
    if (isset($data['users.json']['list'])) $data['users.json']['list'] = array_values(array_filter($data['users.json']['list'], function($r) use ($phone) {
        return !is_array($r) || !isset($r['phone']) || !ta_privacy_phone_is($r['phone'], $phone);
    }));
    if (isset($data['social.json']['comments'])) foreach ($data['social.json']['comments'] as $i => $comments) {
        $data['social.json']['comments'][$i] = array_values(array_filter($comments, function($r) use ($owner) {
            return !isset($r['_owner']) || $r['_owner'] !== $owner;
        }));
    }
    if (isset($data['content.json']['messages'])) $data['content.json']['messages'] = array_values(array_filter($data['content.json']['messages'], function($r) use ($sids, $phone, $owner) {
        return !is_array($r) || !((isset($r['sid']) && isset($sids[$r['sid']])) || (isset($r['phone']) && ta_privacy_phone_is($r['phone'], $phone)) || (isset($r['who']['phone']) && ta_privacy_phone_is($r['who']['phone'],$phone)) || (isset($r['_owner']) && $r['_owner'] === $owner));
    }));
    if (isset($data['smslog.json'])) $data['smslog.json'] = array_values(array_filter($data['smslog.json'], function($r) use ($phone) { return !isset($r['to']) || !ta_privacy_phone_is($r['to'], $phone); }));
    if (isset($data['otp.json'])) unset($data['otp.json'][$phone]);
    if (isset($data['bookmarks.json'])) unset($data['bookmarks.json'][$owner]);
    if (isset($data['rl.json'])) foreach ($data['rl.json'] as $k => $_) if (strpos($k, $phone) !== false) unset($data['rl.json'][$k]);
    if (isset($data['privacy-index.json'])) unset($data['privacy-index.json'][$owner]);
    if (isset($data['upload-owners.json'])) foreach ($data['upload-owners.json'] as $id => $r) if (isset($files[$id]) || (isset($r['owner']) && $r['owner'] === $owner) || (isset($r['sid']) && isset($sids[$r['sid']]))) { $files[$id]=true;unset($data['upload-owners.json'][$id]); }
    if(isset($data['ready-orders.json']['list']))$data['ready-orders.json']['list']=array_values(array_filter($data['ready-orders.json']['list'],function($r)use($phone){return !isset($r['phone'])||!ta_privacy_phone_is($r['phone'],$phone);}));
    if(isset($data['group.json'])) {
        $g=&$data['group.json'];unset($g['members'][$owner]);
        $g['messages']=array_values(array_filter(isset($g['messages'])?$g['messages']:array(),function($m)use($owner){return !isset($m['owner'])||$m['owner']!==$owner;}));
        foreach(isset($g['files'])?$g['files']:array() as $id=>$f)if(isset($f['owner'])&&$f['owner']===$owner){$files[$id]=true;unset($g['files'][$id]);}
        unset($g);
    }
    if(isset($data['content.json']['gallery']))foreach($data['content.json']['gallery'] as $i=>$g)if(isset($g['comments'])&&is_array($g['comments']))$data['content.json']['gallery'][$i]['comments']=array_values(array_filter($g['comments'],function($c)use($owner){return !isset($c['_owner'])||$c['_owner']!==$owner;}));
    // Never unlink a file also referenced by someone else's retained messages.
    foreach ($keep as $r) if (isset($r['file']['id'])) unset($files[$r['file']['id']]);
    return array('data' => $data, 'sids' => array_keys($sids), 'files' => array_keys($files));
}
function ta_privacy_write($name, $data)
{
    if (!ta_put($name, $data)) throw new Exception('نوشتن دادهٔ حذف‌شده ممکن نشد؛ دوباره تلاش کنید.');
}
function ta_privacy_scrub_zip($path, $phone, $sids)
{
    ta_fs_zip_required();
    if (is_link($path)) throw new Exception('مسیر بکاپ نامعتبر است.');
    $z = new ZipArchive();
    if ($z->open($path) !== true) throw new Exception('یک بکاپ خواندنی نیست؛ حذف کامل تأیید نشد.');
    $manifest = json_decode($z->getFromName('titanali-backup-manifest.json'), true);
    if (!is_array($manifest) || empty($manifest['files'])) { $z->close(); throw new Exception('بکاپ ناشناخته است؛ مدیر باید آن را بررسی کند.'); }
    $data = array();
    foreach (ta_privacy_json_names() as $n) {
        $raw = $z->getFromName('data/' . $n);
        if ($raw !== false) { $j = json_decode($raw, true); if (!is_array($j)) { $z->close(); throw new Exception('JSON بکاپ نامعتبر است.'); } $data[$n] = $j; }
    }
    $clean = ta_privacy_scrub($data, $phone, $sids); $replace = array(); $remove = array();
    foreach ($clean['data'] as $n => $j) if ($j !== $data[$n]) $replace['data/' . $n] = json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    foreach ($clean['files'] as $id) $remove['data/uploads/' . $id] = true;
    if (!$replace && !$remove) { $z->close(); return; }
    $tmp = $path . '.erase'; $out = new ZipArchive();
    if ($out->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { $z->close(); throw new Exception('بازنویسی بکاپ ممکن نشد.'); }
    try {
        $entries = array();
        foreach ($manifest['files'] as $f) {
            $name = $f['path'];
            if (isset($remove[$name])) continue;
            $bytes = isset($replace[$name]) ? $replace[$name] : $z->getFromName($name);
            if ($bytes === false || !$out->addFromString($name, $bytes)) throw new Exception('پاک‌سازی بکاپ ناقص بود.');
            $f['sha256'] = hash('sha256', $bytes); $f['size'] = strlen($bytes); $entries[] = $f;
        }
        $manifest['files'] = $entries;
        $out->addFromString('titanali-backup-manifest.json', json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        if (!$out->close()) throw new Exception('ذخیره بکاپ پاک‌سازی‌شده نشد.');
        $out = null; $z->close(); $z = null;
        if (!@rename($tmp, $path)) throw new Exception('جایگزینی بکاپ ممکن نشد.');
        @chmod($path, 0600);
        $id = basename($path, '.zip'); $meta = ta_read('backups/' . $id . '.json', array());
        $meta['sha256'] = hash_file('sha256', $path); $meta['size'] = filesize($path); $meta['files'] = count($entries);
        ta_privacy_write('backups/' . $id . '.json', $meta);
    } catch (Exception $e) { ta_fs_close($out); ta_fs_close($z); @unlink($tmp); throw $e; }
}
function ta_privacy_erase($phone)
{
    $data = array();
    foreach (ta_privacy_json_names() as $n) if (is_file(ta_file($n))) $data[$n] = ta_read($n, array());
    $clean = ta_privacy_scrub($data, $phone);
    foreach(glob(ta_file('group-jobs/').'*.json') as $job){$j=json_decode((string)@file_get_contents($job),true);if(isset($j['owner'])&&$j['owner']===ta_privacy_hash($phone)){@unlink(substr($job,0,-5).'.part');@unlink($job);}}
    // Existing backups are scrubbed in place; no new backup of erased personal data is made.
    foreach (array('*.part','*.work') as $pattern) if (glob(ta_file('backups/') . $pattern)) throw new Exception('بکاپ نیمه‌تمام وجود دارد؛ مدیر باید آن را بررسی کند.');
    foreach (glob(ta_file('backups/') . '*.zip') as $path) ta_privacy_scrub_zip($path, $phone, $clean['sids']);
    foreach (glob(ta_file('backups/') . 'backup-*.json') as $path) {
        $name = 'backups/' . basename($path); $j = ta_read($name, array()); $map = array();
        foreach (array('content','social','inbox') as $k) if (isset($j[$k])) $map[$k . '.json'] = $j[$k];
        $r = ta_privacy_scrub($map, $phone, $clean['sids']);
        foreach ($r['data'] as $n => $v) $j[substr($n, 0, -5)] = $v;
        ta_privacy_write($name, $j);
    }
    // Reviewed but not applied data uploads can contain old private records: cancel only affected jobs.
    foreach (glob(ta_file('file-jobs/') . '*', GLOB_ONLYDIR) as $dir) {
        if (is_link($dir)) throw new Exception('مسیر آپلود موقت نامعتبر است.');
        $job = ta_read('file-jobs/' . basename($dir) . '/plan.json', array()); $map = array();
        foreach (isset($job['files']) ? $job['files'] : array() as $f) if ($f['scope'] === 'data' && in_array($f['rel'], ta_privacy_json_names(), true)) {
            $j = json_decode(file_get_contents($dir . '/' . $f['stage']), true); if (is_array($j)) $map[$f['rel']] = $j;
        }
        $r = ta_privacy_scrub($map, $phone, $clean['sids']);
        $affected = $r['data'] !== $map;
        foreach (isset($job['files']) ? $job['files'] : array() as $f) if ($f['scope'] === 'data' && in_array($f['rel'], array_map(function($id){return 'uploads/' . $id;}, $clean['files']), true)) $affected = true;
        if ($affected) {
            foreach (glob($dir . '/*') as $file) if (is_file($file) && !is_link($file) && !@unlink($file)) throw new Exception('پاک‌سازی آپلود موقت نشد.');
            @rmdir($dir);
        }
    }
    foreach ($clean['data'] as $n => $j) if ($j !== $data[$n]) ta_privacy_write($n, $j);
    foreach ($clean['files'] as $id) {
        if (!preg_match('/^(?:[a-f0-9]{24}|group-[a-f0-9]{32})\.[a-z0-9]+$/', $id)) continue;
        $path = ta_file('uploads/' . $id);
        if (is_link($path) || (is_file($path) && !@unlink($path))) throw new Exception('حذف یکی از پیوست‌ها ممکن نشد.');
    }
    $ledger = ta_read('privacy-erased.json', array());
    $h=ta_privacy_hash($phone);$prior=isset($ledger[$h])?$ledger[$h]:array('sids'=>array(),'files'=>array());
    $ledger[$h] = array('at' => time(), 'sids' => array_values(array_unique(array_merge($prior['sids'],array_map('ta_privacy_hash', $clean['sids'])))), 'files' => array_values(array_unique(array_merge($prior['files'],array_map('ta_privacy_hash', $clean['files'])))));
    ta_privacy_write('privacy-erased.json', $ledger);
    $rev=ta_bump();
    if (is_file(ta_publish_path())) { $pub=ta_bake(ta_read('content.json',array()),$rev,'privacy'); if(isset($pub['error'])) throw new Exception('پاک‌سازی نسخهٔ منتشرشده نشد.'); }
    return array('ok' => true, 'deleted' => true, 'receipt' => bin2hex(random_bytes(12)), 'message' => 'حساب و داده‌های مرتبط قابل شناسایی روی این سرور و بکاپ‌های داخلی پاک شدند.');
}
function ta_privacy_restore_guard($rel, $j)
{
    $ledger = ta_read('privacy-erased.json', array());
    if (!$ledger || !is_array($j)) return;
    $check = function($v) use (&$check, $ledger) {
        if (!is_array($v)) return;
        foreach(array('phone','ph') as $k)if(isset($v[$k])&&is_string($v[$k])&&preg_match('/^g_[a-f0-9]{40}$/D',$v[$k])&&isset($ledger[ta_privacy_hash($v[$k])]))throw new Exception('حساب حذف‌شده قابل بازیابی نیست.');
        foreach (array('phone','ph','to') as $k) if (isset($v[$k]) && is_scalar($v[$k]) && ta_ok_phone(ta_norm_phone($v[$k])) && isset($ledger[ta_privacy_hash(ta_norm_phone($v[$k]))])) throw new Exception('این بازیابی شامل دادهٔ هویتی حذف‌شده است؛ به دلیل حفاظت از حریم خصوصی رد شد.');
        if ((isset($v['_owner']) && is_string($v['_owner']) && isset($ledger[$v['_owner']])) || (isset($v['owner']) && is_string($v['owner']) && isset($ledger[$v['owner']]))) throw new Exception('دادهٔ حذف‌شده در بکاپ وجود دارد.');
        foreach ($v as $k => $value) {
            if(is_string($k)&&isset($ledger[$k]))throw new Exception('ذخیره‌های حساب حذف‌شده قابل بازیابی نیست.');
            foreach ($ledger as $erased) if (in_array(ta_privacy_hash((string)$k), $erased['sids'], true) || in_array(ta_privacy_hash((string)$k), $erased['files'], true) || (is_string($value) && (in_array(ta_privacy_hash($value), $erased['sids'], true) || in_array(ta_privacy_hash($value), $erased['files'], true)))) throw new Exception('بکاپ حاوی شناسهٔ حذف‌شده است.');
            if (is_array($value)) $check($value);
        }
    };
    if ($rel === 'content.json') { if (isset($j['messages'])) $check($j['messages']); }
    elseif (in_array($rel, ta_privacy_json_names(), true)) $check($j);
}
function ta_privacy_routes($action)
{
    if (!in_array($action, array('delete_start','delete_confirm'), true)) return;
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') ta_out(405, array('ok'=>false,'error'=>'فقط POST مجاز است.'));
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) ta_out(415, array('ok'=>false,'error'=>'JSON لازم است.'));
    $b = ta_body(); $phone = ta_norm_phone(isset($b['phone']) ? $b['phone'] : '');
    if (!ta_ok_phone($phone)) ta_out(400, array('ok'=>false,'error'=>'شماره موبایل معتبر لازم است.'));
    $cfg = ta_sms_cfg();
    if (in_array($cfg['prov'], array('none','demo'), true)) ta_out(409, array('ok'=>false,'error'=>'حذف با احراز هویت پیامکی به پنل واقعی و فعال نیاز دارد. از بخش گفتگو با پشتیبانی تماس بگیرید.'));
    if ($action === 'delete_start') {
        if (!ta_throttle('delip:' . ta_ip(), 4, 600) || !ta_throttle('delph:' . ta_privacy_hash($phone), 3, 600)) ta_out(429,array('ok'=>false,'error'=>'درخواست زیاد است؛ ده دقیقه صبر کنید.'));
        $code = (string) random_int(100000,999999); $id = bin2hex(random_bytes(16)); $lk = ta_lock();
        $o = ta_read('deletion-otp.json',array());
        foreach ($o as $p=>$r) if (!is_array($r) || $r['at'] < time()-300) unset($o[$p]);
        $o[$phone] = array('id'=>$id,'h'=>hash_hmac('sha256',$id.'|delete|'.$code,ta_privacy_key()),'at'=>time(),'try'=>0);
        ta_privacy_write('deletion-otp.json',$o); ta_unlock($lk);
        $r = ta_sms_send($phone,'کد حذف دائمی حساب تیتانلی: '.$code.' — این کد فقط برای حذف است.');
        if (empty($r['ok'])) { $lk=ta_lock();$o=ta_read('deletion-otp.json',array());if(isset($o[$phone])&&$o[$phone]['id']===$id){unset($o[$phone]);ta_privacy_write('deletion-otp.json',$o);}ta_unlock($lk);ta_out(502,array('ok'=>false,'error'=>'ارسال پیامک حذف انجام نشد؛ از پشتیبانی کمک بگیرید.')); }
        ta_out(200,array('ok'=>true,'challenge'=>$id,'expiresIn'=>300,'message'=>'کد شش‌رقمی حذف را وارد کنید.'));
    }
    if (empty($b['confirm']) || $b['confirm'] !== 'DELETE') ta_out(400,array('ok'=>false,'error'=>'تأیید صریح حذف لازم است.'));
    $lk=ta_lock();
    try {
        $o=ta_read('deletion-otp.json',array());$r=isset($o[$phone])?$o[$phone]:null;
        if (!$r || $r['at']<time()-300 || $r['try']>=5 || !isset($b['challenge']) || !is_string($b['challenge']) || !hash_equals($r['id'],$b['challenge'])) { ta_unlock($lk);ta_out(401,array('ok'=>false,'error'=>'کد حذف منقضی یا نامعتبر است.')); }
        $code=ta_str(isset($b['code'])?$b['code']:'',6);
        if (!preg_match('/^[0-9]{6}$/',$code) || !hash_equals($r['h'],hash_hmac('sha256',$r['id'].'|delete|'.$code,ta_privacy_key()))) { $o[$phone]['try']++;ta_privacy_write('deletion-otp.json',$o);ta_unlock($lk);ta_out(401,array('ok'=>false,'error'=>'کد حذف درست نیست.')); }
        $result=ta_privacy_erase($phone);unset($o[$phone]);ta_privacy_write('deletion-otp.json',$o);ta_unlock($lk);ta_out(200,$result);
    } catch (Throwable $e) { ta_unlock($lk);ta_out(500,array('ok'=>false,'error'=>'حذف کامل تأیید نشد؛ درخواست را دوباره انجام دهید یا به پشتیبانی اطلاع دهید.')); }
}


/* Ready-order records are private: never part of public website content. */
function ta_orders_read() {
    $p=ta_file('ready-orders.json');
    if(!is_file($p))return array('mode'=>'phone','list'=>array());
    $s=@file_get_contents($p);$v=is_string($s)?json_decode($s,true):null;
    if(!is_array($v)||!isset($v['mode'],$v['list'])||!in_array($v['mode'],array('name','phone'),true)||!is_array($v['list']))throw new Exception('سفارش‌ها خوانده نشدند؛ داده‌ها تغییر نکردند.');
    foreach($v['list'] as $r)if(!is_array($r)||!isset($r['id'],$r['name'],$r['phone']))throw new Exception('ساختار سفارش‌ها معتبر نیست.');
    return $v;
}
function ta_order_name($s){
    $s=ta_str($s,120,true);$s=str_replace(array('ي','ى','ك',"\xE2\x80\x8C","\xE2\x80\x8D"),array('ی','ی','ک',' ',' '),$s);
    $s=preg_replace('/[ًٌٍَُِّْٰ]/u','',$s);return trim(preg_replace('/\s+/u',' ',$s));
}
function ta_orders_routes($action){
    if(!in_array($action,array('orders_mode','order_lookup','orders_admin'),true))return;
    $method=$_SERVER['REQUEST_METHOD'];
    if($action==='orders_mode'){
        if($method!=='GET')ta_out(405,array('ok'=>false));$s=ta_orders_read();ta_out(200,array('ok'=>true,'mode'=>$s['mode']));
    }
    if($action==='order_lookup'){
        if($method!=='POST')ta_out(405,array('ok'=>false,'error'=>'از فرم پیگیری استفاده کنید.'));
        $b=ta_body();$lk=ta_lock();
        if(!ta_throttle('order-lookup:'.hash('sha256',isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:''),12,60)){ta_unlock($lk);ta_out(429,array('ok'=>false,'error'=>'درخواست‌ها زیاد است؛ یک دقیقه بعد دوباره تلاش کنید.'));}
        $s=ta_orders_read();ta_unlock($lk);
        if(!isset($b['value'])||!is_string($b['value'])||strlen($b['value'])>480)ta_out(400,array('ok'=>false,'error'=>'نام یا شماره را کامل وارد کنید.'));
        if(!isset($b['mode'])||$b['mode']!==$s['mode'])ta_out(409,array('ok'=>false,'mode'=>$s['mode'],'error'=>'روش پیگیری تغییر کرده است؛ دوباره وارد کنید.'));
        $v=$s['mode']==='phone'?ta_norm_phone($b['value']):ta_order_name($b['value']);
        if(($s['mode']==='phone'&&!ta_ok_phone($v))||($s['mode']==='name'&&strlen($v)<3))ta_out(400,array('ok'=>false,'error'=>'نام کامل یا شمارهٔ همراه معتبر را وارد کنید.'));
        $ready=false;foreach($s['list'] as $r){$key=$s['mode']==='phone'?$r['phone']:ta_order_name($r['name']);if($key!==''&&hash_equals($key,$v)){$ready=true;break;}}
        ta_out(200,array('ok'=>true,'ready'=>$ready,'msg'=>$ready?'لباس شما حاضر است':'هنوز سفارش آماده‌ای با این مشخصات اعلام نشده است؛ اطلاعات را بررسی کنید یا با کارگاه تماس بگیرید.'));
    }
    ta_need_admin();
    if($method==='GET'){$s=ta_orders_read();ta_out(200,array('ok'=>true,'mode'=>$s['mode'],'list'=>array_values($s['list'])));}
    if($method!=='POST')ta_out(405,array('ok'=>false));
    $b=ta_body();$op=isset($b['op'])?$b['op']:'';
    if(!in_array($op,array('mode','add','remove'),true))ta_out(400,array('ok'=>false,'error'=>'عملیات نامعتبر است.'));
    $lk=ta_lock();$s=ta_orders_read();
    if($op==='mode'){
        if(!isset($b['mode'])||!in_array($b['mode'],array('phone','name'),true)){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'روش پیگیری معتبر نیست.'));}
        $s['mode']=$b['mode'];
    }else{
        $id=isset($b['id'])&&is_string($b['id'])?$b['id']:'';
        if(!preg_match('/^[a-f0-9]{32}$/',$id)){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'شناسهٔ عملیات معتبر نیست.'));}
        if($op==='remove')$s['list']=array_values(array_filter($s['list'],function($r)use($id){return $r['id']!==$id;}));
        else{
            foreach(array('name','phone') as $k)if(isset($b[$k])&&(!is_string($b[$k])||strlen($b[$k])>480)){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'اطلاعات سفارش معتبر نیست.'));}
            $name=ta_order_name(isset($b['name'])?$b['name']:'');$raw=isset($b['phone'])?$b['phone']:'';$phone=ta_norm_phone($raw);
            if(($s['mode']==='name'&&strlen($name)<3)||($s['mode']==='phone'&&!ta_ok_phone($phone))||($raw!==''&&!ta_ok_phone($phone))){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'فیلد مربوط به روش پیگیری را کامل و معتبر وارد کنید.'));}
            $found=false;foreach($s['list'] as $r)if($r['id']===$id){if($r['name']!==$name||$r['phone']!==$phone){ta_unlock($lk);ta_out(409,array('ok'=>false,'error'=>'شناسه برای سفارش دیگری استفاده شده است.'));}$found=true;}
            if(!$found){if(count($s['list'])>=500){ta_unlock($lk);ta_out(409,array('ok'=>false,'error'=>'فهرست پر است؛ سفارش تحویل‌شده را حذف کنید.'));}$s['list'][]=array('id'=>$id,'name'=>$name,'phone'=>$phone,'at'=>time());}
        }
    }
    if(!ta_put('ready-orders.json',$s)){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'ذخیره روی هاست تأیید نشد؛ دوباره تلاش کنید.'));}
    ta_unlock($lk);ta_out(200,array('ok'=>true,'mode'=>$s['mode'],'list'=>array_values($s['list'])));
}

/* =====================================================================
 *  مسیردهی
 * ===================================================================== */
require_once __DIR__ . '/titanali-media.php';
require_once __DIR__ . '/titanali-accounts.php';
require_once __DIR__ . '/titanali-push.php';
if (defined('TA_LIBRARY_ONLY') && TA_LIBRARY_ONLY) return;
try{ta_cfg();}catch(Throwable $e){http_response_code(500);header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');echo json_encode(array('ok'=>false,'code'=>'invalid_configuration','error'=>'پیکربندی پوشهٔ داده معتبر نیست؛ داده‌ها حذف نشده‌اند. تنظیمات خصوصی را در چت نفرستید.'));exit;}

$ACTION = isset($_GET['action']) ? preg_replace('/[^a-z_]/', '', strtolower((string) $_GET['action'])) : 'health';
ta_cors();
ta_push_routes($ACTION);
ta_media_routes($ACTION);
try{ta_accounts_routes($ACTION);}catch(Throwable $e){ta_out(503,array('ok'=>false,'error'=>'سرویس حساب و ذخیره‌ها موقتاً در دسترس نیست؛ دوباره تلاش کنید.'));}
if(strpos($ACTION,'group_')===0)ta_out(410,array('ok'=>false,'error'=>'گروه عمومی از این نسخه حذف شده است.'));
try{ta_orders_routes($ACTION);}catch(Throwable $e){ta_out(503,array('ok'=>false,'error'=>'سرویس سفارش‌ها موقتاً در دسترس نیست؛ داده‌ها تغییر نکرده‌اند.'));}
try { ta_privacy_routes($ACTION); } catch (Throwable $e) { ta_out(503,array('ok'=>false,'error'=>'سرویس حذف موقتاً در دسترس نیست؛ از پشتیبانی کمک بگیرید.')); }
ta_fs_routes($ACTION);

/** نسخهٔ پوستهٔ سایت از <head> — تا ببینید index.html روی هاست بهٔروز است یا نه */
function ta_site_ver()
{
    $f = __DIR__ . '/index.html';
    if (!is_readable($f)) { return ''; }
    $fp = @fopen($f, 'rb');
    if (!$fp) { return ''; }
    $head = (string) fread($fp, 8192);
    fclose($fp);
    if (preg_match('/name="titanali:ver" content="([0-9.]+)"/', $head, $m)) { return $m[1]; }
    return '';
}

/* Small revision probe: no members, conversations, tokens or server paths. */
if ($ACTION === 'sync') {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') ta_out(405, array('ok'=>false,'error'=>'GET required'));
    $state=array('ok'=>true, 'app'=>'titanali', 'ver'=>TA_VER, 'siteVer'=>ta_site_ver(), 'rev'=>ta_rev());
    $etag='"ta-sync-'.hash('sha256',json_encode($state)).'"';
    header('ETag: '.$etag);
    header('Cache-Control: no-store, max-age=0');
    $incoming=isset($_SERVER['HTTP_IF_NONE_MATCH'])?(string)$_SERVER['HTTP_IF_NONE_MATCH']:'';
    foreach(explode(',',$incoming) as $candidate){
        $candidate=trim($candidate);if(strpos($candidate,'W/')===0)$candidate=substr($candidate,2);
        // Apache/LiteSpeed compression may append an encoding suffix to the response ETag.
        // All accepted variants still identify exactly this same public revision payload.
        $variants=array($etag,substr($etag,0,-1).'-gzip"',substr($etag,0,-1).'-br"',substr($etag,0,-1).'-deflate"');
        if(in_array($candidate,$variants,true)||$candidate==='*'){http_response_code(304);exit;}
    }
    ta_out(200,$state);
}
$ME = ta_whoami();
$AUTH = is_array($ME);

/* ---------- عمومی ---------- */
if ($ACTION === 'health') {
    if (!ta_installed()) { try { ta_setup_key(); } catch (Throwable $e) { ta_out(500,array('ok'=>false,'error'=>$e->getMessage())); } }
    ta_out(200, array('ok' => true, 'app' => 'titanali', 'ver' => TA_VER, 'siteVer' => ta_site_ver(), 'installed' => ta_installed(),
                      'needSetup' => !ta_installed(), 'rev' => ta_rev(),
                      'writable' => is_writable(ta_cfg()['dataDir']),
                      'mediaTransport' => 'adaptive-chunks', 'mediaChunkSize' => ta_media_chunk_size(),
                      'maxImageBytes' => ta_cfg()['maxFile'], 'postMaxSize' => ini_get('post_max_size'),
                      'php' => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION,
                      'dataDir' => ta_cfg()['dataDir'],
                      'host' => isset($_SERVER['HTTP_HOST']) ? preg_replace('/[^A-Za-z0-9.:-]/', '', $_SERVER['HTTP_HOST']) : '',
                      'domain' => (defined('TA_DOMAIN') ? TA_DOMAIN : ''),
                      'publish' => ta_baked_info(),
                      'smsOn' => (ta_sms_cfg()['prov'] !== 'none'), 'smsProv' => ta_sms_cfg()['prov'],
                      'members' => count(ta_member_list())));
}

if ($ACTION === 'install') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') ta_out(405,array('ok'=>false,'error'=>'POST required'));
    if (ta_installed()) ta_out(409,array('ok'=>false,'error'=>'روی این سرور قبلاً نصب شده است'));
    try { $result=ta_install_owner(ta_body()); $result['token']=ta_issue($result['user']); ta_out(200,$result); }
    catch (Throwable $e) { ta_out(400,array('ok'=>false,'error'=>$e->getMessage())); }
}

if ($ACTION === 'login') {
    if (!ta_installed()) ta_out(423, array('ok' => false, 'error' => 'نصب انجام نشده — از تب همگام‌سازی اقدام کنید'));
    $b = ta_body();
    $u = ta_str(isset($b['u']) ? $b['u'] : '', 32);
    $p = isset($b['p']) ? (string) $b['p'] : '';
    if (!ta_throttle('login:' . ta_ip() . ':' . $u, 10, 600)) {
        ta_out(429, array('ok' => false, 'error' => 'تلاش زیاد بود — ۱۰ دقیقه صبر کنید'));
    }
    $found = null;
    foreach (ta_users() as $a) {
        if (isset($a['u']) && $a['u'] === $u && ta_check_pw($p, isset($a['p']) ? $a['p'] : '')) { $found = $a; break; }
    }
    if (!$found) ta_out(401, array('ok' => false, 'error' => 'نام کاربری یا رمز درست نیست'));
    ta_out(200, array('ok' => true, 'token' => ta_issue($u), 'user' => $u,
                      'name' => isset($found['name']) ? $found['name'] : $u));
}

if ($ACTION === 'logout') {
    $b = ta_body();
    $tk = ta_read('tokens.json', array());
    foreach ($tk as $u => $r) {
        if (is_array($r) && isset($r['h']) && isset($b['t']) && $r['h'] === hash('sha256', (string) $b['t'])) unset($tk[$u]);
    }
    ta_put('tokens.json', $tk);
    ta_out(200, array('ok' => true));
}

if ($ACTION === 'content') {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') ta_out(200, ta_payload(true));
    $w = ta_need_admin();
    $b = ta_body();
    $data = isset($b['data']) ? $b['data'] : null;
    if (!is_array($data)) ta_out(400, array('ok' => false, 'error' => 'data لازم است'));
    if (count($data) < 1) ta_out(400, array('ok' => false, 'error' => 'data خالی است'));
    $lk = ta_lock();
    $cur = ta_rev();
    if (isset($b['baseRev']) && (int) $b['baseRev'] !== $cur) {
        ta_unlock($lk);
        ta_out(409, array('ok' => false, 'conflict' => true, 'rev' => $cur, 'data' => ta_read('content.json', null),
                          'error' => 'نسخهٔ سرور تازه‌تر است؛ اول «گرفتن از سرور» را بزنید یا با «جابه‌جایی» بازنویسی کنید'));
    }
    if(isset($data['messages'])&&is_array($data['messages']))$data['messages']=array_values(array_filter($data['messages'],function($m){try{ta_privacy_restore_guard('inbox.json',array($m));return true;}catch(Exception $e){return false;}}));
    if (!ta_put('content.json', $data)) { ta_unlock($lk); ta_out(500, array('ok' => false, 'error' => 'نوشتن نشد')); }
    $newRev = ta_bump();
    $lg = ta_read('log.json', array());
    array_push($lg, array('ts' => time(), 'u' => $w['u'], 'what' => 'content'));
    ta_put('log.json', array_slice($lg, -200));
    $pub = array('error' => 'off');
    if (empty($b['noPublish'])) {
        $pub = ta_bake($data, $newRev, $w['u']);
        ta_note_publish($pub, $w['u'], $newRev);
    }
    ta_unlock($lk);
    $failed = empty($b['noPublish']) && isset($pub['error']);
    ta_out($failed ? 500 : 200, array('ok' => !$failed, 'rev' => $newRev, 'publish' => $pub, 'sections' => ta_sections_of($data),
        'error' => $failed ? 'محتوا ذخیره شد ولی جایگزینی فایل منتشرشده انجام نشد؛ مجوز نوشتن و تنظیم publishFile را بررسی کنید.' : ''));
}

if ($ACTION === 'social') { ta_out(200, array('ok' => true, 'social' => ta_social_shape())); }

if ($ACTION === 'metric') {
    $b = ta_body();
    $i = isset($b['i']) ? preg_replace('/[^0-9]/', '', (string) $b['i']) : '';
    $k = isset($b['k']) ? (string) $b['k'] : '';
    $d = isset($b['d']) ? ((int) $b['d']) : 1;
    if ($d > 1) $d = 1; if ($d < -1) $d = -1;
    if ($i === '' || !in_array($k, array('like', 'dl'), true)) ta_out(400, array('ok' => false, 'error' => 'i و k لازم است'));
    if (!ta_throttle('metric:' . ta_ip(), 120, 60)) ta_out(429, array('ok' => false, 'error' => 'کمی صبر کنید'));
    $lk = ta_lock();
    $s = ta_social();
    $bucket = $k === 'like' ? 'likes' : 'dl';
    if (!isset($s[$bucket]) || !is_array($s[$bucket])) $s[$bucket] = array();
    $v = isset($s[$bucket][$i]) ? (int) $s[$bucket][$i] : 0;
    $v = max(0, $v + $d);
    if ($v === 0) unset($s[$bucket][$i]); else $s[$bucket][$i] = $v;
    $s['views'] = (int) (isset($s['views']) ? $s['views'] : 0) + 1;
    ta_put('social.json', $s);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'social' => ta_social_shape()));
}

if ($ACTION === 'comment') {
    $b = ta_body();
    if (isset($b['company']) && trim((string) $b['company']) !== '') ta_out(200, array('ok' => true, 'quiet' => true));  /* زنبور عسل */
    $i = isset($b['i']) ? preg_replace('/[^0-9]/', '', (string) $b['i']) : '';
    $txt = ta_str(isset($b['txt']) ? $b['txt'] : '', 400);
    $who = ta_str(isset($b['n']) ? $b['n'] : '', 24);
    if ($i === '' || $txt === '') ta_out(400, array('ok' => false, 'error' => 'متن خالی است'));
    if (!ta_throttle('cmt:' . ta_ip(), 6, 60)) ta_out(429, array('ok' => false, 'error' => 'زیاد شد — کمی صبر کنید'));
    $lk = ta_lock();
    $s = ta_social();
    if (!isset($s['comments']) || !is_array($s['comments'])) $s['comments'] = array();
    if (!isset($s['comments'][$i]) || !is_array($s['comments'][$i])) $s['comments'][$i] = array();
    $s['comments'][$i][] = array('id' => substr(bin2hex(random_bytes(5)), 0, 8),
                                 'n' => $who !== '' ? $who : 'مهمان', 'txt' => $txt, 'ts' => time() * 1000);
    $mp=ta_privacy_member($b);if($mp!==''){$last=count($s['comments'][$i])-1;$s['comments'][$i][$last]['_owner']=ta_privacy_hash($mp);}
    foreach ($s['comments'] as $kk => $vv) { $s['comments'][$kk] = array_slice($vv, -60); }
    ta_put('social.json', $s);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'comments' => ta_social_shape()['comments'][$i]));
}

if ($ACTION === 'comment_del') {
    $w=ta_need_admin();if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();$i=isset($b['i'])?(string)$b['i']:'';$cid=isset($b['id'])?(string)$b['id']:'';
    if(!preg_match('/^[0-9]{1,8}$/',$i)||!preg_match('/^[A-Za-z0-9_-]{1,80}$/',$cid))ta_out(400,array('ok'=>false,'error'=>'شناسهٔ کامنت معتبر نیست.'));
    $lk=ta_lock();try{$done=ta_comment_change($i,$cid,ta_str(isset($b['txt'])?$b['txt']:'',400),true,isset($w['name'])?$w['name']:$w['u']);}
    catch(Throwable $e){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'ذخیره یا انتشار پاسخ تأیید نشد؛ دوباره بررسی کنید.'));}
    ta_unlock($lk);if(!$done)ta_out(404,array('ok'=>false,'error'=>'کامنت پیدا نشد.'));
    $all=ta_social_shape();ta_out(200,array('ok'=>true,'comments'=>isset($all['comments'][$i])?$all['comments'][$i]:array()));
}

/* ---------- گفتگو و صندوق ---------- */
if ($ACTION === 'send') {
    $b = ta_body();
    if (isset($b['company']) && trim((string) $b['company']) !== '') ta_out(200, array('ok' => true, 'quiet' => true));
    $sid = ta_sane_sid(isset($b['sid']) ? $b['sid'] : '');
    if ($sid === '') $sid = substr(hash('sha256', ta_ip() . microtime() . ta_secret()), 0, 8);
    $txt = ta_str(isset($b['text']) ? $b['text'] : '', 4000);
    $file = (isset($b['file']) && is_array($b['file'])) ? $b['file'] : null;
    if ($txt === '' && !$file) ta_out(400, array('ok' => false, 'error' => 'پیام خالی است'));
    if (!ta_throttle('send:' . ta_ip(), 12, 60)) ta_out(429, array('ok' => false, 'error' => 'چند پیام پشت سر هم فرستادید — یک دقیقه صبر کنید'));
    $lk = ta_lock();
    $box = ta_inbox_all();
    $mid = substr(bin2hex(random_bytes(6)), 0, 10);
    $row = array('mid' => $mid, 'sid' => $sid, 'from' => 'guest', 'text' => $txt, 'ts' => time() * 1000,
                 'to' => ta_str(isset($b['to']) ? $b['to'] : '', 24), 'ip' => ta_ip(), 'ua' => substr(ta_str(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 120), 0, 120));
    $memberPhone=ta_privacy_member($b);if($memberPhone!==''){$row['_owner']=ta_privacy_hash($memberPhone);$row['phone']=$memberPhone;}
    $gname = ta_str(isset($b['name']) ? $b['name'] : '', 60);
    if ($gname !== '') { $row['name'] = $gname; }
    $gphone = ta_digits(isset($b['phone']) ? $b['phone'] : '');
    if ($memberPhone === '' && $gphone !== '' && strlen($gphone) <= 15) { $row['phone'] = $gphone; }
    if ($file) {
        $id=isset($file['id'])?$file['id']:'';$owners=ta_read('upload-owners.json',array());
        if (!isset($owners[$id]) || empty($file['cap']) || !is_string($file['cap']) || !hash_equals($owners[$id]['cap'],hash('sha256',$file['cap']))) { ta_unlock($lk);ta_out(403,array('ok'=>false,'error'=>'مجوز پیوست معتبر نیست؛ فایل را دوباره انتخاب کنید.')); }
        $owners[$id]['sid']=$sid;ta_put('upload-owners.json',$owners);
        $row['file'] = array('id' => ta_str(isset($file['id']) ? $file['id'] : '', 40),
                             'name' => ta_str(isset($file['name']) ? $file['name'] : '', 80),
                             'type' => ta_str(isset($file['type']) ? $file['type'] : '', 40),
                             'size' => isset($file['size']) ? (int) $file['size'] : 0);
    }
    $box[] = $row;
    if (count($box) > 3000) $box = array_slice($box, -2500);
    ta_put('inbox.json', $box);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'mid' => $mid, 'sid' => $sid, 'ts' => $row['ts'],
                      'unread' => ta_unread_count($sid)));
}

/* seen.json = { sid: {a: وقت‌که ادمین خوانده, g: وقت‌که مهمان خوانده} } */
function ta_seen() { return ta_arr(ta_read('seen.json', array())); }
function ta_seen_set($sid, $who, $ts)
{
    if ($sid === '') return;
    $s = ta_seen();
    if (!isset($s[$sid]) || !is_array($s[$sid])) $s[$sid] = array();
    $s[$sid][$who] = max((int) (isset($s[$sid][$who]) ? $s[$sid][$who] : 0), (int) $ts);
    if (count($s) > 2000) $s = array_slice($s, -1500, null, true);
    ta_put('seen.json', $s);
}
function ta_unread_count($sid)
{
    $s = ta_seen();
    $seen = isset($s[$sid]) && is_array($s[$sid]) && isset($s[$sid]['g']) ? (int) $s[$sid]['g'] : 0;
    $n = 0;
    foreach (ta_inbox_all() as $r) {
        if (!is_array($r)) continue;
        if (isset($r['from']) && $r['from'] === 'admin' && isset($r['sid']) && $r['sid'] === $sid && (int) $r['ts'] > $seen) $n++;
    }
    return $n;
}
function ta_unread_for_admin($sid)
{
    $s = ta_seen();
    $seen = isset($s[$sid]) && is_array($s[$sid]) && isset($s[$sid]['a']) ? (int) $s[$sid]['a'] : 0;
    $n = 0;
    foreach (ta_inbox_all() as $r) {
        if (!is_array($r)) continue;
        if (isset($r['from']) && $r['from'] !== 'admin' && isset($r['sid']) && $r['sid'] === $sid && (int) $r['ts'] > $seen) $n++;
    }
    return $n;
}

if ($ACTION === 'thread') {
    $sid = ta_sane_sid(isset($_GET['sid']) ? $_GET['sid'] : '');
    if ($sid === '') ta_out(400, array('ok' => false, 'error' => 'sid لازم است'));
    $out = array();
    foreach (ta_inbox_all() as $r) {
        if (!is_array($r) || !isset($r['sid']) || $r['sid'] !== $sid) continue;
        if (isset($r['from']) && $r['from'] !== 'admin') continue;   /* فقط پاسخ‌های ادمین */
        $row = array('mid' => $r['mid'], 'text' => $r['text'], 'ts' => $r['ts'], 'from' => 'them',
                     'name' => isset($r['name']) ? $r['name'] : 'تیتانلی');
        if (!empty($r['file']) && is_array($r['file'])) {
            $row['file'] = array('name' => $r['file']['name'], 'type' => $r['file']['type'],
                                 'size' => $r['file']['size'], 'url' => 'api.php?action=file&f=' . rawurlencode($r['file']['id']));
        }
        $out[] = $row;
    }
    $max = 0;
    foreach ($out as $o) { if ((int) $o['ts'] > $max) $max = (int) $o['ts']; }
    if ($max) ta_seen_set($sid, 'g', $max);
    ta_out(200, array('ok' => true, 'messages' => $out, 'unread' => 0));
}

if ($ACTION === 'inbox') {
    $w = ta_need_admin();
    $threads = array();
    $seenAll = ta_seen();
    foreach (ta_inbox_all() as $r) {
        if (!is_array($r) || !isset($r['sid'])) continue;
        $sid = $r['sid'];
        if (!isset($threads[$sid])) $threads[$sid] = array('sid' => $sid, 'n' => 0, 'last' => 0, 'items' => array(), 'unread' => 0,
                                                            'name' => '', 'phone' => '', 'imgs' => 0, 'answered' => 0);
        $threads[$sid]['n']++;
        $threads[$sid]['last'] = max($threads[$sid]['last'], (int) $r['ts']);
        if (count($threads[$sid]['items']) < 40) $threads[$sid]['items'][] = $r;
        if (isset($r['from']) && $r['from'] !== 'admin') {
            $seen = isset($seenAll[$sid]) && is_array($seenAll[$sid]) && isset($seenAll[$sid]['a']) ? (int) $seenAll[$sid]['a'] : 0;
            if ((int) $r['ts'] > $seen) $threads[$sid]['unread']++;
            if ($threads[$sid]['name'] === '' && isset($r['name'])) $threads[$sid]['name'] = $r['name'];
            if ($threads[$sid]['phone'] === '' && isset($r['phone'])) $threads[$sid]['phone'] = $r['phone'];
            if (!empty($r['file']) && is_array($r['file'])
                && preg_match('#^image/#', (string) (isset($r['file']['type']) ? $r['file']['type'] : ''))) $threads[$sid]['imgs']++;
        } else {
            $threads[$sid]['answered']++;
        }
    }
    foreach ($threads as $k => $v) {
        $t = $v['items'];
        usort($t, 'ta_cmp_ts');
        $threads[$k]['items'] = $t;
        $threads[$k]['unreadForAdmin'] = ta_unread_for_admin($v['sid']);
        if (isset($WM[$v['sid']]) && is_array($WM[$v['sid']])) {   /* اصلاحیهٔ ادمین: نام/شمارهٔ درست‌تر */
            if ($WM[$v['sid']]['name'] !== '') { $threads[$k]['name'] = $WM[$v['sid']]['name']; }
            if ($WM[$v['sid']]['phone'] !== '') { $threads[$k]['phone'] = $WM[$v['sid']]['phone']; }
        }
    }
    $WM = ta_who_map();
    usort($threads, 'ta_cmp_last');
    $nu = 0;
    foreach ($threads as $v) { $nu += $v['unreadForAdmin']; }
    ta_out(200, array('ok' => true, 'threads' => array_values($threads), 'total' => count(ta_inbox_all()), 'unread' => $nu));
}

/* رقم‌های فارسی/عربی به لاتین، سپس حذف هر چه رقم نیست */
function ta_digits($v)
{
    $v = (string) $v;
    $v = strtr($v, array("\xD9\xA0" => '0', "\xD9\xA1" => '1', "\xD9\xA2" => '2', "\xD9\xA3" => '3', "\xD9\xA4" => '4',
                         "\xD9\xA5" => '5', "\xD9\xA6" => '6', "\xD9\xA7" => '7', "\xD9\xA8" => '8', "\xD9\xA9" => '9',
                         "\xD6\xB0" => '0', "\xD6\xB1" => '1', "\xD6\xB2" => '2', "\xD6\xB3" => '3', "\xD6\xB4" => '4',
                         "\xD6\xB5" => '5', "\xD6\xB6" => '6', "\xD6\xB7" => '7', "\xD6\xB8" => '8', "\xD6\xB9" => '9'));
    return preg_replace('/[^0-9]/', '', $v);
}
function ta_cmp_ts($a, $b) { return (int) $a['ts'] === (int) $b['ts'] ? 0 : ((int) $a['ts'] < (int) $b['ts'] ? -1 : 1); }
function ta_cmp_last($a, $b) { return (int) $b['last'] === (int) $a['last'] ? 0 : ((int) $b['last'] < (int) $a['last'] ? -1 : 1); }

if ($ACTION === 'reply') {
    $w = ta_need_admin();
    $b = ta_body();
    $sid = ta_sane_sid(isset($b['sid']) ? $b['sid'] : '');
    $txt = ta_str(isset($b['text']) ? $b['text'] : '', 4000);
    if ($sid === '' || $txt === '') ta_out(400, array('ok' => false, 'error' => 'sid و text لازم است'));
    $lk = ta_lock();
    $box = ta_inbox_all();
    $mid = substr(bin2hex(random_bytes(6)), 0, 10);
    $row = array('mid' => $mid, 'sid' => $sid, 'from' => 'admin', 'name' => $w['name'], 'text' => $txt, 'ts' => time() * 1000 + 1);
    if (!empty($b['file']) && is_array($b['file'])) $row['file'] = $b['file'];
    $box[] = $row;
    ta_put('inbox.json', $box);
    ta_unlock($lk);
    ta_seen_set($sid, 'a', $row['ts']);      /* ادمین که جواب داد، یعنی خوانده */
    ta_out(200, array('ok' => true, 'mid' => $mid, 'ts' => $row['ts']));
}

if ($ACTION === 'read') {
    $w = ta_need_admin();
    $b = ta_body();
    $sid = ta_sane_sid(isset($b['sid']) ? $b['sid'] : '');
    $t = 0;
    foreach (ta_inbox_all() as $r) { if (is_array($r) && isset($r['sid']) && $r['sid'] === $sid) $t = max($t, (int) $r['ts']); }
    ta_seen_set($sid, 'a', $t + 1);
    ta_out(200, array('ok' => true, 'unread' => ta_unread_for_admin($sid)));
}

if ($ACTION === 'thread_del') {
    $w = ta_need_admin();
    $b = ta_body();
    $sid = ta_sane_sid(isset($b['sid']) ? $b['sid'] : '');
    $lk = ta_lock();
    $keep = array();
    foreach (ta_inbox_all() as $r) { if (is_array($r) && isset($r['sid']) && $r['sid'] !== $sid) $keep[] = $r; }
    ta_put('inbox.json', $keep);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'total' => count($keep)));
}

/* ---------- هویت کاربر: نام و شمارهٔ تلفن (لایهٔ اصلاحی ادمین) ----------
   پیام‌های کاربر دست‌نخورده می‌مانند؛ اصلاحیه در who.json نشسته و هنگام خواندن صندوق رویش می‌آید. */
function ta_who_map()
{
    $m = ta_read('who.json', array());
    $out = array();
    if (!is_array($m)) { return $out; }
    foreach ($m as $k => $v) {
        if (is_array($v)) { $out[$k] = array('name' => (string) (isset($v['name']) ? $v['name'] : ''),
                                             'phone' => (string) (isset($v['phone']) ? $v['phone'] : '')); }
    }
    return $out;
}

if ($ACTION === 'who') {
    $w  = ta_need_admin();
    $b  = ta_body();
    $sid = ta_sane_sid(isset($b['sid']) ? $b['sid'] : '');
    if ($sid === '') ta_out(400, array('ok' => false, 'error' => 'sid لازم است'));
    $nm = ta_str(isset($b['name']) ? $b['name'] : '', 60);
    $ph = substr(ta_digits(isset($b['phone']) ? $b['phone'] : ''), 0, 15);
    $lk = ta_lock();
    $map = ta_read('who.json', array());
    if (!is_array($map)) { $map = array(); }
    if ($nm === '' && $ph === '') {
        unset($map[$sid]);
    } else {
        $map[$sid] = array('name' => $nm, 'phone' => $ph, 'at' => time(), 'by' => $w['name']);
    }
    if (count($map) > 5000) { $map = array_slice($map, -5000, null, true); }
    ta_put('who.json', $map);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'sid' => $sid, 'name' => $nm, 'phone' => $ph));
}

/* ---------- فایل‌ها ---------- */
/* Public design images use an authenticated, idempotent and validated media path.
 * They are not private chat attachments and never belong to a member erasure ledger. */
if ($ACTION === 'design_upload') {
    ta_need_admin();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();$raw=base64_decode(isset($b['data'])&&is_string($b['data'])?$b['data']:'',true);
    ta_out(200,ta_design_store($raw));
}
if ($ACTION === 'publication_check') {
    ta_need_admin();
    if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();$lk=ta_lock();$rev=ta_rev();$path=ta_publish_path();$public=$path!==''?json_decode((string)@file_get_contents($path),true):null;$data=ta_read('content.json',null);
    if(!isset($b['rev'])||(int)$b['rev']!==$rev){ta_unlock($lk);ta_out(409,array('ok'=>false,'conflict'=>true,'rev'=>$rev,'error'=>'نسخهٔ تازه‌تری روی سرور است؛ پیش‌نویس محفوظ است.'));}
    if(!$public||!isset($public['rev'])||(int)$public['rev']!==$rev||ta_sections_of($public['data'])!==ta_sections_of($data)){ta_unlock($lk);ta_out(500,array('ok'=>false,'rev'=>$rev,'error'=>'نسخهٔ عمومی با ذخیرهٔ سرور یکسان نیست.'));}
    $urls=array();foreach(isset($data['gallery'])?$data['gallery']:array() as $g){if(!empty($g['img']))$urls[]=$g['img'];if(isset($g['imgs'])&&is_array($g['imgs']))$urls=array_merge($urls,$g['imgs']);}
    foreach(isset($data['cats'])&&is_array($data['cats'])?$data['cats']:array() as $cat){if(!empty($cat['menuImage']))$urls[]=$cat['menuImage'];}foreach(isset($data['settings']['homeMenu']['items'])&&is_array($data['settings']['homeMenu']['items'])?$data['settings']['homeMenu']['items']:array() as $item){if(!empty($item['image']))$urls[]=$item['image'];}
    if(!empty($data['profile']['avatar']))$urls[]=$data['profile']['avatar'];if(!empty($data['settings']['bg']))$urls[]=$data['settings']['bg'];if(!empty($data['settings']['watermark']['image']))$urls[]=$data['settings']['watermark']['image'];$count=0;
    foreach(array_unique($urls) as $u){
        if(strpos($u,'data:image/')===0){ta_unlock($lk);ta_out(422,array('ok'=>false,'rev'=>$rev,'error'=>'تصویر هنوز روی هاست ذخیره نشده است.'));}
        if(preg_match('/^api\.php\?action=file&f=([A-Za-z0-9._-]{8,64})$/',$u,$m)){
            $file=ta_cfg()['dataDir'].'/uploads/'.$m[1];$image=@getimagesize($file);
            if(!is_file($file)||!is_readable($file)||!$image){ta_unlock($lk);ta_out(500,array('ok'=>false,'rev'=>$rev,'error'=>'یکی از تصاویر منتشرشده روی هاست در دسترس نیست.'));}
            if(preg_match('/^design-([a-f0-9]{48})\.(jpg|png|webp)$/',$m[1],$digest)&&substr((string)@hash_file('sha256',$file),0,48)!==$digest[1]){ta_unlock($lk);ta_out(500,array('ok'=>false,'rev'=>$rev,'error'=>'بایت‌های یکی از تصاویر منتشرشده با اثر انگشت فایل یکسان نیست.'));}
            $count++;
        }
    }
    ta_unlock($lk);ta_out(200,array('ok'=>true,'rev'=>$rev,'mediaChecked'=>$count,'sections'=>ta_sections_of($data)));
}

if ($ACTION === 'upload') {
    $b = ta_body();
    $mime = isset($b['type']) ? (string) $b['type'] : '';
    if (!$AUTH && !in_array($mime, array('image/jpeg', 'image/png', 'image/webp'), true)) {
        ta_out(415, array('ok' => false, 'error' => 'مهمان فقط می‌تواند jpeg/png/webp بفرستد'));
    }
    if (!$AUTH && !ta_throttle('upl:' . ta_ip(), 12, 600)) {
        ta_out(429, array('ok' => false, 'error' => 'محدودیت بارگذاری — کمی بعداً تلاش کنید'));
    }
    $r = ta_store_file(isset($b['name']) ? $b['name'] : '', $mime, isset($b['data']) ? $b['data'] : '');
    if (empty($r['ok'])) ta_out(400, $r);
    $lk=ta_lock();$owners=ta_read('upload-owners.json',array());$cap=bin2hex(random_bytes(24));$mp=ta_privacy_member($b);
    $owners[$r['id']]=array('owner'=>$mp!==''?ta_privacy_hash($mp):'','cap'=>hash('sha256',$cap),'at'=>time());ta_put('upload-owners.json',$owners);ta_unlock($lk);$r['cap']=$cap;
    ta_out(200, $r);
}

if ($ACTION === 'file') {
    $f = basename(isset($_GET['f']) ? (string) $_GET['f'] : '');
    if (!preg_match('/^[A-Za-z0-9._-]{8,64}$/', $f)) ta_out(400, array('ok' => false, 'error' => 'نام فایل نامعتبر است'));
    if(strpos($f,'group-')===0)ta_out(403,array('ok'=>false,'error'=>'پیوست گروه فقط برای اعضای پیوسته قابل دریافت است.'));
    $path = ta_cfg()['dataDir'] . '/uploads/' . $f;
    if (!is_file($path)) ta_out(404, array('ok' => false, 'error' => 'فایل پیدا نشد'));
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $mime = 'application/octet-stream';
    foreach (ta_types() as $m => $e) { if ($e === $ext) { $mime = $m; break; } }
    $dl = !empty($_GET['dl']);
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: ' . ($dl ? 'attachment' : 'inline') . '; filename="' . $f . '"');
    header('Content-Security-Policy: default-src \'none\'');
    readfile($path);
    exit;
}

/* ---------- ادمین‌ها، ورودی/خروجی ---------- */
if ($ACTION === 'admins') {
    $w = ta_need_admin();
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $out = array();
        foreach (ta_users() as $a) { $out[] = array('u' => $a['u'], 'name' => isset($a['name']) ? $a['name'] : $a['u'], 'role' => isset($a['role']) ? $a['role'] : 'admin'); }
        ta_out(200, array('ok' => true, 'admins' => $out));
    }
    $b = ta_body();
    $op = isset($b['op']) ? (string) $b['op'] : '';
    $lk = ta_lock();
    $users = ta_users();
    $byU = array();
    foreach ($users as $k => $a) { $byU[$a['u']] = $k; }
    if ($op === 'add') {
        $u = ta_str(isset($b['u']) ? $b['u'] : '', 32);
        $p = isset($b['p']) ? (string) $b['p'] : '';
        if (strlen($u) < 3 || strlen($p) < 8) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'نام کاربری ۳+ و رمز ۸+ کاراکتر')); }
        if (isset($byU[$u])) { ta_unlock($lk); ta_out(409, array('ok' => false, 'error' => 'این نام کاربری هست')); }
        $users[] = array('u' => $u, 'p' => ta_hash_pw($p), 'name' => ta_str(isset($b['name']) ? $b['name'] : '', 40, false) ?: $u, 'role' => 'admin');
    } elseif ($op === 'remove') {
        $u = ta_str(isset($b['u']) ? $b['u'] : '', 32);
        if (count($users) <= 1) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'آخرین ادمین حذف نمی‌شود')); }
        if ($u === $w['u']) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'از خودتان نمی‌توانید خارج شوید')); }
        if (!isset($byU[$u])) { ta_unlock($lk); ta_out(404, array('ok' => false, 'error' => 'پیدا نشد')); }
        unset($users[$byU[$u]]);
        $users = array_values($users);
        $tk = ta_read('tokens.json', array()); unset($tk[$u]); ta_put('tokens.json', $tk);
    } elseif ($op === 'pw') {
        $u = ta_str(isset($b['u']) ? $b['u'] : $w['u'], 32);
        $p = isset($b['p']) ? (string) $b['p'] : '';
        if (strlen($p) < 8) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'رمز جدید حداقل ۸ کاراکتر')); }
        if (!isset($byU[$u])) { ta_unlock($lk); ta_out(404, array('ok' => false, 'error' => 'پیدا نشد')); }
        $users[$byU[$u]]['p'] = ta_hash_pw($p);
    } elseif ($op === 'name') {
        $u = ta_str(isset($b['u']) ? $b['u'] : $w['u'], 32);
        if (!isset($byU[$u])) { ta_unlock($lk); ta_out(404, array('ok' => false, 'error' => 'پیدا نشد')); }
        $users[$byU[$u]]['name'] = ta_str(isset($b['name']) ? $b['name'] : '', 40) ?: $u;
    } else { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'op نامعتبر است')); }
    if (!ta_put('config.json', array_merge(ta_conf(), array('users' => array_values($users))))) {
        ta_unlock($lk); ta_out(500, array('ok' => false, 'error' => 'نوشتن نشد'));
    }
    ta_unlock($lk);
    $out = array();
    foreach (array_values($users) as $a) { $out[] = array('u' => $a['u'], 'name' => isset($a['name']) ? $a['name'] : $a['u'], 'role' => isset($a['role']) ? $a['role'] : 'admin'); }
    ta_out(200, array('ok' => true, 'admins' => $out));
}

if ($ACTION === 'export') {
    $w = ta_need_admin();
    ta_out(200, array('ok' => true, 'app' => 'titanali', 'ver' => TA_VER, 'at' => time(),
                      'rev' => ta_rev(),
                      'data' => ta_read('content.json', null),
                      'social' => ta_social_shape(),
                      'inbox' => ta_inbox_all(),
                      'log' => ta_read('log.json', array())));
}

if ($ACTION === 'import') {
    $w = ta_need_admin();
    $b = ta_body();
    $lk = ta_lock();
    try { foreach(array('data'=>'content.json','social'=>'social.json','inbox'=>'inbox.json') as $k=>$rel) if(isset($b[$k])) ta_privacy_restore_guard($rel,$b[$k]); } catch(Exception $e){ta_unlock($lk);ta_out(409,array('ok'=>false,'error'=>$e->getMessage()));}
    $stamp = date('Ymd-His');
    $bak = array('content' => ta_read('content.json', null), 'social' => ta_social(), 'inbox' => ta_inbox_all());
    ta_put('backups/backup-' . $stamp . '.json', $bak);
    $bl = ta_read('backups/list.json', array());
    $bl[] = $stamp;
    ta_put('backups/list.json', array_slice($bl, -10));
    foreach (glob(ta_cfg()['dataDir'] . '/backups/backup-*.json') as $old) {
        $all = glob(ta_cfg()['dataDir'] . '/backups/backup-*.json');
        if (count($all) > 10) { @unlink($old); }
    }
    if (isset($b['data']) && is_array($b['data'])) ta_put('content.json', $b['data']);
    if (isset($b['social']) && is_array($b['social'])) ta_put('social.json', $b['social']);
    if (isset($b['inbox']) && is_array($b['inbox'])) ta_put('inbox.json', $b['inbox']);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'backup' => $stamp, 'rev' => ta_rev()));
}

if ($ACTION === 'stats') {
    $s = ta_social();
    $like = 0; $dl = 0;
    foreach (ta_arr($s['likes']) as $v) { $like += (int) $v; }
    foreach (ta_arr($s['dl']) as $v) { $dl += (int) $v; }
    ta_out(200, array('ok' => true, 'stats' => array('likes' => $like, 'dl' => $dl,
        'views' => isset($s['views']) ? (int) $s['views'] : 0,
        'comments' => isset($s['comments']) ? count($s['comments']) : 0,
        'messages' => count(ta_inbox_all()), 'rev' => ta_rev())));
}

/* =====================================================================
 *  انتشار دستی: POST api.php?action=publish   body: {"data":…,"baseRev":n}
 *  وضعیت سرور: GET api.php?action=state        (فقط ادمین)
 *  نمونهٔ منتشرشده (عمومی، با ETag): GET api.php?action=baked
 * ===================================================================== */
if ($ACTION === 'publish') {
    $w = ta_need_admin();
    $b = ta_body();
    $data = isset($b['data']) ? $b['data'] : null;
    if (!is_array($data) || count($data) < 1) ta_out(400, array('ok' => false, 'error' => 'data لازم است'));
    $lk = ta_lock();
    $cur = ta_rev();
    if (isset($b['baseRev']) && (int) $b['baseRev'] !== $cur) {
        ta_unlock($lk);
        ta_out(409, array('ok' => false, 'conflict' => true, 'rev' => $cur, 'data' => ta_read('content.json', null),
                          'error' => 'نسخهٔ سرور عوض شده؛ دوباره «گرفتن از سرور» را بزنید'));
    }
    if(isset($data['messages'])&&is_array($data['messages']))$data['messages']=array_values(array_filter($data['messages'],function($m){try{ta_privacy_restore_guard('inbox.json',array($m));return true;}catch(Exception $e){return false;}}));
    if (!ta_put('content.json', $data)) { ta_unlock($lk); ta_out(500, array('ok' => false, 'error' => 'نوشتن نشد')); }
    $newRev = ta_bump();
    $pub = ta_bake($data, $newRev, $w['u']);
    ta_note_publish($pub, $w['u'], $newRev);
    ta_unlock($lk);
    ta_out(isset($pub['error']) ? 500 : 200, array('ok' => !isset($pub['error']), 'rev' => $newRev, 'publish' => $pub, 'sections' => ta_sections_of($data),
        'error' => isset($pub['error']) ? 'محتوا ذخیره شد ولی فایل عمومی نوشته نشد؛ دسترسی نوشتن و publishFile را بررسی کنید.' : ''));
}

if ($ACTION === 'state') {
    $w = ta_need_admin();
    $c = ta_cfg();
    $m = ta_meta();
    $d = ta_read('content.json', null);
    $up = array('files' => 0, 'bytes' => 0);
    $dir = $c['dataDir'] . '/uploads';
    if (is_dir($dir)) {
        foreach ((array) glob($dir . '/*') as $f) { if (is_file($f)) { $up['files']++; $up['bytes'] += (int) @filesize($f); } }
    }
    ta_out(200, array('ok' => true, 'who' => $w['u'], 'rev' => ta_rev(),
                      'updated' => isset($m['updated']) ? (int) $m['updated'] : 0,
                      'publish' => isset($m['publish']) ? $m['publish'] : null,
                      'baked' => ta_baked_info(),
                      'hash' => ta_hash_of($d),
                      'sections' => ta_sections_of($d),
                      'uploads' => $up,
                      'inbox' => count(ta_inbox_all()),
                      'log' => array_slice(ta_read('log.json', array()), -14),
                      'counts' => array('gallery' => count(ta_arr(isset($d['gallery']) ? $d['gallery'] : array())),
                                        'cats' => count(ta_arr(isset($d['cats']) ? $d['cats'] : array())),
                                        'contacts' => count(ta_arr(isset($d['contacts']) ? $d['contacts'] : array())),
                                        'admins' => count(ta_users()))));
}

if ($ACTION === 'baked') {
    $abs = ta_publish_path();
    $raw = ($abs === '') ? false : @file_get_contents($abs);
    if (is_string($raw) && $raw !== '') {
        $etag = '"' . md5($raw) . '"';
        if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim((string) $_SERVER['HTTP_IF_NONE_MATCH']) === $etag) {
            // ۳۰۴ نباید بدنه داشته باشد؛ برای همین ta_out صدا نمی‌شود.
            @http_response_code(304);
            @header('ETag: ' . $etag);
            @header('Cache-Control: public, max-age=60, must-revalidate');
            @header('X-Content-Type-Options: nosniff');
            exit;
        }
        if (!headers_sent()) {
            @header('Content-Type: application/json; charset=utf-8');
            @header('ETag: ' . $etag);
            @header('Cache-Control: public, max-age=60, must-revalidate');
        }
        echo $raw;
        exit;
    }
    ta_out(200, ta_payload(true) + array('baked' => false));
}

/* ---------- پاسخ ادمین به کامنت طرح‌ها ---------- */
if ($ACTION === 'comment_reply') {
    $w=ta_need_admin();if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();$i=isset($b['i'])?(string)$b['i']:'';$cid=isset($b['id'])?(string)$b['id']:'';
    if(!preg_match('/^[0-9]{1,8}$/',$i)||!preg_match('/^[A-Za-z0-9_-]{1,80}$/',$cid))ta_out(400,array('ok'=>false,'error'=>'شناسهٔ کامنت معتبر نیست.'));
    $lk=ta_lock();try{$done=ta_comment_change($i,$cid,ta_str(isset($b['txt'])?$b['txt']:'',400),false,isset($w['name'])?$w['name']:$w['u']);}
    catch(Throwable $e){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'ذخیره یا انتشار پاسخ تأیید نشد؛ دوباره بررسی کنید.'));}
    ta_unlock($lk);if(!$done)ta_out(404,array('ok'=>false,'error'=>'کامنت پیدا نشد.'));
    $all=ta_social_shape();ta_out(200,array('ok'=>true,'comments'=>isset($all['comments'][$i])?$all['comments'][$i]:array()));
}

if ($ACTION === 'comments') {
    $w = ta_need_admin();
    $s = ta_social();
    $cn = ta_comments_all();
    $cont = ta_read('content.json', null);
    $gal = (is_array($cont) && isset($cont['gallery']) && is_array($cont['gallery'])) ? $cont['gallery'] : array();
    $out = array();
    foreach ($cn as $k => $list) {
        if (!is_array($list)) continue;
        $title = isset($gal[$k]['t']) ? (string) $gal[$k]['t'] : ('طرح ' . (string) ((int) $k + 1));
        foreach ($list as $c) {
            if (!is_array($c)) continue;
            $out[] = array('i' => (int) $k, 'title' => ta_str($title,60),
                           'id' => isset($c['id']) ? $c['id'] : '', 'n' => isset($c['n']) ? $c['n'] : 'مهمان',
                           'txt' => isset($c['txt']) ? (string) $c['txt'] : '', 'ts' => isset($c['ts']) ? (int) $c['ts'] : 0,
                           'r' => (isset($c['r']) && is_array($c['r'])) ? $c['r'] : null);
        }
    }
    usort($out, function ($a, $b) { return $b['ts'] <=> $a['ts']; });
    ta_out(200, array('ok' => true, 'list' => array_slice($out, 0, 240), 'n' => count($out),
                      'open' => count(array_filter($out, function ($x) { return !$x['r']; }))));
}

/* ---------- ثبت‌نام کاربر با شماره تلفن ---------- */
if ($ACTION === 'reg_start') {
    if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    if(!ta_registration_allow('phone'))ta_out(403,array('ok'=>false,'error'=>'روش شماره در تنظیمات ثبت‌نام غیرفعال است.'));
    $b = ta_body();
    $phone = ta_norm_phone(isset($b['phone']) ? $b['phone'] : '');
    if (!ta_ok_phone($phone)) ta_out(400, array('ok' => false, 'error' => 'شمارهٔ موبایل درست نیست (۰۹xxxxxxxxx)'));
    if (!ta_throttle('reg:' . ta_ip(), 4, 600)) ta_out(429, array('ok' => false, 'error' => 'زیاد شد — ۱۰ دقیقه صبر کنید'));
    if (!ta_throttle('regp:' . $phone, 3, 300)) ta_out(429, array('ok' => false, 'error' => 'برای این شماره زیاد شد — چند دقیقه صبر کنید'));
    $cfg = ta_sms_cfg();
    if (in_array($cfg['prov'],array('none','demo'),true)) ta_out(409, array('ok' => false, 'error' => 'ورود با پیامک روی این سایت فعال نیست (ادمین باید پنل پیامک را انتخاب کند)'));
    $code = (string) random_int(10000, 99999);
    $lk = ta_lock();
    $o = ta_otp_get();
    $o[$phone] = array('c' => $code, 'at' => time(), 'try' => 0, 'name' => ta_str(isset($b['name']) ? $b['name'] : '', 32));
    foreach ($o as $k => $v) { if (!is_array($v) || (isset($v['at']) && $v['at'] < time() - 1800)) unset($o[$k]); }
    ta_otp_put($o);
    ta_unlock($lk);
    $tx = 'کد تأیید تیتانلی: ' . $code;   /* در پنل دلخواه می‌توانید از {text} و {code} در آدرس استفاده کنید */
    $r = ta_sms_send($phone, $tx);
    $res = array('ok' => (bool) $r['ok'], 'phone' => $phone, 'msg' => isset($r['msg']) ? $r['msg'] : '',
                 'need' => 'کد ۵ رقمی را وارد کنید');
    if (!$r['ok']) $res['error'] = 'پیامک نرفت: ' . (isset($r['msg']) ? $r['msg'] : 'خطای سرور پیامک');
    ta_out($r['ok'] ? 200 : 502, $res);
}

if ($ACTION === 'reg_verify') {
    if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    if(!ta_registration_allow('phone'))ta_out(403,array('ok'=>false,'error'=>'روش شماره در تنظیمات ثبت‌نام غیرفعال است.'));
    $b = ta_body();
    $phone = ta_norm_phone(isset($b['phone']) ? $b['phone'] : '');
    $code = preg_replace('/[^0-9]/', '', (string) (isset($b['code']) ? $b['code'] : ''));
    if (!ta_ok_phone($phone) || strlen($code) < 4) ta_out(400, array('ok' => false, 'error' => 'شماره یا کد کامل نیست'));
    if (!ta_throttle('regv:' . $phone, 8, 600)) ta_out(429, array('ok' => false, 'error' => 'تلاش زیاد — ۱۰ دقیقه صبر کنید'));
    $lk = ta_lock();
    $o = ta_otp_get();
    if (!isset($o[$phone]) || !is_array($o[$phone])) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'کدی فعال نیست — دوباره درخواست بدهید')); }
    if ($o[$phone]['at'] < time() - 300) { unset($o[$phone]); ta_otp_put($o); ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'کد منقضی شد — دوباره بخواهید')); }
    if ((int) $o[$phone]['try'] >= 6) { ta_unlock($lk); ta_out(429, array('ok' => false, 'error' => 'چند بار اشتباه زدیت — چند دقیقه صبر کنید')); }
    if ((string) $o[$phone]['c'] !== $code) {
        $o[$phone]['try'] = (int) $o[$phone]['try'] + 1; ta_otp_put($o); ta_unlock($lk);
        ta_out(400, array('ok' => false, 'error' => 'کد درست نیست'));
    }
    unset($o[$phone]); ta_otp_put($o);
    $name = ta_str(isset($b['name']) ? $b['name'] : '', 32);
    $m = ta_members();
    $list = isset($m['list']) && is_array($m['list']) ? $m['list'] : array();
    $now = time();
    $found = -1;
    foreach ($list as $n => $u) { if (isset($u['phone']) && $u['phone'] === $phone) { $found = $n; break; } }
    if ($found >= 0) {
        if(!empty($list[$found]['off'])){ta_unlock($lk);ta_out(403,array('ok'=>false,'error'=>'این حساب توسط مدیریت غیرفعال شده است.'));}
        $list[$found]['off'] = 0;
        if ($name !== '') $list[$found]['name'] = $name;
        $list[$found]['seen'] = $now;
    } else {
        if ($name === '') $name = 'کاربر ' . substr($phone, -4);
        $list[] = array('phone' => $phone, 'name' => $name, 'ts' => $now, 'seen' => $now, 'off' => 0);
    }
    foreach($list as $n=>$u) if(isset($u['phone'])&&$u['phone']===$phone&&empty($u['auth'])) $list[$n]['auth']=bin2hex(random_bytes(24));
    $m['list'] = $list; ta_put('users.json', $m);
    ta_unlock($lk);
    ta_out(200, array('ok' => true, 'phone' => $phone, 'name' => $name, 'tok' => ta_member_tok($phone),
                      'msg' => 'شماره‌ات تأیید شد ✓'));
}

if ($ACTION === 'me') {
    $b = ta_body();
    $phone = ta_identity(isset($b['phone']) ? $b['phone'] : '');
    $tok = preg_replace('/[^a-f0-9]/', '', (string) (isset($b['tok']) ? $b['tok'] : ''));
    if ($phone === '' || $tok === '') ta_out(400, array('ok' => false));
    foreach (ta_member_list() as $u) {
        if (isset($u['phone']) && $u['phone'] === $phone && empty($u['off']) && $tok === ta_member_tok($phone)) {
            ta_out(200, array('ok' => true, 'phone' => $phone, 'name' => isset($u['name']) ? $u['name'] : '', 'since' => (int) $u['ts'], 'provider'=>isset($u['provider'])?$u['provider']:'phone', 'email'=>isset($u['email'])?$u['email']:''));
        }
    }
    ta_out(401, array('ok' => false, 'error' => 'این شماره عضو نیست یا نشستش باطل شده'));
}

if ($ACTION === 'members') {
    $w = ta_need_admin();
    $method=$_SERVER['REQUEST_METHOD'];if(!in_array($method,array('GET','POST'),true))ta_out(405,array('ok'=>false,'error'=>'GET or POST required'));
    $b = $method==='GET'?array():ta_body();
    $op = isset($b['op']) ? preg_replace('/[^a-z_]/', '', (string) $b['op']) : 'list';
    $phone = ta_identity(isset($b['phone']) ? $b['phone'] : '');
    $lk = ta_lock();
    $m = ta_members();
    $list = isset($m['list']) && is_array($m['list']) ? $m['list'] : array();
    if ($op === 'off' || $op === 'on' || $op === 'del') {
        if (!ta_identity_ok($phone)) { ta_unlock($lk); ta_out(400, array('ok' => false, 'error' => 'شناسهٔ حساب لازم است')); }
        foreach ($list as $n => $u) {
            if (!isset($u['phone']) || $u['phone'] !== $phone) continue;
            if ($op === 'del') unset($list[$n]);
            else $list[$n]['off'] = ($op === 'off') ? 1 : 0;
        }
        $m['list'] = array_values($list); ta_put('users.json', $m);
    }
    ta_unlock($lk);
    $public=$m['list'];foreach($public as $i=>$u)unset($public[$i]['auth']);
    ta_out(200, array('ok' => true, 'list' => $public, 'n' => count($public)));
}

/* ---------- تنظیمات پنل پیامک ---------- */
if ($ACTION === 'sms') {
    $w=ta_need_admin();$method=$_SERVER['REQUEST_METHOD'];
    if(!in_array($method,array('GET','POST'),true))ta_out(405,array('ok'=>false,'error'=>'فقط خواندن یا ذخیرهٔ صریح مجاز است.'));
    $b=$method==='GET'?array():ta_body();
    if(!$b){$c=ta_sms_cfg();ta_out(200,array('ok'=>true,'cfg'=>array('prov'=>$c['prov'],'key'=>'','user'=>$c['user'],'from'=>$c['from'],'tpl'=>$c['tpl'],'debug'=>(int)$c['debug'],'keySet'=>$c['key']!==''),'provs'=>ta_sms_provs_names(),'lastTry'=>ta_read('smslog.json',array())));}
    $P=ta_sms_provs();
    if(isset($b['prov'])&&(!is_string($b['prov'])||!isset($P[$b['prov']])))ta_out(400,array('ok'=>false,'error'=>'پنل انتخاب‌شده معتبر نیست؛ تنظیمات قبلی تغییر نکرد.'));
    $lk=ta_lock();$c=ta_sms_cfg();
    if(isset($b['prov']))$c['prov']=$b['prov'];
    foreach(array('user','from','tpl') as $k)if(isset($b[$k]))$c[$k]=ta_str($b[$k],160,true);
    if(isset($b['key'])&&is_string($b['key'])&&trim($b['key'])!==''&&trim($b['key'])!=='••••')$c['key']=ta_str($b['key'],160,true);
    if(isset($b['debug']))$c['debug']=!empty($b['debug'])?1:0;
    if(!ta_put('sms.json',$c)){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'ذخیرهٔ تنظیمات پیامک روی هاست تأیید نشد.'));}
    ta_unlock($lk);ta_out(200,array('ok'=>true,'msg'=>'تنظیمات پیامک ذخیره شد ✓','prov'=>$c['prov'],'keySet'=>$c['key']!==''));
}

if ($ACTION === 'sms_test') {
    $w = ta_need_admin();
    $b = ta_body();
    $to = ta_norm_phone(isset($b['to']) ? $b['to'] : '');
    if (!ta_ok_phone($to)) ta_out(400, array('ok' => false, 'error' => 'شمارهٔ مقصد درست نیست'));
    $r = ta_sms_send($to, 'تیتانلی — آزمایش اتصال پنل پیامک ✓');
    $lg = ta_read('smslog.json', array());
    $lg[] = array('to' => $to, 'at' => time(), 'ok' => (bool) $r['ok'], 'msg' => isset($r['msg']) ? $r['msg'] : '',
                  'body' => isset($r['body']) ? ta_str($r['body'],240,true) : '');
    ta_put('smslog.json', array_slice($lg, -12));
    ta_out($r['ok'] ? 200 : 502, array('ok' => (bool) $r['ok'], 'msg' => isset($r['msg']) ? $r['msg'] : '',
                                       'body' => isset($r['body']) ? ta_str($r['body'],400,true) : ''));
}

ta_out(404, array('ok' => false, 'error' => 'endpoint ناشناخته', 'action' => $ACTION, 'ver' => TA_VER));
