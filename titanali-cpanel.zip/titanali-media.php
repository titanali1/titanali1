<?php
/* Authenticated small-part transport. Include from api.php only; no public entry point. */
if (!defined('TA_VER')) { http_response_code(404); exit; }

function ta_setup_key() {
    if (ta_installed()) return '';
    $lk=ta_lock();if(ta_installed()){ta_unlock($lk);return '';}
    $path=ta_file('setup-key.txt');$key=trim((string)@file_get_contents($path));
    if (!preg_match('/^[a-f0-9]{64}$/',$key)) {
        $key=bin2hex(random_bytes(32));
        if (@file_put_contents($path,$key."\n",LOCK_EX)!==65) { ta_unlock($lk);throw new Exception('کلید نصب روی هاست نوشته نشد.'); }
        @chmod($path,0600);
    }
    ta_unlock($lk);return $key;
}
function ta_install_owner($b) {
    if (ta_installed()) throw new Exception('این هاست قبلاً نصب شده؛ حساب تازه جایگزین مدیر قبلی نمی‌شود.');
    if (!ta_throttle('install',10,600)) throw new Exception('تلاش‌های نصب زیاد است؛ ده دقیقه صبر کنید.');
    $key=ta_setup_key();$given=isset($b['setupKey'])?(string)$b['setupKey']:'';
    if ($given===''||!hash_equals($key,$given)) throw new Exception('کلید نصب لازم است؛ setup-key.txt را فقط از File Manager سی‌پنل بخوانید.');
    $u=ta_str(isset($b['u'])?$b['u']:'',32);$p=isset($b['p'])?(string)$b['p']:'';$nm=ta_str(isset($b['name'])?$b['name']:'',40);
    if (!preg_match('/^[A-Za-z0-9_.-]{3,32}$/',$u)||strlen($p)<12) throw new Exception('نام کاربری لاتین ۳ تا ۳۲ حرف و رمز حداقل ۱۲ نویسه لازم است.');
    $lk=ta_lock();
    if (ta_installed()) {ta_unlock($lk);throw new Exception('مدیر قبلاً ساخته شده است.');}
    $c=ta_conf();$c['users']=array(array('u'=>$u,'p'=>ta_hash_pw($p),'name'=>$nm!==''?$nm:'مدیر اصلی','role'=>'owner'));
    if(!isset($c['secret']))$c['secret']=bin2hex(random_bytes(24));
    $seed=ta_read('content.json',null);
    if ($seed===null) {
        $seed=json_decode((string)@file_get_contents(__DIR__.'/titanali-defaults.json'),true);
        if(!is_array($seed)||!ta_put('content.json',$seed)){ta_unlock($lk);throw new Exception('فایل محتوای اولیه ناقص یا پوشهٔ داده نوشتنی نیست.');}
    }
    $baked=ta_bake($seed,ta_rev(),$u);
    $public=json_decode((string)@file_get_contents(ta_publish_path()),true);
    if(isset($baked['error'])||!$public||ta_sections_of($public['data'])!==ta_sections_of($seed)){ta_unlock($lk);throw new Exception('فایل عمومی نوشته یا تأیید نشد؛ دسترسی نوشتن کنار index.html را بررسی کنید.');}
    if(!ta_put('config.json',$c)){ta_unlock($lk);throw new Exception('ذخیره حساب مدیر ممکن نشد؛ دسترسی نوشتن پوشه داده را بررسی کنید.');}
    @unlink(ta_file('setup-key.txt'));ta_unlock($lk);
    return array('ok'=>true,'user'=>$u,'name'=>$nm!==''?$nm:'مدیر اصلی','rev'=>ta_rev(),'msg'=>'مدیر روی همین هاست ساخته شد.');
}
function ta_design_store($raw) {
    $c=ta_cfg();
    if(!is_string($raw)||$raw==='')ta_out(400,array('ok'=>false,'error'=>'بایت‌های تصویر دریافت نشده است؛ قالب درخواست و محدودیت بدنهٔ هاست را بررسی کنید.'));
    if(strlen($raw)>$c['maxFile'])ta_out(413,array('ok'=>false,'error'=>'تصویر از سقف مجاز هاست بزرگ‌تر است.'));
    $info=@getimagesizefromstring($raw);$mime=$info&&isset($info['mime'])?$info['mime']:'';
    if(!in_array($mime,array('image/jpeg','image/png','image/webp'),true))ta_out(415,array('ok'=>false,'error'=>'خود فایل تصویری معتبر JPG، PNG یا WebP نیست؛ تغییر نام فایل کافی نیست.'));
    if($info[0]<1||$info[1]<1||$info[0]>16000||$info[1]>16000||$info[0]*$info[1]>64000000)ta_out(415,array('ok'=>false,'error'=>'ابعاد تصویر خارج از حد مجاز است.'));
    $sha=hash('sha256',$raw);$types=ta_types();$fn='design-'.substr($sha,0,48).'.'.$types[$mime];$dir=$c['dataDir'].'/uploads';$lk=ta_lock();
    if(!is_dir($dir))@mkdir($dir,0775,true);$path=$dir.'/'.$fn;
    if(!is_file($path)||@hash_file('sha256',$path)!==$sha){
        $tmp=$path.'.tmp';
        if(@file_put_contents($tmp,$raw,LOCK_EX)!==strlen($raw)||!@rename($tmp,$path)){@unlink($tmp);ta_unlock($lk);ta_out(500,array('ok'=>false,'error'=>'تصویر روی هاست ذخیره نشد؛ فضای دیسک و مجوز نوشتن داده را بررسی کنید.'));}
        @chmod($path,0644);
    }
    clearstatcache(true,$path);$valid=is_file($path)&&filesize($path)===strlen($raw)&&@hash_file('sha256',$path)===$sha;ta_unlock($lk);
    if(!$valid)ta_out(500,array('ok'=>false,'error'=>'صحت فایل ذخیره‌شده تأیید نشد.'));
    return array('ok'=>true,'id'=>$fn,'url'=>'api.php?action=file&f='.rawurlencode($fn),'sha256'=>$sha,'size'=>strlen($raw),'type'=>$mime,'width'=>$info[0],'height'=>$info[1]);
}
function ta_media_routes($action) {
    if(!in_array($action,array('media_begin','media_chunk','media_finish'),true))return;
    $owner=ta_need_admin();
    if($_SERVER['REQUEST_METHOD']!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();$c=ta_cfg();$dir=ta_file('media-jobs');
    if(is_link($dir))ta_out(500,array('ok'=>false,'error'=>'پوشهٔ موقت معتبر نیست.'));
    if(!is_dir($dir)&&!@mkdir($dir,0700,true))ta_out(500,array('ok'=>false,'error'=>'پوشهٔ موقت آپلود نوشتنی نیست.'));
    /* Metadata + parts stay behind the data directory access guard. Locks serialize
       append/replay and bound active jobs; expired parts are lazily collected. */
    $lk=ta_lock();$jobs=glob($dir.'/*.json');$jobs=is_array($jobs)?$jobs:array();$count=0;
    foreach($jobs as $p){$v=json_decode((string)@file_get_contents($p),true);if(!$v||!isset($v['expires'])||$v['expires']<time()){@unlink(substr($p,0,-5).'.part');@unlink($p);}elseif(empty($v['result'])){$count++;}}
    if($action==='media_begin') {
        $size=isset($b['size'])?(int)$b['size']:0;$sha=isset($b['sha256'])?(string)$b['sha256']:'';
        if($size<1||$size>$c['maxFile']||!preg_match('/^[a-f0-9]{64}$/',$sha)){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'اندازه یا اثرانگشت تصویر معتبر نیست.'));}
        foreach(glob($dir.'/*.json') as $p){
            $j=json_decode((string)@file_get_contents($p),true);
            if($j&&$j['owner']===$owner['u']&&$j['sha256']===$sha&&$j['size']===$size){
                if(!empty($j['result'])){
                    $stored=ta_file('uploads/'.$j['result']['id']);
                    if(is_file($stored)&&@hash_file('sha256',$stored)===$sha){ta_unlock($lk);ta_out(200,array('ok'=>true,'result'=>$j['result']));}
                    @unlink($p);@unlink(substr($p,0,-5).'.part');continue;
                }
                clearstatcache(true,substr($p,0,-5).'.part');$offset=is_file(substr($p,0,-5).'.part')?(int)filesize(substr($p,0,-5).'.part'):0;
                ta_unlock($lk);ta_out(200,array('ok'=>true,'id'=>basename($p,'.json'),'offset'=>$offset,'chunkSize'=>ta_media_chunk_size()));
            }
        }
        if($count>=32){ta_unlock($lk);ta_out(429,array('ok'=>false,'error'=>'آپلودهای موقت زیاد است؛ آپلود جاری را کامل کنید یا پس از یک ساعت تلاش کنید.'));}
        $id=bin2hex(random_bytes(16));$j=array('owner'=>$owner['u'],'sha256'=>$sha,'size'=>$size,'expires'=>time()+3600);
        if(!ta_put('media-jobs/'.$id.'.json',$j)){ta_unlock($lk);ta_out(500,array('ok'=>false,'error'=>'ثبت آپلود ممکن نشد.'));}
        ta_unlock($lk);ta_out(200,array('ok'=>true,'id'=>$id,'offset'=>0,'chunkSize'=>ta_media_chunk_size()));
    }
    $id=isset($b['id'])?(string)$b['id']:'';
    if(!preg_match('/^[a-f0-9]{32}$/',$id)){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'شناسهٔ آپلود معتبر نیست.'));}
    $j=ta_read('media-jobs/'.$id.'.json',null);
    if(!$j||$j['owner']!==$owner['u']||$j['expires']<time()){ta_unlock($lk);ta_out(404,array('ok'=>false,'error'=>'آپلود موقت منقضی شده یا متعلق به این مدیر نیست؛ دوباره تلاش کنید.'));}
    if(!empty($j['result'])){
        $stored=ta_file('uploads/'.$j['result']['id']);
        if(!is_file($stored)||@hash_file('sha256',$stored)!==$j['sha256']){ta_unlock($lk);ta_out(500,array('ok'=>false,'error'=>'فایل قبلاً ذخیره‌شده اکنون در هاست موجود یا سالم نیست.'));}
        ta_unlock($lk);ta_out(200,$action==='media_finish'?$j['result']:array('ok'=>true,'offset'=>$j['size'],'replayed'=>true));
    }
    $part=$dir.'/'.$id.'.part';clearstatcache(true,$part);$offset=is_file($part)?(int)filesize($part):0;
    if($action==='media_chunk') {
        $at=isset($b['offset'])&&is_numeric($b['offset'])?(int)$b['offset']:-1;
        $text=isset($b['data'])&&is_string($b['data'])?$b['data']:'';$raw=strlen($text)<=16384?base64_decode($text,true):false;
        if($raw===false||$raw===''||strlen($raw)>12288||$at<0||$at+strlen($raw)>$j['size']){ta_unlock($lk);ta_out(400,array('ok'=>false,'error'=>'قطعهٔ تصویر یا محدودهٔ بایت معتبر نیست.'));}
        if($at<$offset&&$at+strlen($raw)<=$offset){$fp=@fopen($part,'rb');$old='';if($fp){fseek($fp,$at);$old=fread($fp,strlen($raw));fclose($fp);}if($old===$raw){ta_unlock($lk);ta_out(200,array('ok'=>true,'offset'=>$offset,'replayed'=>true));}}
        if($at!==$offset){ta_unlock($lk);ta_out(409,array('ok'=>false,'offset'=>$offset,'error'=>'ترتیب قطعه‌ها متفاوت است؛ آپلود را دوباره ادامه دهید.'));}
        if(@file_put_contents($part,$raw,FILE_APPEND|LOCK_EX)!==strlen($raw)){ta_unlock($lk);ta_out(500,array('ok'=>false,'error'=>'نوشتن قطعه روی دیسک کامل نشد؛ ادامه از اندازهٔ واقعی فایل انجام می‌شود.'));}
        ta_unlock($lk);ta_out(200,array('ok'=>true,'offset'=>$offset+strlen($raw)));
    }
    if($offset!==$j['size']){ta_unlock($lk);ta_out(409,array('ok'=>false,'offset'=>$offset,'error'=>'تمام بایت‌های تصویر هنوز دریافت نشده است.'));}
    $raw=@file_get_contents($part);
    if($raw===false||!hash_equals($j['sha256'],hash('sha256',$raw))){@unlink($part);@unlink($dir.'/'.$id.'.json');ta_unlock($lk);ta_out(422,array('ok'=>false,'error'=>'اثر انگشت تصویر با فایل دریافت‌شده یکی نیست؛ آپلود را دوباره شروع کنید.'));}
    ta_unlock($lk);$result=ta_design_store($raw);
    $lk=ta_lock();$j['result']=$result;
    if(ta_put('media-jobs/'.$id.'.json',$j))@unlink($part);
    ta_unlock($lk);
    /* Receipt permits idempotent finish after a lost response, without retaining
       duplicate photo parts or counting completed uploads against active quota. */
    ta_out(200,$result);
}
