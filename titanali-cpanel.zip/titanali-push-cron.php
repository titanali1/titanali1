<?php
// CLI ONLY. Never expose a public cron URL or secret query parameter.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
// The API HTTPS guard is HTTP-only; this entry already rejected every HTTP request.
$_SERVER['HTTPS']='on';
define('TA_LIBRARY_ONLY',true);
require __DIR__.'/api.php';
try {
    ta_cfg();
    echo json_encode(ta_push_dispatch(100),JSON_UNESCAPED_SLASHES).PHP_EOL;
} catch (Throwable $e) {
    fwrite(STDERR,"Titanali push: check private configuration, permissions and PHP extensions.\n");
    exit(1);
}
