/* Titanali appearance presets. No credentials, networking or account state here. */
(function () {
  'use strict';
  var CACHE = 'titanali.public-theme-v1';
  var presets = [
    {id:'baluchi',name:'روشن بلوچی',description:'کاغذ گرم، سبز نخ، اناری و حاشیه‌های دوخت؛ تم پیش‌فرض تازه.',background:'#f8f5ef'},
    {id:'editorial',name:'روشن تحریریه‌ای',description:'سفیدِ کاغذ، سرمه‌ای، تیترهای درشت و خطوط ظریف؛ با الهام از ساختار سایت مرجع.',background:'#fafbf9'},
    {id:'classic',name:'تیرهٔ کلاسیک',description:'ظاهر تیرهٔ قبلی، همراه با تصویر پس‌زمینه و رنگ نوار مرورگرِ ذخیره‌شده.',background:'#050409'}
  ];
  function safe(id) { return id === 'editorial' || id === 'classic' ? id : 'baluchi'; }
  function meta(id) { return presets.filter(function (p) { return p.id === safe(id); })[0]; }
  function apply(id, preview) {
    id = safe(id); document.documentElement.setAttribute('data-site-theme',id);
    document.documentElement.style.colorScheme = id === 'classic' ? 'dark' : 'light';
    var tag = document.querySelector('meta[name="theme-color"]');
    // Classic preserves the owner's existing custom browser-bar colour.
    if (tag && id !== 'classic') tag.content = meta(id).background;
    if (tag && id === 'classic' && document.documentElement.hasAttribute('data-theme-document')) tag.content = '#050409';
    if (!preview) try { localStorage.setItem(CACHE,id); } catch (_) {}
    return id;
  }
  // Strict enum cache only: no arbitrary CSS, markup, object keys or external URLs.
  try { apply(localStorage.getItem(CACHE) || 'baluchi',true); } catch (_) { apply('baluchi',true); }
  var paths = {
    wall:'<path d="m12 5 3 4 5 1-3 4v5l-5-2-5 2v-5l-3-4 5-1Z"/>',
    gallery:'<rect x="4" y="5" width="16" height="14" rx="1"/><path d="m4 16 5-5 4 4 3-3 4 4M8 8h1"/>',
    account:'<path d="m12 4 4 4-4 4-4-4ZM5 21v-4l7-4 7 4v4"/>',
    saved:'<path d="M6 4h12v17l-6-4-6 4Z"/><path d="m9 9 3 3 3-3"/>',
    category:'<path d="M3 8h7l2 2h9v10H3ZM3 8V4h7l2 3h9v3"/><path d="m9 15 3-3 3 3-3 3Z"/>',
    tracking:'<path d="M4 5h16v16H4ZM8 3v5M16 3v5M4 10h16m-12 5 3 3 6-5"/>',
    chat:'<path d="M3 4h18v13H10l-5 4v-4H3Z"/><path d="M7 9h10M7 13h6"/>',
    contact:'<path d="m7 3 4 5-3 3 5 5 3-3 5 4-3 4C11 21 3 13 3 6Z"/>',
    lang:'<path d="M3 12h18M12 3v18"/><circle cx="12" cy="12" r="9"/><path d="M12 3c-6 6-6 12 0 18 6-6 6-12 0-18Z"/>',
    share:'<path d="M12 16V3m-5 5 5-5 5 5M4 13v8h16v-8"/>',
    theme:'<path d="m12 2 3 5 5 1-2 5 2 5-6 1-2 3-3-5-5-1 2-5-2-5 6-1Z"/>'
  };
  function icon(name,variant) {
    var body = Object.prototype.hasOwnProperty.call(paths,name) ? paths[name] : paths.category;
    var diamond = (Number(variant)||0)%2 ? '<path class="stitch-accent" d="m5 2 2 2-2 2-2-2Zm22 24 2 2-2 2-2-2Z"/>' : '<path class="stitch-accent" d="m16 1 2 2-2 2-2-2Zm0 26 2 2-2 2-2-2Z"/>';
    return '<svg class="stitch-icon" viewBox="0 0 32 32" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="square" stroke-linejoin="miter"><path class="stitch-frame" d="M8 3H3v5m21-5h5v5M3 24v5h5m16 0h5v-5M8 4h2m3 0h2m3 0h2M8 28h2m3 0h2m3 0h2"/>'+diamond+'<g transform="translate(5 5) scale(.92)">'+body+'</g></svg>';
  }
  function iconInk(hex) {
    hex=/^#[a-f0-9]{6}$/i.test(hex)?hex:'#5473bd';
    var channels=[1,3,5].map(function(i){var v=parseInt(hex.slice(i,i+2),16)/255;return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);});
    var l=channels[0]*.2126+channels[1]*.7152+channels[2]*.0722;
    return l>.22?'#142d29':'#ffffff';
  }
  function pane(selected) {
    selected = safe(selected);
    return '<section class="theme-control"><p class="theme-admin-intro">یک تم انتخاب کنید. انتخاب، فقط پیش‌نمایش همین مدیر است؛ «ذخیره» انتخاب را ثبت می‌کند؛ با انتشار خودکار روشن، همان ذخیره آن را منتشر می‌کند. در غیر این صورت «انتشار روی هاست» را هم بزنید. حساب‌ها، طرح‌ها و تصویر اصلی لوگو تغییر نمی‌کنند.</p><fieldset class="theme-options"><legend>تم سایت</legend>'+presets.map(function (p) {
      return '<label class="theme-option" data-theme-option="'+p.id+'"><input type="radio" name="siteAppearance" value="'+p.id+'"'+(selected===p.id?' checked':'')+'><span class="theme-sample sample-'+p.id+'" aria-hidden="true"><span class="sample-heading"></span><span class="sample-line"></span><span class="sample-cards"><i></i><i></i><i></i></span><span class="sample-stitch"></span></span><span class="theme-option-name">'+p.name+'</span><span class="theme-option-description">'+p.description+'</span></label>';
    }).join('')+'</fieldset><p id="themePreviewStatus" class="theme-preview-status" role="status">گزینهٔ انتخاب‌شده: '+meta(selected).name+' — پیش‌نمایش مدیر</p><button type="button" class="pbtn" data-theme-reset>برگشت پیش‌نمایش به تم ذخیره‌شده</button><p class="hint">متن معرفی جدید خانه از «متن‌های سایت» قابل تغییر است. پس‌زمینهٔ اختصاصی قبلی محفوظ می‌ماند و در تم تیرهٔ کلاسیک نمایش داده می‌شود. تم تحریریه‌ای بازآفرینی بصری است؛ محتوا، نشان و وابستگی بیرونی سایت مرجع به سایت اضافه نشده است.</p><p><a href="THEMES.fa.html" target="_blank" rel="noopener">راهنمای تغییر تم و ارتقای امن با گوشی ↗</a></p></section>';
  }
  window.TitanaliThemes = Object.freeze({safe:safe,apply:apply,icon:icon,iconInk:iconInk,pane:pane,name:function(id){return meta(id).name;}});
})();
