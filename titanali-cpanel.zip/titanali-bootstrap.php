<?php
/* Web24 entry utilities. No accounts, setup keys or public-root writes here. */
function ta_local_transport($server)
{
    $addr=isset($server['REMOTE_ADDR'])?(string)$server['REMOTE_ADDR']:'';
    $host=isset($server['HTTP_HOST'])?strtolower((string)$server['HTTP_HOST']):'';
    $host=preg_replace('/:[0-9]+$/','',$host);
    return in_array($addr,array('127.0.0.1','::1'),true) &&
        ($host==='localhost'||$host==='127.0.0.1'||$host==='[::1]'||substr($host,-5)==='.test');
}
function ta_secure_transport($server)
{
    return (isset($server['HTTPS'])&&in_array(strtolower((string)$server['HTTPS']),array('on','1'),true))||
        (isset($server['SERVER_PORT'])&&(int)$server['SERVER_PORT']===443)||ta_local_transport($server);
}
function ta_require_secure_transport()
{
    if(ta_secure_transport($_SERVER))return;
    http_response_code(426);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    echo json_encode(array('ok'=>false,'code'=>'https_required','error'=>'این بخش فقط با HTTPS باز می‌شود؛ از آدرس https سایت استفاده کنید.'));
    exit;
}
function ta_private_path($raw,$base)
{
    if(!is_string($raw)||trim($raw)===''||strpos($raw,"\0")!==false)throw new Exception('پیکربندی پوشهٔ داده معتبر نیست.');
    $path=str_replace('\\','/',$raw);
    if($path[0]!=='/')$path=$base.'/'.$path;
    $parts=array();foreach(explode('/',$path) as $part){if($part===''||$part==='.')continue;if($part==='..'){array_pop($parts);continue;}$parts[]=$part;}
    $path='/'.implode('/',$parts);
    // Resolve the existing ancestor too: a not-yet-created child of a symlink
    // must be checked against the real public root, not its textual alias.
    $ancestor=$path;$suffix=array();
    while(!file_exists($ancestor)&&$ancestor!=='/'){$suffix[]=basename($ancestor);$ancestor=dirname($ancestor);}
    $resolved=realpath($ancestor);if($resolved===false)throw new Exception('مسیر پوشهٔ داده قابل بررسی نیست.');
    $path=rtrim(str_replace('\\','/',$resolved),'/');foreach(array_reverse($suffix) as $part)$path.='/'.$part;
    $path=$path===''?'/':$path;$public=str_replace('\\','/',realpath($base));
    if($path==='/'||$path===$public||strpos($public,$path.'/')===0)throw new Exception('پوشهٔ داده نباید ریشهٔ سایت یا یکی از پوشه‌های والد آن باشد. فایل تنظیمات را بررسی کنید؛ اطلاعات حذف نشده است.');
    return $path;
}
function ta_private_guard()
{
    return "# Titanali private data; conditional auth syntax supports modern/legacy servers.\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
}

function ta_write_private_guard($path,$body)
{
    $tmp=$path.'.tmp-'.bin2hex(random_bytes(8));
    if(@file_put_contents($tmp,$body,LOCK_EX)!==strlen($body)){
        @unlink($tmp);throw new Exception('حفاظت پوشهٔ داده قابل ذخیره نیست؛ نصب متوقف شد و اطلاعات حذف نشده است.');
    }
    @chmod($tmp,0644);
    if(!@rename($tmp,$path)){
        @unlink($tmp);throw new Exception('حفاظت پوشهٔ داده قابل ذخیره نیست؛ نصب متوقف شد و اطلاعات حذف نشده است.');
    }
}
