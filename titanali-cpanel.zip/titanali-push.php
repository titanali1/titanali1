<?php
/* Background Web Push (RFC 8291/8292) and APNs. No credentials in public files.
 * State, capabilities and VAPID keys live ONLY in ta_cfg()['dataDir'].
 * Delivery is at-least-once to the push provider, not a device delivery receipt.
 */
function ta_push_b64($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function ta_push_unb64($s) { return base64_decode(strtr($s, '-_', '+/'), true); }
function ta_push_lock($worker = false) {
    $f = @fopen(ta_file($worker ? 'push-worker.lock' : 'push.lock'), 'c');
    if (!$f || !flock($f, LOCK_EX | ($worker ? LOCK_NB : 0))) { if ($f) fclose($f); throw new RuntimeException('push_lock'); }
    return $f;
}
function ta_push_state() {
    $raw=ta_read('push-state.json',array('_invalid'=>true));
    if (is_file(ta_file('push-state.json')) && (!empty($raw['_invalid']) || !isset($raw['subs'],$raw['jobs'],$raw['seen']) || !is_array($raw['subs']) || !is_array($raw['jobs']) || !is_array($raw['seen']))) throw new RuntimeException('push_state_corrupt');
    return array_merge(array('enabled'=>false,'seen'=>array(),'subs'=>array(),'jobs'=>array(),'accepted'=>0,'failed'=>0,'lastRun'=>0,'lastError'=>''), empty($raw['_invalid'])?$raw:array());
}
function ta_push_save($s) {
    $p=ta_file('push-state.json'); $tmp=$p.'.'.getmypid().'.tmp';
    $raw=json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if ($raw===false) throw new RuntimeException('push_write');
    $old=umask(0077);
    try { if (@file_put_contents($tmp,$raw,LOCK_EX)===false || !@chmod($tmp,0600) || !@rename($tmp,$p)) { @unlink($tmp);throw new RuntimeException('push_write'); } } finally {umask($old);}
}
function ta_push_ready() { return function_exists('curl_init') && function_exists('openssl_pkey_derive') && function_exists('openssl_encrypt'); }
function ta_push_key() {
    $k = openssl_pkey_new(array('private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1'));
    if (!$k || !openssl_pkey_export($k, $pem)) throw new RuntimeException('push_crypto');
    $d = openssl_pkey_get_details($k);
    return array('private'=>$pem,'public'=>ta_push_b64("\x04".str_pad($d['ec']['x'],32,"\0",STR_PAD_LEFT).str_pad($d['ec']['y'],32,"\0",STR_PAD_LEFT)));
}
function ta_push_pubpem($raw) {
    if (strlen($raw)!==65 || $raw[0]!=="\x04") throw new InvalidArgumentException('push_key');
    return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode(hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200').$raw),64,"\n")."-----END PUBLIC KEY-----\n";
}
function ta_push_signature($der) {
    if (strlen($der)<8 || ord($der[0])!==48 || ord($der[2])!==2) throw new RuntimeException('push_signature');
    $n=ord($der[3]); $r=ltrim(substr($der,4,$n),"\0"); $p=4+$n;
    if (!isset($der[$p+1]) || ord($der[$p])!==2) throw new RuntimeException('push_signature');
    $s=ltrim(substr($der,$p+2,ord($der[$p+1])),"\0");
    if (strlen($r)>32 || strlen($s)>32) throw new RuntimeException('push_signature');
    return str_pad($r,32,"\0",STR_PAD_LEFT).str_pad($s,32,"\0",STR_PAD_LEFT);
}
function ta_push_jwt($header,$claims,$pem) {
    $msg=ta_push_b64(json_encode($header)).'.'.ta_push_b64(json_encode($claims,JSON_UNESCAPED_SLASHES));
    if (!openssl_sign($msg,$sig,$pem,OPENSSL_ALGO_SHA256)) throw new RuntimeException('push_sign');
    return $msg.'.'.ta_push_b64(ta_push_signature($sig));
}
function ta_push_encrypt($payload,$public,$auth) {
    $user=ta_push_unb64($public); $secret=ta_push_unb64($auth);
    if (strlen($payload)>3000 || strlen($secret)!==16) throw new InvalidArgumentException('push_payload');
    $server=ta_push_key(); $pub=ta_push_unb64($server['public']);
    $shared=openssl_pkey_derive(ta_push_pubpem($user),$server['private'],32);
    if ($shared===false) throw new RuntimeException('push_ecdh');
    $prk=hash_hmac('sha256',$shared,$secret,true);
    $ikm=hash_hmac('sha256',"WebPush: info\0".$user.$pub."\x01",$prk,true);
    $salt=random_bytes(16); $prk=hash_hmac('sha256',$ikm,$salt,true);
    $cek=substr(hash_hmac('sha256',"Content-Encoding: aes128gcm\0\x01",$prk,true),0,16);
    $nonce=substr(hash_hmac('sha256',"Content-Encoding: nonce\0\x01",$prk,true),0,12);
    $ct=openssl_encrypt($payload."\x02",'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag);
    if ($ct===false) throw new RuntimeException('push_encrypt');
    return $salt.pack('N',4096).chr(65).$pub.$ct.$tag;
}
/* Exact provider allowlist, no redirects, credentials, ports, IPs or user-selected hosts.
 * Adding a push provider requires review, never an arbitrary URL from the browser. */
function ta_push_endpoint($url) {
    if (!is_string($url) || strlen($url)>2048 || preg_match('/[\x00-\x20\x7f]/',$url)) return false;
    $u=parse_url($url); if (!$u || ($u['scheme']??'')!=='https' || isset($u['user']) || isset($u['pass']) || isset($u['port']) || isset($u['fragment'])) return false;
    $h=strtolower($u['host']??''); $p=$u['path']??'';
    return ($h==='fcm.googleapis.com' && strpos($p,'/fcm/send/')===0 && strlen($p)>10)
        || ($h==='updates.push.services.mozilla.com' && strpos($p,'/wpush/')===0 && strlen($p)>7)
        || ($h==='web.push.apple.com' && strpos($p,'/')===0 && strlen($p)>5);
}
function ta_push_apns() {
    $a=ta_read('push-apns.json',array());
    if (!preg_match('/^[A-Z0-9]{10}$/',$a['teamId']??'') || !preg_match('/^[A-Z0-9]{10}$/',$a['keyId']??'') || !preg_match('/^[A-Za-z0-9.-]{3,200}$/',$a['topic']??'') || !in_array($a['environment']??'',array('sandbox','production'),true)) return null;
    if (!ta_push_ready() || !defined('CURL_VERSION_HTTP2') || !(curl_version()['features'] & CURL_VERSION_HTTP2)) return null;
    $pem=@file_get_contents(ta_file('apns-auth-key.p8'));
    if (!$pem || strlen($pem)>8192) return null;
    $key=openssl_pkey_get_private($pem); if (!$key) return null;
    $d=openssl_pkey_get_details($key); if (($d['ec']['curve_name']??'')!=='prime256v1') return null;
    $a['private']=$pem; return $a;
}
function ta_push_view($s,$admin=false) {
    $a=ta_push_apns();
    $v=array('ok'=>true,'enabled'=>!empty($s['enabled']),'webReady'=>ta_push_ready()&&!empty($s['vapid']['public']),
        'publicKey'=>$s['vapid']['public']??'','apnsReady'=>$a!==null,'apnsTopic'=>$a?$a['topic']:'','apnsEnvironment'=>$a?$a['environment']:'');
    if ($admin) $v+=array('subscribers'=>count($s['subs']),'pending'=>count($s['jobs']),'accepted'=>$s['accepted'],'failed'=>$s['failed'],'lastRun'=>$s['lastRun'],'lastError'=>$s['lastError']);
    return $v;
}
function ta_push_ids($data) {
    $ids=array(); $data=ta_design_ids($data);
    foreach (($data['gallery']??array()) as $g) if ((!empty($g['img']) || !empty($g['imgs'][0])) && !empty($g['_taId'])) $ids[(string)$g['_taId']]=1;
    return $ids;
}
/* Called ONLY after atomic replacement of the real public snapshot. Drafts/uploads
 * never call this. Seen IDs survive deletion/re-addition and disabled periods. */
function ta_push_published($data,$rev) {
    $lk=ta_push_lock();
    try {
        $s=ta_push_state(); $ids=ta_push_ids($data); $new=array_diff_key($ids,$s['seen']);
        $s['jobs']=array_values(array_filter($s['jobs'],function($j){return $j['expires']>time();}));
        if ($new && !empty($s['enabled']) && $s['subs']) {
            if (count($s['jobs'])>=40) {$s['lastError']='push_queue_full';ta_push_save($s);throw new RuntimeException('push_queue_full');}
            $s['jobs'][]=array('id'=>bin2hex(random_bytes(12)),'rev'=>(int)$rev,'count'=>count($new),'expires'=>time()+3600,'targets'=>array_fill_keys(array_keys($s['subs']),array('tries'=>0,'next'=>0)));
        }
        $s['seen'] += $ids; ta_push_save($s);
    } finally { ta_unlock($lk); }
}
function ta_push_admin_set($enabled) {
    $lk=ta_push_lock();
    try {
        $s=ta_push_state();
        if ($enabled === !empty($s['enabled'])) return ta_push_view($s,true);
        if ($enabled && !ta_push_ready()) throw new RuntimeException('push_requirements');
        if ($enabled && empty($s['vapid'])) $s['vapid']=ta_push_key();
        if ($enabled && empty($s['enabled'])) {
            $p=ta_publish_path(); $snapshot=$p?json_decode((string)@file_get_contents($p),true):null;
            if (!is_array($snapshot) || !isset($snapshot['data'])) throw new RuntimeException('push_publish_first');
            $s['seen'] += ta_push_ids($snapshot['data']);
        }
        $s['enabled']=$enabled; $s['jobs']=array(); $s['lastError']=''; ta_push_save($s); return ta_push_view($s,true);
    } finally { ta_unlock($lk); }
}
function ta_push_rate() {
    $lk=ta_push_lock();
    try {
        $s=ta_push_state();$now=time();$rates=$s['rates']??array();
        foreach ($rates as $k=>$r) if ($r['until']<$now) unset($rates[$k]);
        $id=hash('sha256',$_SERVER['REMOTE_ADDR']??'cli');$r=$rates[$id]??array('until'=>$now+600,'count'=>0);
        if ($r['count']>=60 || (!isset($rates[$id]) && count($rates)>=500)) throw new RuntimeException('push_rate');
        $r['count']++;$rates[$id]=$r;$s['rates']=$rates;ta_push_save($s);
    } finally {ta_unlock($lk);}
}
function ta_push_register($b) {
    $cap=$b['capability']??'';
    if (!is_string($cap) || !preg_match('/^[A-Za-z0-9_-]{43,100}$/',$cap)) throw new InvalidArgumentException('push_capability');
    $kind=$b['kind']??'web';
    if ($kind==='web') {
        $p=$b['subscription']??array(); $ep=$p['endpoint']??null; $keys=$p['keys']??array();
        if (!ta_push_endpoint($ep) || !is_string($keys['p256dh']??null) || !is_string($keys['auth']??null) || strlen($keys['p256dh'])>100 || strlen($keys['auth'])>30) throw new InvalidArgumentException('push_subscription');
        $pub=ta_push_unb64($keys['p256dh']); $auth=ta_push_unb64($keys['auth']);
        if (strlen($auth)!==16 || strlen($pub)!==65 || !openssl_pkey_get_public(ta_push_pubpem($pub))) throw new InvalidArgumentException('push_subscription');
        $sub=array('kind'=>'web','endpoint'=>$ep,'public'=>$keys['p256dh'],'auth'=>$keys['auth']); $id=hash('sha256',$ep);
    } elseif ($kind==='apns') {
        $token=$b['token']??''; $a=ta_push_apns();
        if (!$a || !is_string($token) || !preg_match('/^[a-f0-9]{64,200}$/',$token) || ($b['topic']??'')!==$a['topic'] || ($b['environment']??'')!==$a['environment']) throw new InvalidArgumentException('push_apns_unavailable');
        $id=hash('sha256','apns:'.$a['environment'].':'.$a['topic'].':'.$token);
        $sub=array('kind'=>'apns','token'=>$token,'topic'=>$a['topic'],'environment'=>$a['environment']);
    } else throw new InvalidArgumentException('push_kind');
    $lk=ta_push_lock();
    try {
        $s=ta_push_state(); if (empty($s['enabled'])) throw new RuntimeException('push_disabled');
        if (isset($s['subs'][$id]) && !hash_equals($s['subs'][$id]['cap'],hash('sha256',$cap))) throw new InvalidArgumentException('push_capability_mismatch');
        if (!isset($s['subs'][$id]) && count($s['subs'])>=1000) throw new RuntimeException('push_capacity');
        $sub['cap']=hash('sha256',$cap); $sub['at']=time(); $s['subs'][$id]=$sub; ta_push_save($s); return array('ok'=>true,'id'=>$id);
    } finally { ta_unlock($lk); }
}
function ta_push_remove($id,$cap) {
    if (!is_string($id) || !preg_match('/^[a-f0-9]{64}$/',$id) || !is_string($cap) || strlen($cap)>100) throw new InvalidArgumentException('push_capability');
    $lk=ta_push_lock();
    try {
        $s=ta_push_state();
        if (isset($s['subs'][$id])) {
            if (!hash_equals($s['subs'][$id]['cap'],hash('sha256',$cap))) throw new InvalidArgumentException('push_capability');
            unset($s['subs'][$id]); foreach ($s['jobs'] as &$j) unset($j['targets'][$id]); unset($j); ta_push_save($s);
        }
        return array('ok'=>true);
    } finally { ta_unlock($lk); }
}
function ta_push_http($url,$headers,$body,$http2=false) {
    $c=curl_init($url);
    curl_setopt_array($c,array(CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>2,CURLOPT_TIMEOUT=>5,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS));
    if ($http2) curl_setopt($c,CURLOPT_HTTP_VERSION,CURL_HTTP_VERSION_2TLS);
    $body=curl_exec($c); $code=(int)curl_getinfo($c,CURLINFO_HTTP_CODE); curl_close($c);
    return array('code'=>$code,'body'=>is_string($body)?substr($body,0,2048):'');
}
function ta_push_send($sub,$job,$vapid) {
    $body=$job['count'].' طرح تازه منتشر شد. برای دیدن طرح‌ها لمس کنید.';
    if ($sub['kind']==='web') {
        if (!ta_push_endpoint($sub['endpoint'])) return array('code'=>410,'body'=>'');
        $u=parse_url($sub['endpoint']); $aud='https://'.strtolower($u['host']);
        $jwt=ta_push_jwt(array('typ'=>'JWT','alg'=>'ES256'),array('aud'=>$aud,'exp'=>time()+3600,'sub'=>'https://titanali1.ir/'),$vapid['private']);
        $data=json_encode(array('title'=>'طرح تازهٔ تیتانلی','body'=>$body,'id'=>$job['id']),JSON_UNESCAPED_UNICODE);
        return ta_push_http($sub['endpoint'],array('Authorization: vapid t='.$jwt.', k='.$vapid['public'],'Content-Type: application/octet-stream','Content-Encoding: aes128gcm','TTL: '.max(0,$job['expires']-time()),'Urgency: normal','Topic: '.$job['id']),ta_push_encrypt($data,$sub['public'],$sub['auth']));
    }
    $a=ta_push_apns(); if (!$a || $a['topic']!==$sub['topic'] || $a['environment']!==$sub['environment']) return array('code'=>503,'body'=>'');
    $jwt=ta_push_jwt(array('alg'=>'ES256','kid'=>$a['keyId']),array('iss'=>$a['teamId'],'iat'=>time()),$a['private']);
    $host=$a['environment']==='sandbox'?'api.sandbox.push.apple.com':'api.push.apple.com';
    return ta_push_http('https://'.$host.'/3/device/'.$sub['token'],array('authorization: bearer '.$jwt,'apns-topic: '.$a['topic'],'apns-push-type: alert','apns-priority: 10','apns-expiration: '.$job['expires'],'apns-collapse-id: '.$job['id'],'content-type: application/json'),json_encode(array('aps'=>array('alert'=>array('title'=>'طرح تازهٔ تیتانلی','body'=>$body),'sound'=>'default'),'titanaliEvent'=>$job['id']),JSON_UNESCAPED_UNICODE),true);
}
/* A private CLI cron owns the worker lock. Never hold a publication lock over I/O.
 * A disable/remove cancels queued sends; an already in-flight request cannot be recalled. */
function ta_push_dispatch($limit=100,$transport=null) {
    try { $worker=ta_push_lock(true); } catch (RuntimeException $e) { return array('ok'=>true,'busy'=>true); }
    $sent=0; $start=microtime(true);
    try {
        while ($sent<$limit && microtime(true)-$start<45) {
            $lk=ta_push_lock(); $pick=null;
            try {
                $s=ta_push_state(); $s['lastRun']=time();
                $s['jobs']=array_values(array_filter($s['jobs'],function($j){return $j['expires']>time() && !empty($j['targets']);}));
                if (!empty($s['enabled'])) foreach ($s['jobs'] as $ji=>$j) {
                    foreach ($j['targets'] as $id=>$retry) {
                        if (!isset($s['subs'][$id])) {unset($s['jobs'][$ji]['targets'][$id]);continue;}
                        if ($retry['next']<=time()) { $pick=array($ji,$id,$retry,$j,$s['subs'][$id],$s['vapid']??array()); break 2; }
                    }
                }
                ta_push_save($s);
            } finally { ta_unlock($lk); }
            if (!$pick) break;
            list($ji,$id,$retry,$job,$sub,$vapid)=$pick;
            try {$result=$transport?call_user_func($transport,$sub,$job,$vapid):ta_push_send($sub,$job,$vapid);} catch (Throwable $e) {$result=array('code'=>0,'body'=>'');}
            $sent++; $code=$result['code']; $accepted=in_array($code,array(200,201,202),true);
            $dead=$sub['kind']==='web'?in_array($code,array(404,410),true):($code===410 || ($code===400 && (json_decode($result['body'],true)['reason']??'')==='BadDeviceToken'));
            $lk=ta_push_lock();
            try {
                $s=ta_push_state(); $found=null;
                foreach ($s['jobs'] as $k=>$j) if ($j['id']===$job['id']) {$found=$k;break;}
                if ($found!==null && isset($s['jobs'][$found]['targets'][$id])) {
                    if ($accepted || $dead || $retry['tries']>=2) unset($s['jobs'][$found]['targets'][$id]);
                    else $s['jobs'][$found]['targets'][$id]=array('tries'=>$retry['tries']+1,'next'=>time()+($retry['tries']?300:60));
                }
                if ($dead && isset($s['subs'][$id]) && $s['subs'][$id]['cap']===$sub['cap']) unset($s['subs'][$id]);
                if ($accepted) {$s['accepted']++;$s['lastError']='';} else {$s['failed']++;$s['lastError']='provider_http_'.(int)$code;}
                $s['jobs']=array_values(array_filter($s['jobs'],function($j){return !empty($j['targets']);})); ta_push_save($s);
            } finally {ta_unlock($lk);}
        }
        return array('ok'=>true,'attempted'=>$sent);
    } finally {ta_unlock($worker);}
}
function ta_push_routes($action) {
    if (strpos($action,'push_')!==0) return;
    try {
        $method=$_SERVER['REQUEST_METHOD']??'GET';
        if ($action==='push_config' && $method==='GET') ta_out(200,ta_push_view(ta_push_state()));
        if ($action==='push_admin') {
            ta_need_admin();
            if ($method==='GET') ta_out(200,ta_push_view(ta_push_state(),true));
            if ($method==='POST') { $b=ta_body(); if (!isset($b['enabled']) || !is_bool($b['enabled'])) throw new InvalidArgumentException('push_enabled'); ta_out(200,ta_push_admin_set($b['enabled'])); }
        }
        if ($method!=='POST') ta_out(405,array('ok'=>false,'error'=>'POST required'));
        if ($action==='push_subscription') { ta_push_rate();ta_out(200,ta_push_register(ta_body())); }
        if ($action==='push_unsubscribe') { $b=ta_body();ta_out(200,ta_push_remove($b['id']??'',$b['capability']??'')); }
        ta_out(404,array('ok'=>false,'error'=>'Unknown push action'));
    } catch (InvalidArgumentException $e) {ta_out(400,array('ok'=>false,'error'=>'اطلاعات اشتراک یا مجوز این دستگاه معتبر نیست.','code'=>$e->getMessage()));}
    catch (Throwable $e) {ta_out(503,array('ok'=>false,'error'=>'سرویس اعلان آماده نیست؛ وضعیت و راهنمای پوش را در مدیریت بررسی کنید.','code'=>in_array($e->getMessage(),array('push_disabled','push_capacity','push_requirements','push_publish_first'),true)?$e->getMessage():'push_unavailable'));}
}
