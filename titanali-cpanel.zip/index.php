<?php
/* Alternative entry point only; the same index.html, not a second application. */
ini_set('display_errors','0');
if(!is_file(__DIR__.'/titanali-bootstrap.php')){http_response_code(503);header('Content-Type: text/plain; charset=UTF-8');echo 'بسته کامل نیست؛ فایل راه‌انداز PHP موجود نیست. اطلاعات را پاک نکنید.';exit;}
require_once __DIR__.'/titanali-bootstrap.php';
ta_require_secure_transport();
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
$entry=__DIR__.'/index.html';
if(!is_file($entry)||!is_readable($entry)){
    http_response_code(503);
    echo '<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>بسته ناقص است</title><p>فایل index.html قابل خواندن نیست. بستهٔ کامل را در همان پوشه استخراج کنید؛ پوشهٔ داده را حذف نکنید.</p></html>';
    exit;
}
readfile($entry);
