/* Real opt-in background notifications. No polling or fake foreground delivery. */
(function () {
  'use strict';
  var ctx, config, admin, adminError = '', adminLoaded = false, adminBusy = false, busy = false, on = false;
  var slot = 'ta-push-device-v1', nativeConfigured = false;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function native() { return window.TitanaliNativePush; }
  function unsupported() {
    if (native()) return nativeConfigured ? '' : 'این ساخت اپ برای پوش فعال نشده است؛ نسخهٔ امضاشدهٔ دارای مجوز APNs لازم است.';
    if (window.__titanaliIOSInstalled || window.TitanaliApp) return 'این نسخهٔ اپ بومی پوش ندارد؛ نسخهٔ جدید با اتصال و امضای سرویس اعلان لازم است. نسخهٔ وبِ نصب‌شده می‌تواند جداگانه اعلان بگیرد.';
    if (!window.isSecureContext || !('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return 'این مرورگر پوش را پشتیبانی نمی‌کند. در آیفون iOS 16.4 یا جدیدتر، ابتدا سایت را با Add to Home Screen نصب و از آیکون آن باز کنید.';
    return '';
  }
  async function call(action, data, method) {
    var r = await ctx.call(action, data, method);
    if (!r || !r.ok) throw new Error((r && r.error) || 'ارتباط با هاست برقرار نشد؛ دوباره تلاش کنید.');
    return r;
  }
  function saved() { return JSON.parse(localStorage.getItem(slot) || '{}'); }
  function record() {
    var r = saved();
    if (!r.capability) {
      var bytes = new Uint8Array(32); crypto.getRandomValues(bytes);
      r.capability = btoa(String.fromCharCode.apply(null, bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
      localStorage.setItem(slot, JSON.stringify(r));
    }
    return r;
  }
  async function worker() {
    var timer;
    try {
      return await Promise.race([navigator.serviceWorker.ready, new Promise(function (_, reject) {
        timer = setTimeout(function () { reject(new Error('سرویس‌ورکر آماده نشد؛ صفحه را آنلاین دوباره باز کنید.')); }, 12000);
      })]);
    } finally { clearTimeout(timer); }
  }
  function prefs(message) {
    var root = document.getElementById('taPushPreferences'); if (!root) return;
    var why = unsupported(), ready = config && config.enabled && (native() ? config.apnsReady : config.webReady);
    var status = message || (why || (!config ? 'برای خواندن وضعیت، «تازه‌سازی» را بزنید.' : (!config.enabled ? 'ارسال اعلان توسط مدیر متوقف است.' : (!ready ? 'اتصال سرویس اعلان هنوز در هاست آماده نیست.' : (on ? 'دریافت اعلان روی این دستگاه روشن است.' : 'با اجازهٔ شما، انتشار طرح تازه حتی با بسته‌بودن سایت اطلاع داده می‌شود.')))));
    root.innerHTML = '<h4>🔔 اعلان طرح‌های تازه</h4><p class="reg-p" role="status">' + esc(status) + '</p>' +
      '<button type="button" class="pbtn" data-push-user ' + (busy || (!on && (!ready || why)) ? 'disabled' : '') + '>' + (busy ? 'در حال بررسی…' : (on ? 'قطع دریافت روی این دستگاه' : 'فعال‌کردن دریافت اعلان')) + '</button> ' +
      '<button type="button" class="linkb" data-push-refresh ' + (busy ? 'disabled' : '') + '>تازه‌سازی</button><p class="reg-p">اجازهٔ اعلان اختیاری است؛ دریافت اینترنتی و تنظیمات سیستم‌عامل لازم است. تحویل فوری یا نمایش روی همهٔ دستگاه‌ها تضمین نمی‌شود.</p>';
  }
  async function refresh() {
    if (busy || !ctx) return;
    try {
      config = await call('push_config', null, 'GET');
      if (native()) { var s = await native().status(); on = !!s.enabled; nativeConfigured = !!s.configured; }
      else if (!unsupported()) { var w = await navigator.serviceWorker.getRegistration(); on = !!(w && await w.pushManager.getSubscription()); }
      prefs();
    } catch (e) { prefs(e.message); }
  }
  function decodeKey(s) {
    var raw = atob(s.replace(/-/g,'+').replace(/_/g,'/') + '='.repeat((4-s.length%4)%4));
    return Uint8Array.from(raw, function (c) { return c.charCodeAt(0); });
  }
  async function toggle() {
    if (busy) return;
    busy = true; prefs();
    var created = null;
    try {
      if (native()) {
        // The native coordinator owns capability/token persistence, server registration
        // and rotation. WKWebView Web Push is deliberately not used.
        if (on) await native().disable(); else await native().enable();
        var s = await native().status(); on = !!s.enabled;
      } else if (on) {
        var r = saved();
        if (r.id && r.capability) await call('push_unsubscribe', {id:r.id, capability:r.capability}, 'POST');
        var w = await worker(), sub = await w.pushManager.getSubscription();
        if (sub) await sub.unsubscribe();
        r.id = ''; localStorage.setItem(slot, JSON.stringify(r)); on = false;
      } else {
        if (unsupported()) throw new Error(unsupported());
        if (!config || !config.enabled || !config.webReady) throw new Error('سرویس ارسال آماده نیست؛ ابتدا وضعیت را تازه‌سازی کنید.');
        var rec = record(); // Fail closed before permission if storage is unavailable.
        // Called directly from the user's click, before awaiting service-worker work.
        var permission = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
        if (permission !== 'granted') throw new Error('اجازهٔ اعلان داده نشد؛ در صورت تمایل از تنظیمات مرورگر تغییر دهید.');
        var registration = await worker(), current = await registration.pushManager.getSubscription();
        if (!current) { current = await registration.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:decodeKey(config.publicKey)}); created = current; }
        var response = await call('push_subscription', {kind:'web', capability:rec.capability, subscription:current.toJSON()}, 'POST');
        rec.id = response.id;
        try { localStorage.setItem(slot, JSON.stringify(rec)); }
        catch (e) { await call('push_unsubscribe', {id:rec.id, capability:rec.capability}, 'POST'); throw e; }
        on = true;
      }
      busy = false; prefs(on ? 'دریافت اعلان روی این دستگاه فعال شد.' : 'دریافت اعلان روی این دستگاه قطع شد.');
    } catch (e) {
      if (created) try { await created.unsubscribe(); } catch (_) {}
      busy = false; prefs(e.message || 'ثبت درخواست تأیید نشد.');
    }
  }
  async function adminLoad() {
    if (!ctx || adminBusy) return;
    adminBusy = true; adminLoaded = true;
    try { admin = await call('push_admin', null, 'GET'); adminError = ''; }
    catch (e) { adminError = e.message; }
    finally { adminBusy = false; ctx.repaint(); }
  }
  async function adminToggle() {
    if (adminBusy || !admin) return;
    adminBusy = true; ctx.repaint();
    try { admin = await call('push_admin', {enabled:!admin.enabled}, 'POST'); config = admin; adminError = ''; prefs(); }
    catch (e) { adminError = e.message; }
    finally { adminBusy = false; ctx.repaint(); }
  }
  function adminPane() {
    if (!adminLoaded && ctx) adminLoad();
    var last = admin && admin.lastRun ? new Date(admin.lastRun * 1000).toLocaleString('fa-IR') : 'هنوز اجرا نشده';
    return '<section><h3>🔔 ارسال پس‌زمینهٔ طرح‌های تازه</h3><p>این کلید مستقل از ذخیرهٔ پیش‌نویس است و همان لحظه روی هاست ذخیره می‌شود. فقط طرح‌های تازهٔ منتشرشده اعلان دارند؛ طرح‌های قدیمی، ویرایش و جابه‌جایی دوباره اعلام نمی‌شوند.</p>' +
      (adminError ? '<p role="alert">' + esc(adminError) + '</p>' : '') +
      (admin ? '<p>ارسال: <strong>' + (admin.enabled ? 'روشن' : 'خاموش') + '</strong> · وب پوش: ' + (admin.webReady ? 'کلید آماده' : 'نیازمند OpenSSL/cURL و فعال‌سازی') + ' · APNs: ' + (admin.apnsReady ? 'پیکربندی موجود؛ تست دستگاه لازم است' : 'هنوز پیکربندی نشده') + '</p><button type="button" class="pbtn" data-push-admin-toggle ' + (adminBusy ? 'disabled' : '') + '>' + (admin.enabled ? 'بستن ارسال اعلان' : 'باز کردن ارسال اعلان') + '</button><p>اشتراک‌ها: ' + Number(admin.subscribers) + ' · انتشارهای در صف: ' + Number(admin.pending) + ' · پذیرش توسط سرویس پوش: ' + Number(admin.accepted) + ' · تلاش ناموفق: ' + Number(admin.failed) + '</p><p>آخرین اجرای زمان‌بندی: ' + esc(last) + '</p>' + (!admin.lastRun || Date.now()/1000-admin.lastRun > 180 ? '<p role="alert">وظیفهٔ Cron را مطابق راهنمای همراه بسته تنظیم یا بررسی کنید؛ بدون آن صف خودکار ارسال نمی‌شود.</p>' : '') + (admin.lastError ? '<p>آخرین خطا: ' + esc(admin.lastError) + '</p>' : '') : '<p>وضعیت هنوز دریافت نشده است.</p>') +
      '<button type="button" class="linkb" data-push-admin-refresh ' + (adminBusy ? 'disabled' : '') + '>خواندن وضعیت هاست</button><p>خاموش‌کردن، صف ارسال را لغو می‌کند. درخواستِ ازقبل ارسال‌شده به سرویس قابل پس‌گرفتن نیست. ظرفیت این بسته: ۱۰۰۰ دستگاه، ۴۰ انتشار در انتظار؛ اعلان‌های صف پس از یک ساعت منقضی می‌شوند.</p><p>راهنمای نصب: <a href="PUSH-SETUP.html" target="_blank" rel="noopener">تنظیم Cron و پوش اپلیکیشن</a></p></section>';
  }
  window.TitanaliPush = Object.freeze({adminPane:adminPane, init:function (value) {
    ctx = value; refresh(); if (ctx.active()) adminLoad();
    document.addEventListener('click', function (event) {
      var n = event.target.closest && event.target.closest('[data-push-user],[data-push-refresh],[data-push-admin-toggle],[data-push-admin-refresh]');
      if (!n) return; event.preventDefault();
      if (n.hasAttribute('data-push-user')) toggle();
      else if (n.hasAttribute('data-push-refresh')) refresh();
      else if (ctx.active() && n.hasAttribute('data-push-admin-toggle')) adminToggle();
      else if (ctx.active()) adminLoad();
    });
  }});
})();
