<?php
/* Web24: local-only, data-preserving owner setup. No HTTP loopback/deployment. */
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; img-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
function install_h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$installed=false;$ready=false;$message='';$error='';$missing=array();$c=null;
foreach(array('.htaccess','api.php','titanali-bootstrap.php','titanali-media.php','titanali-start.js','index.html','titanali-defaults.json') as $file){
    if(!is_file(__DIR__.'/'.$file)||!is_readable(__DIR__.'/'.$file))$missing[]=$file;
}
try{
    if($missing)throw new Exception('بسته کامل نیست؛ فایل‌های عمومی فهرست‌شده را دوباره از بستهٔ کامل استخراج کنید. اطلاعات موجود را پاک نکنید.');
    require_once __DIR__.'/titanali-bootstrap.php';
    ta_require_secure_transport();
    define('TA_LIBRARY_ONLY',true);
    require_once __DIR__.'/api.php';
    if(TA_VER!=='1.0.35')throw new Exception('فایل‌های سایت هم‌نسخه نیستند؛ همهٔ فایل‌های بستهٔ کامل را جایگزین کنید.');
    if(strpos((string)file_get_contents(__DIR__.'/.htaccess'),'# Titanali web24:')===false)throw new Exception('فایل پیکربندی ریشه از این بسته نیست؛ فایل مخفی .htaccess جدید را نیز جایگزین کنید.');
    $c=ta_cfg();$installed=ta_installed();
    if(!$installed)ta_setup_key();
    $ready=is_writable($c['dataDir'])&&is_writable(__DIR__);
    if(isset($_SERVER['REQUEST_METHOD'])&&$_SERVER['REQUEST_METHOD']==='POST'&&!$installed){
        if(!$ready)throw new Exception('پوشه داده یا ریشه سایت نوشتنی نیست.');
        if(!isset($_POST['p'],$_POST['p2'])||$_POST['p']!==$_POST['p2'])throw new Exception('دو بار رمز یکسان نیست.');
        $result=ta_install_owner(array('setupKey'=>isset($_POST['setupKey'])?$_POST['setupKey']:'',
            'u'=>isset($_POST['u'])?$_POST['u']:'','p'=>$_POST['p'],'name'=>isset($_POST['name'])?$_POST['name']:''));
        $installed=ta_installed();$verified=false;
        foreach(ta_users() as $a)if($a['u']===$result['user']&&ta_check_pw($_POST['p'],$a['p']))$verified=true;
        if(!$installed||!$verified)throw new Exception('خواندن دوباره حساب ذخیره‌شده تأیید نشد.');
        $message='حساب مدیر روی همین هاست ذخیره و رمز از روی فایل سرور بررسی شد. محتوای اولیهٔ سایت منتشر شده است.';
    }
}catch(Throwable $e){
    // Show only application messages, never PHP stack traces or absolute paths.
    $known=array('حفاظت پوشهٔ داده قابل ذخیره نیست؛ نصب متوقف شد و اطلاعات حذف نشده است.','فایل پیکربندی ریشه از این بسته نیست؛ فایل مخفی .htaccess جدید را نیز جایگزین کنید.','فایل تنظیمات باید یک آرایهٔ PHP برگرداند.','مسیر فایل نامعتبر یا خارج از سایت است.','مسیر خطرناک یا نام فایل نامعتبر است.','مقصد نامعتبر است.','پوشه مقصد در دسترس نیست.','بازنویسی فایل امنیتی یا نشست مجاز نیست.','لینک نمادین در مسیر مقصد مجاز نیست.','داده‌های کاربران باید در بخش data بازیابی شوند.','مقصد یک پوشه است، نه فایل.','افزونه ZIP در PHP هاست فعال نیست؛ در سی‌پنل PHP Extensions، zip را فعال کنید.','پوشه بکاپ قابل نوشتن نیست.','پوشه بکاپ نباید لینک نمادین باشد.','ساخت ZIP بکاپ ممکن نشد.','فضای موقت بکاپ قابل ساخت نیست.','حجم یا تعداد فایل‌های سایت از سقف بکاپ پنل بیشتر است؛ از بکاپ کامل سی‌پنل استفاده کنید.','خواندن یکی از فایل‌های بکاپ ممکن نشد.','افزودن فایل به ZIP ممکن نشد.','ساخت فهرست بکاپ ممکن نشد.','نهایی‌سازی ZIP بکاپ ممکن نشد.','ذخیره بکاپ ممکن نشد.','ذخیره مشخصات بکاپ ممکن نشد.','نام فایل قابل قبول نیست.','این نوع فایل مجاز نیست؛ فایل اجرایی PHP فقط داخل بسته سایت بررسی‌شده پذیرفته می‌شود.','پسوند مقصد باید با فایل انتخاب‌شده یکی باشد.','فایل خالی یا بزرگ‌تر از سقف مجاز است.','پوشه موقت نباید لینک نمادین باشد.','فضای موقت آپلود قابل نوشتن نیست.','فایل ZIP خراب است یا قالب پشتیبانی نمی‌شود.','ZIP بیش از حد فایل دارد.','فهرست ZIP خوانده نشد.','ZIP دارای لینک نمادین است.','ZIP دارای نام تکراری یا مبهم است.','ZIP از سقف استخراج امن بیشتر است.','فهرست بکاپ سایت معتبر نیست.','مشخصات فایل بکاپ ناقص است.','مسیر بکاپ نامعتبر است.','فایل اعلام‌شده در بکاپ وجود ندارد.','بکاپ فایل اعلام‌نشده دارد.','این ZIP بسته قابل‌شناسایی Titanali نیست.','ZIP دارای فایل خارج از public_html است.','فایل غیرمجاز در بسته سایت وجود دارد.','فایل JSON معتبر نیست.','بکاپ خالی است.','محتوای فایل ZIP است ولی پسوند آن zip نیست.','خواندن فایل آپلودشده ممکن نشد.','امضای بکاپ یا اندازه فایل تطابق ندارد.','ذخیره موقت فایل ممکن نشد.','ثبت بررسی فایل ممکن نشد.','شناسه آپلود نامعتبر است.','آپلود پیدا نشد یا متعلق به مدیر دیگری است.','زمان بررسی آپلود تمام شده؛ دوباره آپلود کنید.','بکاپ JSON فقط داده‌ای است؛ بازیابی داده‌ها را صریحاً تأیید کنید.','پیوست حذف‌شده قابل بازیابی نیست.','یکی از فایل‌های هاست پس از بررسی عوض شده؛ برای جلوگیری از حذف تغییرات تازه، دوباره آپلود کنید.','امضای فایل موقت عوض شده است.','پوشه مقصد قابل ساخت نیست.','پوشه مقصد قابل نوشتن نیست.','فایل موقت مقصد از قبل وجود دارد.','آماده‌سازی جایگزینی ممکن نشد.','نسخه مقصد ناقص نوشته شد.','آماده‌سازی بازگشت ممکن نشد.','جایگزینی فایل روی هاست انجام نشد.','شناسه بکاپ نامعتبر است.','بکاپ پیدا نشد.','آپلود کامل نشد؛ سقف upload_max_filesize و post_max_size در سی‌پنل را بررسی کنید.','حذف بکاپ نیاز به تأیید دارد.','حذف بکاپ ممکن نشد.','جایگزینی فایل‌ها نیاز به تأیید صریح دارد.','کلید حریم خصوصی قابل دسترس نیست.','کلید حریم خصوصی خراب است.','ذخیره کلید ممکن نشد.','نوشتن دادهٔ حذف‌شده ممکن نشد؛ دوباره تلاش کنید.','یک بکاپ خواندنی نیست؛ حذف کامل تأیید نشد.','بکاپ ناشناخته است؛ مدیر باید آن را بررسی کند.','JSON بکاپ نامعتبر است.','بازنویسی بکاپ ممکن نشد.','پاک‌سازی بکاپ ناقص بود.','ذخیره بکاپ پاک‌سازی‌شده نشد.','جایگزینی بکاپ ممکن نشد.','بکاپ نیمه‌تمام وجود دارد؛ مدیر باید آن را بررسی کند.','مسیر آپلود موقت نامعتبر است.','پاک‌سازی آپلود موقت نشد.','حذف یکی از پیوست‌ها ممکن نشد.','پاک‌سازی نسخهٔ منتشرشده نشد.','این بازیابی شامل دادهٔ هویتی حذف‌شده است؛ به دلیل حفاظت از حریم خصوصی رد شد.','دادهٔ حذف‌شده در بکاپ وجود دارد.','بکاپ حاوی شناسهٔ حذف‌شده است.','پیکربندی پوشهٔ داده معتبر نیست.','مسیر پوشهٔ داده قابل بررسی نیست.','پوشهٔ داده نباید ریشهٔ سایت یا یکی از پوشه‌های والد آن باشد. فایل تنظیمات را بررسی کنید؛ اطلاعات حذف نشده است.','کلید نصب روی هاست نوشته نشد.','این هاست قبلاً نصب شده؛ حساب تازه جایگزین مدیر قبلی نمی‌شود.','تلاش‌های نصب زیاد است؛ ده دقیقه صبر کنید.','کلید نصب لازم است؛ setup-key.txt را فقط از File Manager سی‌پنل بخوانید.','نام کاربری لاتین ۳ تا ۳۲ حرف و رمز حداقل ۱۲ نویسه لازم است.','مدیر قبلاً ساخته شده است.','فایل محتوای اولیه ناقص یا پوشهٔ داده نوشتنی نیست.','فایل عمومی نوشته یا تأیید نشد؛ دسترسی نوشتن کنار index.html را بررسی کنید.','ذخیره حساب مدیر ممکن نشد؛ دسترسی نوشتن پوشه داده را بررسی کنید.','بسته کامل نیست؛ فایل‌های عمومی فهرست‌شده را دوباره از بستهٔ کامل استخراج کنید. اطلاعات موجود را پاک نکنید.','فایل‌های سایت هم‌نسخه نیستند؛ همهٔ فایل‌های بستهٔ کامل را جایگزین کنید.','پوشه داده یا ریشه سایت نوشتنی نیست.','دو بار رمز یکسان نیست.','خواندن دوباره حساب ذخیره‌شده تأیید نشد.');
    $error=in_array($e->getMessage(),$known,true)?$e->getMessage():'اجرای نصب کامل نشد؛ کامل‌بودن فایل‌ها و پیکربندی خصوصی را بررسی کنید. اطلاعات خصوصی را در چت نفرستید.';
}
?><!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب امن تیتانلی · 1.0.35</title><link rel="icon" type="image/png" sizes="96x96" href="favicon.png?v=20261015-24"><style>
*{box-sizing:border-box}body{margin:0;padding:24px 14px;background:#071424;color:#edf3fc;font:16px/2 Tahoma,Arial,sans-serif}main{max-width:700px;margin:auto}h1{font-size:24px}h1,h2{color:#e7cda5}h2{font-size:19px}section{background:#10263e;border:1px solid #35506b;border-radius:18px;padding:20px;margin:18px 0}a{color:#91d1ff}label{display:block;margin-top:14px}input{display:block;width:100%;font:16px Tahoma;padding:13px;margin-top:7px;border-radius:10px;border:1px solid #52708d;background:#071424;color:white;min-height:48px}button,.button{display:block;text-align:center;font:16px Tahoma;background:#0986d9;color:white;border:0;border-radius:10px;padding:14px;margin-top:20px;min-height:48px;text-decoration:none;cursor:pointer}button:disabled{opacity:.45;cursor:not-allowed}.error{border-color:#d57183;color:#ffcad4}.success{border-color:#439b7d;color:#ccf8e9}code{direction:ltr;display:inline-block;overflow-wrap:anywhere}li{margin:12px 0}small{color:#b6cddd}
</style></head><body><main><h1>تیتانلی · نصب و بررسی نسخهٔ 1.0.35</h1><p>این صفحه فقط دادهٔ خصوصی را آماده می‌کند و فایل‌های عمومی، .htaccess یا مجوزهای ریشهٔ سایت را بازنویسی نمی‌کند.</p>
<?php if($error!==''):?><section class="error" role="alert"><?=install_h($error)?><?php if($missing):?><ul><?php foreach($missing as $file):?><li><code><?=install_h($file)?></code></li><?php endforeach;?></ul><?php endif;?></section><?php endif;?>
<?php if($message!==''):?><section class="success" role="status"><?=install_h($message)?></section><?php endif;?>
<?php if($installed):?>
<section class="success"><h2>هاست نصب شده است</h2><p>مدیر موجود دست‌نخورده است؛ حساب دیگری جایگزین نمی‌شود. با همان حساب قبلی وارد شوید.</p><a class="button" href="index.html">باز کردن سایت</a><a class="button" href="index.php">ورودی جایگزین PHP</a><p>پس از ورود موفق می‌توانید فقط titanali-install.php را از File Manager حذف کنید. پوشهٔ titanali-data، فایل titanali-config.php و titanali-content.json را حذف نکنید.</p></section>
<?php elseif(!$missing):?>
<section><h2>۱ · احراز مالکیت</h2><p>کلید خصوصی در خروجی این صفحه نمایش داده نمی‌شود. در File Manager فایل <code>titanali-data/setup-key.txt</code> را با View باز کنید و متن ۶۴ حرفی را فقط در فرم زیر وارد کنید. اگر dataDir سفارشی دارید، از همان پوشهٔ خصوصی استفاده کنید. کلید، رمز و فایل تنظیمات را در چت نفرستید.</p><p>PHP <?=install_h(PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION)?> · ریشه و داده: <?=$ready?'نوشتنی':'نیازمند بررسی'?></p><p>HTTPS و اجرای قواعد حفاظت داده روی Apache/LiteSpeed لازم است. اگر داده از وب قابل خواندن است، نصب را متوقف کنید؛ حفاظت را خاموش نکنید.</p></section>
<section><h2>۲ · ساخت اولین مدیر؛ فقط اگر قبلاً مدیر ندارید</h2><form method="post" action="titanali-install.php" autocomplete="off">
<label>کلید خصوصی نصب<input name="setupKey" type="password" required minlength="64" maxlength="64" pattern="[a-f0-9]{64}" autocomplete="off" dir="ltr"></label>
<label>نام کاربری لاتین<input name="u" required minlength="3" maxlength="32" pattern="[A-Za-z0-9_.\-]{3,32}" autocomplete="username" dir="ltr" autocapitalize="none"></label>
<label>نام نمایشی<input name="name" maxlength="40" autocomplete="name"></label>
<label>رمز عبور؛ حداقل ۱۲ نویسه<input name="p" type="password" required minlength="12" autocomplete="new-password" dir="ltr"></label>
<label>تکرار رمز<input name="p2" type="password" required minlength="12" autocomplete="new-password" dir="ltr"></label>
<button type="submit" <?=$ready?'':'disabled'?>>ساخت حساب و تأیید ذخیره روی همین هاست</button></form></section>
<?php endif;?>
<section><h2>آزمون فایل‌ها، جدا از نصب حساب</h2><a href="READY.html">فایل سادهٔ عمومی، بدون PHP و JavaScript</a> · <a href="HOST-CHECK.html">بررسی پاسخ فایل‌ها و PHP</a> · <a href="INSTALL.fa.html">راهنمای گوشی</a><p>عکس‌ها یا حساب‌های حذف‌شده فقط با بکاپ یا فایل اصلی قابل بازیابی‌اند. ارسال واقعی SMS نیازمند تنظیم سرویس است.</p><small>پشتیبانی: <a href="mailto:majeedj01@gmail.com">majeedj01@gmail.com</a></small></section></main></body></html>
