<?php
/* Website31: Google identity and private saved designs. No direct entry point. */
if (!defined('TA_VER')) { http_response_code(404); exit; }
function ta_identity($v) {
    if (!is_string($v)) return '';
    return preg_match('/^g_[a-f0-9]{40}$/D',$v) ? $v : ta_norm_phone($v);
}
function ta_identity_ok($v) { return ta_ok_phone($v) || preg_match('/^g_[a-f0-9]{40}$/D',$v); }
function ta_registration() {
    $r=ta_read('registration.json',array());
    $mode=isset($r['mode'])&&in_array($r['mode'],array('phone','email','both'),true)?$r['mode']:'phone';
    $client=isset($r['clientId'])&&is_string($r['clientId'])?$r['clientId']:'';
    return array('mode'=>$mode,'clientId'=>$client,'googleReady'=>ta_google_client_ok($client));
}
function ta_google_client_ok($v) { return is_string($v) && (bool)preg_match('/^[0-9]{6,30}-[A-Za-z0-9_-]{8,160}\.apps\.googleusercontent\.com$/D',$v); }
function ta_registration_allow($kind) {
    $c=ta_registration();
    return $c['mode']==='both'||$c['mode']===$kind;
}
function ta_design_ids($data) {
    if(!is_array($data)||!isset($data['gallery'])||!is_array($data['gallery']))return $data;
    foreach($data['gallery'] as $i=>$g) {
        if(!is_array($g))continue;
        if(isset($g['_taId'])&&is_string($g['_taId'])&&preg_match('/^[A-Za-z0-9_-]{6,100}$/D',$g['_taId']))continue;
        $src=!empty($g['img'])?$g['img']:(!empty($g['imgs'][0])?$g['imgs'][0]:'');
        $data['gallery'][$i]['_taId']='legacy-'.substr(hash('sha256',$src!==''?$src:json_encode(array($i,isset($g['t'])?$g['t']:''))),0,40);
    }
    return $data;
}
function ta_account_response($u) {
    return array('ok'=>true,'phone'=>$u['phone'],'name'=>isset($u['name'])?$u['name']:'','email'=>isset($u['email'])?$u['email']:'','provider'=>isset($u['provider'])?$u['provider']:'phone','tok'=>ta_member_tok($u['phone']));
}
function ta_google_claims($jwt,$client,$nonce) {
    /* Google checks the signature against its own rotating signing keys. A decoded
       JWT alone, a browser email, or an unverified Google profile is NEVER trusted. */
    if(!is_string($jwt)||strlen($jwt)>12000||!preg_match('/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/D',$jwt))throw new Exception('پاسخ ورود گوگل معتبر نیست.');
    $parts=explode('.',$jwt);$claims=json_decode(base64_decode(strtr($parts[1],'-_','+/'),true),true);
    if(!is_array($claims))throw new Exception('پاسخ ورود گوگل معتبر نیست.');
    $r=ta_http('https://oauth2.googleapis.com/tokeninfo?id_token='.rawurlencode($jwt));
    if(!$r['ok'])throw new Exception('تأیید امن گوگل انجام نشد؛ اتصال هاست به گوگل و انتخاب حساب را دوباره بررسی کنید.');
    $v=json_decode($r['body'],true);
    if(!is_array($v)||empty($v['sub'])||!isset($v['aud'])||$v['aud']!==$client||!in_array(isset($v['iss'])?$v['iss']:'',array('accounts.google.com','https://accounts.google.com'),true)
       ||!isset($v['exp'])||(int)$v['exp']<=time()||!isset($v['email_verified'])||!in_array($v['email_verified'],array(true,'true',1,'1'),true)
       ||empty($v['email'])||!filter_var($v['email'],FILTER_VALIDATE_EMAIL)
       ||!isset($claims['sub'],$claims['aud'],$claims['exp'],$claims['nonce'])||$claims['sub']!==$v['sub']||$claims['aud']!==$v['aud']||(int)$claims['exp']!==(int)$v['exp']
       ||!is_string($claims['nonce'])||!hash_equals($nonce,hash('sha256',$claims['nonce']))
       ||(isset($claims['iat'])&&(int)$claims['iat']>time()+60)||!preg_match('/^[0-9]{1,255}$/D',(string)$v['sub']))throw new Exception('حساب یا تأیید گوگل با این سایت و درخواست ورود مطابقت ندارد.');
    $v['name']=isset($claims['name'])?ta_str($claims['name'],32):'کاربر گوگل';
    return $v;
}
function ta_accounts_routes($a) {
    if(!in_array($a,array('registration','registration_admin','google_start','google_finish','saved_designs'),true))return;
    $method=$_SERVER['REQUEST_METHOD'];
    if($a==='registration') {
        if($method!=='GET')ta_out(405,array('ok'=>false,'error'=>'GET required'));
        ta_out(200,array('ok'=>true,'cfg'=>ta_registration()));
    }
    if($a==='registration_admin') {
        ta_need_admin();
        if($method==='GET')ta_out(200,array('ok'=>true,'cfg'=>ta_registration()));
        if($method!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
        $b=ta_body();$mode=isset($b['mode'])?$b['mode']:null;$client=isset($b['clientId'])&&is_string($b['clientId'])?trim($b['clientId']):null;
        if(!in_array($mode,array('phone','email','both'),true)||$client===null||($client!==''&&!ta_google_client_ok($client))||($mode!=='phone'&&!ta_google_client_ok($client)))ta_out(422,array('ok'=>false,'error'=>'روش معتبر و Client ID وب گوگل لازم است؛ برای فعال‌ماندن روش شماره، ابتدا همان روش را انتخاب کنید. تنظیمات قبلی تغییر نکرد.'));
        $lk=ta_lock();$ok=ta_put('registration.json',array('mode'=>$mode,'clientId'=>$client));ta_unlock($lk);
        if(!$ok)ta_out(503,array('ok'=>false,'error'=>'تنظیمات ورود روی هاست ذخیره نشد.'));
        ta_out(200,array('ok'=>true,'cfg'=>ta_registration()));
    }
    if($method!=='POST')ta_out(405,array('ok'=>false,'error'=>'POST required'));
    $b=ta_body();
    if($a==='saved_designs') {
        $id=ta_privacy_member($b);if($id==='')ta_out(401,array('ok'=>false,'error'=>'ابتدا وارد حساب شوید.'));
        $op=isset($b['op'])?$b['op']:'list';if(!in_array($op,array('list','add','remove'),true))ta_out(400,array('ok'=>false,'error'=>'عملیات معتبر نیست.'));
        $key=isset($b['key'])&&is_string($b['key'])?$b['key']:'';
        if($op!=='list'&&!preg_match('/^[A-Za-z0-9_-]{6,100}$/D',$key))ta_out(400,array('ok'=>false,'error'=>'شناسه طرح معتبر نیست.'));
        $lk=ta_lock();$all=ta_read('bookmarks.json',array());$owner=ta_privacy_hash($id);$keys=isset($all[$owner])&&is_array($all[$owner])?$all[$owner]:array();
        if($op==='add') {
            $d=ta_design_ids(ta_read('content.json',array()));$found=false;
            foreach(isset($d['gallery'])?$d['gallery']:array() as $g)if(isset($g['_taId'])&&$g['_taId']===$key){$found=true;break;}
            if(!$found){ta_unlock($lk);ta_out(404,array('ok'=>false,'error'=>'این طرح دیگر موجود نیست.'));}
            if(!in_array($key,$keys,true)){if(count($keys)>=1000){ta_unlock($lk);ta_out(409,array('ok'=>false,'error'=>'فهرست ذخیره‌شده‌ها پر است.'));}$keys[]=$key;}
        } elseif($op==='remove')$keys=array_values(array_diff($keys,array($key)));
        if($op!=='list'){$all[$owner]=$keys;if(!ta_put('bookmarks.json',$all)){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'ذخیره روی هاست تأیید نشد.'));}}
        ta_unlock($lk);ta_out(200,array('ok'=>true,'keys'=>$keys));
    }
    $cfg=ta_registration();$purpose=isset($b['purpose'])&&$b['purpose']==='delete'?'delete':'login';
    if(($purpose!=='delete'&&!ta_registration_allow('email'))||!$cfg['googleReady'])ta_out(409,array('ok'=>false,'error'=>'ورود گوگل در مدیریت این سایت فعال و تنظیم نشده است.'));
    if(!ta_throttle('google:'.ta_ip(),30,600))ta_out(429,array('ok'=>false,'error'=>'تلاش‌های ورود زیاد است؛ کمی بعد دوباره تلاش کنید.'));
    if($a==='google_start') {
        $member=$purpose==='delete'?ta_privacy_member($b):'';
        if($purpose==='delete'&&!preg_match('/^g_[a-f0-9]{40}$/D',$member))ta_out(401,array('ok'=>false,'error'=>'برای حذف حساب گوگل ابتدا وارد همان حساب شوید.'));
        $id=bin2hex(random_bytes(24));$nonce=bin2hex(random_bytes(24));$lk=ta_lock();$all=ta_read('google-nonces.json',array());
        foreach($all as $k=>$v)if(!is_array($v)||empty($v['expires'])||$v['expires']<time())unset($all[$k]);
        if(count($all)>=2000){ta_unlock($lk);ta_out(429,array('ok'=>false,'error'=>'سرویس ورود شلوغ است؛ کمی بعد تلاش کنید.'));}
        $all[$id]=array('hash'=>hash('sha256',$nonce),'expires'=>time()+300,'client'=>$cfg['clientId'],'purpose'=>$purpose,'member'=>$member);
        $ok=ta_put('google-nonces.json',$all);ta_unlock($lk);if(!$ok)ta_out(503,array('ok'=>false,'error'=>'آغاز امن ورود ممکن نشد.'));
        ta_out(200,array('ok'=>true,'id'=>$id,'nonce'=>$nonce,'clientId'=>$cfg['clientId']));
    }
    $id=isset($b['id'])&&is_string($b['id'])?$b['id']:'';
    $lk=ta_lock();$all=ta_read('google-nonces.json',array());$n=isset($all[$id])?$all[$id]:null;
    if(!$n||$n['expires']<time()||$n['client']!==$cfg['clientId']||$n['purpose']!==$purpose){ta_unlock($lk);ta_out(401,array('ok'=>false,'error'=>'درخواست ورود منقضی یا مصرف شده؛ دوباره دکمهٔ گوگل را بزنید.'));}
    unset($all[$id]);$ok=ta_put('google-nonces.json',$all);ta_unlock($lk);if(!$ok)ta_out(503,array('ok'=>false,'error'=>'تأیید درخواست ممکن نشد.'));
    try{$claims=ta_google_claims(isset($b['credential'])?$b['credential']:'',$cfg['clientId'],$n['hash']);}
    catch(Exception $e){ta_out(401,array('ok'=>false,'error'=>$e->getMessage()));}
    $identity='g_'.substr(hash('sha256',$claims['sub']),0,40);
    $lk=ta_lock();
    if($purpose==='delete') {
        if($identity!==$n['member']||ta_privacy_member($b)!==$identity){ta_unlock($lk);ta_out(403,array('ok'=>false,'error'=>'فقط همان حساب را می‌توانید حذف کنید.'));}
        try{$r=ta_privacy_erase($identity);}catch(Throwable $e){ta_unlock($lk);ta_out(503,array('ok'=>false,'error'=>'حذف کامل تأیید نشد؛ دوباره تلاش کنید یا به پشتیبانی پیام بدهید.'));}
        ta_unlock($lk);ta_out(200,$r);
    }
    /* Re-check policy after Google network verification: admin may have changed it. */
    $nowcfg=ta_registration();if(!ta_registration_allow('email')||$nowcfg['clientId']!==$cfg['clientId']){ta_unlock($lk);ta_out(409,array('ok'=>false,'error'=>'روش ورود تغییر کرده است؛ فرم را دوباره باز کنید.'));}
    $members=ta_members();$list=isset($members['list'])&&is_array($members['list'])?$members['list']:array();$found=-1;
    foreach($list as $i=>$u)if(isset($u['phone'])&&$u['phone']===$identity){$found=$i;break;}
    if($found>=0&&!empty($list[$found]['off'])){ta_unlock($lk);ta_out(403,array('ok'=>false,'error'=>'این حساب توسط مدیریت غیرفعال شده است.'));}
    $u=$found>=0?$list[$found]:array('phone'=>$identity,'ts'=>time(),'auth'=>bin2hex(random_bytes(24)),'off'=>0);
    $u['email']=strtolower($claims['email']);$u['provider']='google';$u['name']=$claims['name'];$u['seen']=time();
    if($found>=0)$list[$found]=$u;else $list[]=$u;
    $members['list']=$list;$ok=ta_put('users.json',$members);ta_unlock($lk);
    if(!$ok)ta_out(503,array('ok'=>false,'error'=>'حساب روی سرور ذخیره نشد؛ دوباره تلاش کنید.'));
    ta_out(200,ta_account_response($u));
}
