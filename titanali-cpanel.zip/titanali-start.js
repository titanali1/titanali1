/* Web24: transport check only. No cache/database deletion or user-data writes. */
(function () {
  'use strict';
  var h=location.hostname.toLowerCase();
  var local=h==='localhost'||h==='127.0.0.1'||h==='[::1]'||/\.test$/.test(h);
  if(location.protocol==='http:'&&!local){
    var secure=new URL(location.href);secure.protocol='https:';
    if(secure.port==='80')secure.port='';
    location.replace(secure.href);
  }
})();
