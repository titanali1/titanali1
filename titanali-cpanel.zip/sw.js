/* titanali — سرویس‌ورکر (آفلاین‌شدن + به‌روزرسانی بی‌دردسر) */
const V = 'titanali-v1.0.35';
const ASSETS = ['./dmj74-signature-4eacbb39fa81.png', './', './index.html', './site.webmanifest', './favicon.svg', './favicon.png', './favicon.ico', './safari-pinned-tab.svg',
                './apple-touch-icon.png', './icon-192.png', './icon-512.png', './maskable-512.png', './avatar.png', './404.html', './403.html', './titanali-start.js', './titanali-notifications.js', './titanali-themes.js', './titanali-themes.css', './fonts/Vazirmatn-Variable.woff2'];

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    for (const u of ASSETS) { try { await c.add(new Request(u, { cache: 'reload' })); } catch (_) {} }
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k.startsWith('titanali-') && k !== V) await caches.delete(k);
    self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const url = new URL(r.url);
  if (url.origin !== self.location.origin) return;            // منابع خارج از همین دامنه کش نمی‌شوند
  if (/\.php(\?|$)/.test(url.pathname + url.search)) return;  // api.php هرگز کش نمی‌شود
  // Only our two explicitly versioned appearance assets may use a query cache.
  // API/content/account queries remain network-only.
  const themeAsset = ['titanali-themes.js','titanali-themes.css'].some((name) =>
    url.pathname === new URL('./'+name,self.location.href).pathname) &&
    (!url.search || url.search === '?v=1.0.35');
  if (url.pathname.includes('/api/') || (url.search && !themeAsset)) return;
  if (/\/(privacy|delete-account|HOST-CHECK|READY)\.html$/.test(url.pathname)) return;
  if (/\/(titanali-content\.json|titanali-data(?:\/|$))/.test(url.pathname)) return;

  // صفحه: شبکه اول، کش به‌عنوان پشتیبان (تا آپدیت‌ها سریع دیده شوند)
  if (r.mode === 'navigate') {
    const base=new URL('./',self.location.href||self.location.origin+'/');
    if(url.pathname!==base.pathname&&url.pathname!==new URL('index.html',base).pathname)return;
    e.respondWith((async () => {
      try {
        const net = await fetch(r, {cache: 'no-store'});
        if(net.ok){try{const c=await caches.open(V);await c.put('./index.html',net.clone());}catch(_){/* A full/disabled cache must not hide a good network page. */}}
        return net;
      } catch (_) {
        try{return (await caches.match('./index.html')) || (await caches.match('./')) || Response.error();}
        catch(_){return Response.error();}
      }
    })());
    return;
  }

  // فایل‌های ثابت: کش اول
  e.respondWith((async () => {
    const key = themeAsset ? new Request(url.origin+url.pathname) : r;
    try{const hit=await(await caches.open(V)).match(key);if(hit)return hit;}catch(_){/* Network still works when cache reads fail. */}
    try {
      const net = await fetch(r, {cache: 'no-store'});
      if(net&&net.status===200&&net.type==='basic'){try{await(await caches.open(V)).put(key,net.clone());}catch(_){}}
      return net;
    } catch (_) {
      return Response.error();
    }
  })());
});

// Browser/PWA system notifications. Never fetch a URL supplied by the payload.
self.addEventListener('push', (event) => {
  event.waitUntil((async () => {
    let p = {}; try { p = event.data ? event.data.json() : {}; } catch (_) {}
    const id = typeof p.id === 'string' && /^[a-f0-9]{24}$/.test(p.id) ? p.id : 'new-designs';
    await self.registration.showNotification('طرح تازهٔ تیتانلی', {
      body: typeof p.body === 'string' ? p.body.slice(0, 240) : 'طرح‌های تازه را در گالری ببینید.',
      icon: new URL('./icon-192.png', self.location.href).href,
      badge: new URL('./icon-192.png', self.location.href).href,
      tag: 'titanali-designs-' + id, renotify: false,
      data: {url: new URL('./#gallery', self.location.href).href}
    });
  })());
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil((async () => {
    // Fixed trusted destination, including for notifications created by older code.
    const dest = new URL('./#gallery', self.location.href);
    const tabs = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for (const tab of tabs) {
      const u = new URL(tab.url);
      if (u.origin === dest.origin && (u.pathname === dest.pathname || u.pathname === dest.pathname + 'index.html')) {
        try { const opened = await tab.navigate(dest.href); if (opened) return opened.focus(); } catch (_) {}
      }
    }
    return self.clients.openWindow(dest.href);
  })());
});
// Subscription rotation is not silently faked: the receiving preference exposes
// a refresh/enable control, and expired provider endpoints are pruned by the worker.
