import SwiftUI
import WebKit
import GoogleSignIn
import QuickLook

@main @MainActor struct TitanaliApp: App {
    @StateObject private var model = BrowserModel()
    var body: some Scene {
        WindowGroup {
            ContentView(model:model)
                .environment(\.layoutDirection,.rightToLeft)
                .onOpenURL {url in
                    guard AppConfiguration.googleConfigured,url.scheme == AppConfiguration.googleScheme else {return}
                    _ = GIDSignIn.sharedInstance.handle(url)
                }
        }
    }
}

@MainActor struct ContentView: View {
    @ObservedObject var model: BrowserModel
    @State private var offline = false
    var body: some View {
        NavigationStack {
            VStack(spacing:0) {
                if model.loading {ProgressView().progressViewStyle(.linear).accessibilityLabel("در حال دریافت سایت")}
                if let error = model.error {
                    HStack {
                        Text(error).font(.footnote)
                        Button("بستن") {model.error = nil}
                    }.padding(10).frame(maxWidth:.infinity).background(Color.orange.opacity(0.17))
                }
                ZStack {
                    WebContainer(model:model)
                    if model.failed {
                        VStack(spacing:20) {
                            Image(systemName:"wifi.exclamationmark").font(.largeTitle)
                            Text("اتصال برقرار نشد").font(.headline)
                            Button("تلاش دوباره") {model.reload()}.buttonStyle(.borderedProminent)
                            Button("تصاویر آفلاین این آیفون") {offline = true}.buttonStyle(.bordered)
                        }.padding().frame(maxWidth:.infinity,maxHeight:.infinity).background(Color(uiColor:.systemBackground))
                    }
                }
            }
            .navigationTitle("تیتانلی").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement:.navigationBarLeading) {
                    Button {model.back()} label:{Image(systemName:"chevron.backward")}.accessibilityLabel("بازگشت")
                    Button {model.home()} label:{Image(systemName:"house")}.accessibilityLabel("خانه")
                }
                ToolbarItemGroup(placement:.navigationBarTrailing) {
                    Button {model.reload()} label:{Image(systemName:"arrow.clockwise")}.accessibilityLabel("بازخوانی")
                    Button {offline = true} label:{Image(systemName:"square.and.arrow.down")}.accessibilityLabel("کتابخانهٔ آفلاین")
                }
            }
        }
        .tint(.purple)
        .sheet(isPresented:$offline) {OfflineView(library:model.library)}
        .sheet(item:$model.authRequest,onDismiss:{model.cancelSignIn()}) {_ in
            VStack(spacing:24) {
                Text("ورود امن به تیتانلی").font(.title2).bold()
                Text("تأیید حساب در پنجرهٔ رسمی گوگل انجام می‌شود. حساب سایت فقط پس از تأیید سرور فعال خواهد شد.")
                    .multilineTextAlignment(.center)
                NativeGoogleButton {model.signIn()}.frame(width:230,height:52).disabled(model.signingIn)
                if model.signingIn {ProgressView()}
                Button("لغو") {model.cancelSignIn()}.disabled(model.signingIn)
            }.padding(28).presentationDetents([.medium,.large]).interactiveDismissDisabled(model.signingIn)
        }
        .sheet(item:$model.exportFile,onDismiss:{model.dismissExport()}) {file in
            ExportView(file:file,library:model.library)
        }
        .onAppear {model.start()}
    }
}

@MainActor struct WebContainer: UIViewRepresentable {
    let model: BrowserModel
    func makeUIView(context:Context)->WKWebView {model.web}
    func updateUIView(_ uiView:WKWebView,context:Context) {}
}

@MainActor struct NativeGoogleButton: UIViewRepresentable {
    var action: ()->Void
    func makeCoordinator()->Coordinator {Coordinator(action:action)}
    func makeUIView(context:Context)->GIDSignInButton {
        let button = GIDSignInButton();button.style = .standard;button.colorScheme = .light
        button.addTarget(context.coordinator,action:#selector(Coordinator.tap),for:.touchUpInside)
        return button
    }
    func updateUIView(_ button:GIDSignInButton,context:Context) {context.coordinator.action = action}
    final class Coordinator: NSObject {
        var action: ()->Void
        init(action:@escaping ()->Void) {self.action = action}
        @objc func tap() {action()}
    }
}

@MainActor struct ExportView: View {
    let file: ExportFile
    @ObservedObject var library: FileLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var status = ""
    @State private var saved = false
    var body: some View {
        NavigationStack {
            VStack(spacing:24) {
                Image(systemName:"doc").font(.largeTitle)
                Text(String(file.url.lastPathComponent.dropFirst(37))).font(.headline).lineLimit(3)
                Text("فایل اصلی آماده است. برای نگهداری در Files، از گزینهٔ اشتراک‌گذاری استفاده کنید؛ بازشدن این پنجره به‌تنهایی فایل را ذخیره نمی‌کند.")
                ShareLink(item:file.url) {Label("اشتراک‌گذاری / ذخیره در Files",systemImage:"square.and.arrow.up")}.buttonStyle(.borderedProminent)
                if file.mime.hasPrefix("image/") {
                    Button(saved ? "در آفلاین ذخیره شد" : "نگهداری تصویر اصلی برای آفلاین") {
                        do {try library.save(file.url,mime:file.mime);saved = true;status = "نسخهٔ اصلی، بدون فشرده‌سازی در این آیفون ذخیره شد."}
                        catch {status = error.localizedDescription}
                    }.buttonStyle(.bordered).disabled(saved)
                    Text("فایل آفلاین مخصوص همین دستگاه است، با حساب همگام نمی‌شود و از همین کتابخانه قابل حذف است.").font(.footnote)
                }
                Text(status).font(.footnote).accessibilityAddTraits(.updatesFrequently)
            }.padding(26).multilineTextAlignment(.center)
                .navigationTitle("دریافت فایل").navigationBarTitleDisplayMode(.inline)
                .toolbar {ToolbarItem(placement:.confirmationAction) {Button("بستن") {dismiss()}}}
        }
    }
}

@MainActor struct OfflineView: View {
    @ObservedObject var library: FileLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var selected: LibraryFile?
    @State private var confirmClear = false
    @State private var error: String?
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("این کتابخانهٔ محلی، با «ذخیره‌شده‌های» حساب سایت متفاوت است. فقط تصاویر دانلودشده‌ای که خودتان برای آفلاین نگه داشته‌اید اینجا هستند. اصل فایل حفظ می‌شود.").font(.footnote)
                    if library.files.isEmpty {Text("هنوز تصویری برای آفلاین نگه نداشته‌اید.")}
                }
                ForEach(library.files) {file in
                    Button {selected = file} label:{
                        HStack {
                            if let image = file.thumbnail {Image(uiImage:image).resizable().scaledToFit().frame(width:70,height:70)}
                            Text(file.name).lineLimit(2).foregroundStyle(.primary)
                            Spacer()
                            Text(ByteCountFormatter.string(fromByteCount:Int64(file.size),countStyle:.file)).font(.caption)
                        }
                    }
                    .swipeActions {Button("حذف",role:.destructive) {do {try library.delete(file)} catch {self.error = error.localizedDescription}}}
                }
                if let error {Text(error).foregroundStyle(.red)}
            }
            .navigationTitle("تصاویر آفلاین")
            .toolbar {
                ToolbarItem(placement:.cancellationAction) {Button("بستن") {dismiss()}}
                ToolbarItem(placement:.confirmationAction) {Button("حذف همه",role:.destructive) {confirmClear = true}.disabled(library.files.isEmpty)}
            }
            .confirmationDialog("تمام تصاویر آفلاین این آیفون حذف شوند؟",isPresented:$confirmClear,titleVisibility:.visible) {
                Button("حذف تصاویر آفلاین",role:.destructive) {do {try library.clear()} catch {self.error = error.localizedDescription}}
            }
            .sheet(item:$selected) {file in
                NavigationStack {
                    VStack {
                        // Quick Look opens the original file for native zoom; grid thumbnails remain bounded.
                        OriginalPreview(url:file.url)
                        ShareLink(item:file.url) {Label("اشتراک‌گذاری فایل اصلی",systemImage:"square.and.arrow.up")}.padding()
                    }.padding().navigationTitle(file.name).navigationBarTitleDisplayMode(.inline)
                        .toolbar {ToolbarItem(placement:.confirmationAction) {Button("بستن") {selected = nil}}}
                }
            }
        }.onAppear {library.refresh()}
    }
}

@MainActor struct OriginalPreview: UIViewControllerRepresentable {
    let url: URL
    func makeCoordinator()->Coordinator {Coordinator(url:url)}
    func makeUIViewController(context:Context)->QLPreviewController {
        let controller = QLPreviewController();controller.dataSource = context.coordinator;return controller
    }
    func updateUIViewController(_ controller:QLPreviewController,context:Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(url:URL) {self.url = url}
        func numberOfPreviewItems(in controller:QLPreviewController)->Int {1}
        func previewController(_ controller:QLPreviewController,previewItemAt index:Int)->QLPreviewItem {url as NSURL}
    }
}
