/* Titanali iOS adapter, web33 contract. No embedded OAuth, JWT decoding or local account creation. */
(() => {
  'use strict';
  if (window !== window.top || location.protocol !== 'https:' ||
      !['titanali1.ir', 'www.titanali1.ir'].includes(location.hostname) ||
      (location.port && location.port !== '443')) return;
  const channel = window.webkit?.messageHandlers?.titanali;
  if (!channel || window.__titanaliIOSInstalled) return;
  Object.defineProperty(window, '__titanaliIOSInstalled', {value: true});
  const pending = new Map();
  function request(type, payload) {
    if (pending.size >= 3) return Promise.reject(new Error('عملیات دیگری در جریان است.'));
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {pending.delete(id); reject(new Error('زمان عملیات تمام شد؛ دوباره تلاش کنید.'));}, 180000);
      pending.set(id, {resolve, reject, timer});
      try { channel.postMessage({id, type, ...payload}); }
      catch (_) {clearTimeout(timer);pending.delete(id);reject(new Error('ارتباط با برنامه برقرار نشد.'));}
    });
  }
  Object.defineProperty(window, '__titanaliIOSComplete', {value: (id, value, error) => {
    const p = pending.get(id); if (!p) return;
    clearTimeout(p.timer); pending.delete(id);
    if (error) p.reject(new Error(error)); else p.resolve(value);
  }});
  Object.defineProperty(window, 'TitanaliNativePush', {value:Object.freeze({
    status: () => request('push_status', {}),
    enable: () => request('push_enable', {}),
    disable: () => request('push_disable', {})
  })});
  // Adapter for existing googlePrepare(): challenge/nonce and authoritative backend verification are unchanged.
  let options = null;
  window.google = {accounts: {id: {
    initialize(config) { options = config; },
    renderButton(container) {
      const captured = options;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'pbtn';
      button.textContent = 'ادامه با گوگل در پنجرهٔ امن آیفون';
      button.addEventListener('click', async () => {
        if (!captured || typeof captured.callback !== 'function') return;
        button.disabled = true;
        try {
          const r = await request('google', {clientId: captured.client_id, nonce: captured.nonce});
          if (options === captured && r?.credential) captured.callback({credential:r.credential});
        } catch (e) {
          const note = document.querySelector('#googleNote'); if (note) note.textContent = e.message;
        } finally {button.disabled = false;}
      });
      container.replaceChildren(button);
    },
    disableAutoSelect() { options = null; }
  }}};
  // WKDownload handles HTTP downloads; this branch preserves exact blob/data bytes (including watermark/export).
  document.addEventListener('click', async event => {
    const anchor = event.target.closest?.('a[download]');
    if (!anchor || !/^(blob:|data:)/i.test(anchor.href)) return;
    event.preventDefault(); event.stopImmediatePropagation();
    try {
      const response = await fetch(anchor.href);
      if (!response.ok) throw new Error('خواندن فایل ممکن نشد.');
      const blob = await response.blob();
      if (!blob.size || blob.size > 12*1024*1024) throw new Error('فایل خالی یا بزرگ‌تر از ۱۲ مگابایت است.');
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let binary = ''; for (let i=0;i<bytes.length;i+=32768) binary += String.fromCharCode(...bytes.subarray(i,i+32768));
      await request('export', {name: anchor.download || 'titanali', mime: blob.type.split(';')[0].toLowerCase(), base64: btoa(binary)});
    } catch (e) {window.alert(e.message || 'دریافت فایل ممکن نشد.');}
  }, true);
  window.addEventListener('pagehide', () => {
    options = null;
    for (const p of pending.values()) {clearTimeout(p.timer);p.reject(new Error('صفحه بسته شد.'));}
    pending.clear();
  });
})();
