import SwiftUI
import WebKit
import GoogleSignIn
import SafariServices

struct AuthRequest: Identifiable {let id: String;let nonce: String;let clientID: String}
struct ExportFile: Identifiable {let id = UUID();let url: URL;let mime: String}

@MainActor final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, WKDownloadDelegate {
    @Published var authRequest: AuthRequest?
    @Published var exportFile: ExportFile?
    @Published var error: String?
    @Published var loading = false
    @Published var failed = false
    @Published var signingIn = false
    let library = FileLibrary()
    let web: WKWebView
    private let bridgeReady: Bool
    private var pendingAuthID: String?
    private var exportReply: String?
    private var exportURL: URL?
    private var downloads: [ObjectIdentifier:(URL,String)] = [:]
    private var downloadObservers: [ObjectIdentifier:NSKeyValueObservation] = [:]

    override init() {
        let controller = WKUserContentController()
        let script = Bundle.main.url(forResource:"native",withExtension:"js").flatMap {try? String(contentsOf:$0,encoding:.utf8)}
        bridgeReady = script != nil
        if let script {controller.addUserScript(WKUserScript(source:script,injectionTime:.atDocumentStart,forMainFrameOnly:true))}
        let config = WKWebViewConfiguration();config.userContentController = controller
        config.websiteDataStore = .default();config.limitsNavigationsToAppBoundDomains = false
        web = WKWebView(frame:.zero,configuration:config)
        super.init()
        controller.add(WeakHandler(self),name:"titanali")
        web.navigationDelegate = self;web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false;web.backgroundColor = UIColor(red:0.06,green:0.045,blue:0.09,alpha:1)
        web.scrollView.contentInsetAdjustmentBehavior = .automatic
        let refresh = UIRefreshControl();refresh.addTarget(self,action:#selector(reload),for:.valueChanged)
        web.scrollView.refreshControl = refresh
        PushCoordinator.shared.bindOpenGallery { [weak self] in
            guard let self, self.bridgeReady, var u = URLComponents(url:AppConfiguration.site,resolvingAgainstBaseURL:false) else { return }
            u.fragment = "gallery"
            if let url = u.url { self.web.load(URLRequest(url:url)) }
        }
    }
    func start() {
        guard bridgeReady else {failed = true;error = "فایل‌های این نسخه ناقص‌اند؛ نسخهٔ سالم برنامه لازم است.";return}
        if web.url == nil {web.load(URLRequest(url:AppConfiguration.site,cachePolicy:.reloadRevalidatingCacheData))}
    }
    @objc func reload() {failed = false;error = nil;if web.url == nil {start()} else {web.reload()}}
    func back() {if web.canGoBack {web.goBack()}}
    func home() {guard bridgeReady else {start();return};failed = false;error = nil;web.load(URLRequest(url:AppConfiguration.site))}
    private func trusted(_ frame: WKFrameInfo) -> Bool {
        let origin = frame.securityOrigin
        return frame.isMainFrame && origin.protocol == "https" && NavigationPolicy.hosts.contains(origin.host.lowercased())
            && (origin.port == 0 || origin.port == 443) && NavigationPolicy.isSite(web.url)
    }
    private func reply(_ id: String, value: [String:Any] = [:], error: String? = nil) {
        guard NavigationPolicy.isSite(web.url) else {return}
        // Objective-C NS_REFINED_FOR_SWIFT entry avoids the absent Swift WebKit overlay on iOS18.5.
        // Fixed source + structured arguments; credentials never interpolated into JavaScript or navigation URLs.
        web.__callAsyncJavaScript("if(typeof window.__titanaliIOSComplete==='function') window.__titanaliIOSComplete(id,value,error);",
                                arguments:["id":id,"value":value,"error":error.map {$0 as Any} ?? NSNull()],
                                inFrame:nil,in:.page,completionHandler:nil)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard trusted(message.frameInfo),let b = message.body as? [String:Any],let id = b["id"] as? String,
              UUID(uuidString:id) != nil,let type = b["type"] as? String else {return}
        switch type {
        case "push_status", "push_enable", "push_disable":
            Task { [weak self] in
                do {
                    if type == "push_enable" { try await PushCoordinator.shared.enable() }
                    if type == "push_disable" { try await PushCoordinator.shared.disable() }
                    let result = try await PushCoordinator.shared.status()
                    self?.reply(id,value:result)
                } catch { self?.reply(id,error:error.localizedDescription) }
            }
        case "google":
            guard pendingAuthID == nil,authRequest == nil,exportFile == nil,downloads.isEmpty else {reply(id,error:"ورود دیگری در جریان است.");return}
            guard AppConfiguration.googleConfigured else {reply(id,error:"ورود بومی گوگل هنوز توسط ناشر برای iOS پیکربندی نشده است.");return}
            guard let nonce = b["nonce"] as? String,nonce.count >= 16,nonce.count <= 256,
                  nonce.range(of:"^[A-Za-z0-9_-]+$",options:.regularExpression) != nil,
                  let clientID = b["clientId"] as? String,clientID == AppConfiguration.googleServerClientID else {
                reply(id,error:"تنظیمات گوگل در سایت و برنامه یکسان نیست.");return
            }
            pendingAuthID = id;authRequest = AuthRequest(id:id,nonce:nonce,clientID:clientID)
        case "export":
            guard exportFile == nil,exportReply == nil,downloads.isEmpty,authRequest == nil else {reply(id,error:"ابتدا پنجرهٔ فایل قبلی را ببندید.");return}
            guard let base64 = b["base64"] as? String,base64.utf8.count <= (NavigationPolicy.exportLimit*4/3+4),
                  let data = Data(base64Encoded:base64),let mime = b["mime"] as? String,mime.count < 100,
                  let name = b["name"] as? String,name.utf8.count <= 512 else {reply(id,error:"فایل معتبر نیست.");return}
            do {let url = try library.temporaryFile(data:data,name:name,mime:mime);exportReply = id;exportURL = url;exportFile = ExportFile(url:url,mime:mime)}
            catch {reply(id,error:error.localizedDescription)}
        default: reply(id,error:"عملیات پشتیبانی نمی‌شود.")
        }
    }
    func signIn() {
        guard let request = authRequest,pendingAuthID == request.id,!signingIn,let presenter = Self.presenter() else {return}
        signingIn = true
        let service = GIDSignIn.sharedInstance
        // No silent login and no mailbox scopes. Clear SDK cache; the web backend owns membership.
        service.signOut()
        service.configuration = GIDConfiguration(clientID:AppConfiguration.googleClientID,serverClientID:request.clientID)
        service.signIn(withPresenting:presenter,hint:nil,additionalScopes:nil,nonce:request.nonce) {[weak self] result, error in
            DispatchQueue.main.async {
                let token = result?.user.idToken?.tokenString
                service.signOut()
                guard let self,self.pendingAuthID == request.id else {return}
                self.signingIn = false;self.pendingAuthID = nil;self.authRequest = nil
                guard error == nil,let token,!token.isEmpty else {self.reply(request.id,error:"ورود گوگل لغو شد یا به نتیجه نرسید؛ دوباره تلاش کنید.");return}
                self.reply(request.id,value:["credential":token])
                // google_finish on the existing server still verifies aud/iss/nonce/expiry/signature boundary.
                // No member is created locally and no SDK token is persisted by this app.
            }
        }
    }
    func cancelSignIn() {
        guard let id = pendingAuthID else {return}
        pendingAuthID = nil;signingIn = false;authRequest = nil;reply(id,error:"ورود گوگل لغو شد.")
    }
    func dismissExport() {
        if let id = exportReply {reply(id,value:["prepared":true])}
        exportReply = nil
        if let url = exportURL {try? FileManager.default.removeItem(at:url)}
        exportURL = nil
    }
    static func presenter() -> UIViewController? {
        var current = UIApplication.shared.connectedScenes.compactMap {$0 as? UIWindowScene}
            .filter {$0.activationState == .foregroundActive}.flatMap {$0.windows}.first {$0.isKeyWindow}?.rootViewController
        while let next = current?.presentedViewController {current = next}
        return current
    }
    private func external(_ url: URL) {
        if NavigationPolicy.isExternalHTTPS(url) {
            Self.presenter()?.present(SFSafariViewController(url:url),animated:true)
        } else if ["tel","mailto"].contains(url.scheme?.lowercased() ?? "") {
            let alert = UIAlertController(title:"بازکردن برنامهٔ دیگر؟",message:url.absoluteString,preferredStyle:.alert)
            alert.addAction(UIAlertAction(title:"لغو",style:.cancel))
            alert.addAction(UIAlertAction(title:"ادامه",style:.default){_ in UIApplication.shared.open(url)})
            Self.presenter()?.present(alert,animated:true)
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy)->Void) {
        guard let url = action.request.url else {decisionHandler(.cancel);return}
        if NavigationPolicy.isSite(url) {
            if action.shouldPerformDownload {decisionHandler(.download)}
            else if action.targetFrame == nil {decisionHandler(.cancel);webView.load(action.request)}
            else {decisionHandler(.allow)}
        } else if action.targetFrame?.isMainFrame == false && url.scheme == "https" {
            decisionHandler(.allow) // Embedded content never gets the main-frame native bridge.
        } else {
            decisionHandler(.cancel)
            if action.navigationType == .linkActivated {external(url)}
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy)->Void) {
        let attachment = (response.response as? HTTPURLResponse)?.value(forHTTPHeaderField:"Content-Disposition")?.lowercased().contains("attachment") == true
        decisionHandler((!response.canShowMIMEType || attachment) && response.isForMainFrame ? .download : .allow)
    }
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {download.delegate = self}
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {download.delegate = self}
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?)->Void) {
        let mime = response.mimeType?.lowercased() ?? "application/octet-stream"
        guard exportFile == nil,exportReply == nil,downloads.isEmpty,NavigationPolicy.isSite(response.url),
              let http = response as? HTTPURLResponse,(200..<300).contains(http.statusCode),
              response.expectedContentLength > 0,response.expectedContentLength <= Int64(NavigationPolicy.exportLimit),
              NavigationPolicy.extensions[mime] != nil else {
            error = "دانلود مستقیم مجاز نیست، اندازهٔ آن مشخص نیست یا از ۱۲ مگابایت بیشتر است.";completionHandler(nil);return
        }
        let url = library.temporary.appendingPathComponent(UUID().uuidString+"-"+NavigationPolicy.filename(suggestedFilename,mime:mime))
        downloads[ObjectIdentifier(download)] = (url,mime)
        downloadObservers[ObjectIdentifier(download)] = download.progress.observe(\.completedUnitCount,options:[.new]) {[weak self,weak download] progress,_ in
            guard progress.completedUnitCount > Int64(NavigationPolicy.exportLimit) else {return}
            DispatchQueue.main.async {
                guard let self,let download,self.downloads[ObjectIdentifier(download)] != nil else {return}
                download.cancel {[weak self] _ in
                    guard let self else {return}
                    if let (path,_) = self.downloads.removeValue(forKey:ObjectIdentifier(download)) {try? FileManager.default.removeItem(at:path)}
                    self.downloadObservers.removeValue(forKey:ObjectIdentifier(download));self.error = "دانلود از حد مجاز بزرگ‌تر شد و لغو شد."
                }
            }
        }
        completionHandler(url)
    }
    func download(_ download: WKDownload, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, decisionHandler: @escaping (WKDownload.RedirectPolicy)->Void) {
        decisionHandler(NavigationPolicy.isSite(request.url) ? .allow : .cancel)
    }
    func downloadDidFinish(_ download: WKDownload) {
        downloadObservers.removeValue(forKey:ObjectIdentifier(download))
        guard let (url,mime) = downloads.removeValue(forKey:ObjectIdentifier(download)) else {return}
        do {
            let size = try url.resourceValues(forKeys:[.fileSizeKey]).fileSize ?? 0
            guard size > 0,size <= NavigationPolicy.exportLimit else {throw FileLibrary.FileError.invalid}
            let data = try Data(contentsOf:url)
            guard !data.isEmpty,data.count <= NavigationPolicy.exportLimit else {throw FileLibrary.FileError.invalid}
            try FileManager.default.setAttributes([.protectionKey:FileProtectionType.complete],ofItemAtPath:url.path)
            exportURL = url;exportFile = ExportFile(url:url,mime:mime)
        } catch {try? FileManager.default.removeItem(at:url);self.error = "دریافت فایل کامل نشد."}
    }
    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloadObservers.removeValue(forKey:ObjectIdentifier(download))
        if let (url,_) = downloads.removeValue(forKey:ObjectIdentifier(download)) {try? FileManager.default.removeItem(at:url)}
        self.error = "دانلود کامل نشد؛ دوباره تلاش کنید."
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        cancelSignIn();loading = true;failed = false
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {loading = false;failed = false;webView.scrollView.refreshControl?.endRefreshing();library.protectWebData()}
    private func loadFailed(_ error: Error) {
        loading = false;web.scrollView.refreshControl?.endRefreshing()
        let ns = error as NSError
        if (ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled) || (ns.domain == "WebKitErrorDomain" && ns.code == 102) {return}
        failed = true;self.error = "ارتباط با سایت برقرار نشد. فایل‌های آفلاین همچنان در دسترس‌اند."
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {loadFailed(error)}
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {loadFailed(error)}
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {loading = false;failed = true;error = "صفحه بسته شد؛ برای ادامه بازخوانی کنید."}
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures)->WKWebView? {
        if action.targetFrame == nil,let url = action.request.url {
            if NavigationPolicy.isSite(url) {webView.load(action.request)}
            else if action.navigationType == .linkActivated {external(url)}
        }
        return nil
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ()->Void) {
        guard trusted(frame),let p = Self.presenter() else {completionHandler();return}
        let a = UIAlertController(title:"تیتانلی",message:String(message.prefix(1500)),preferredStyle:.alert)
        a.addAction(UIAlertAction(title:"باشه",style:.default){_ in completionHandler()});p.present(a,animated:true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool)->Void) {
        guard trusted(frame),let p = Self.presenter() else {completionHandler(false);return}
        let a = UIAlertController(title:"تأیید",message:String(message.prefix(1500)),preferredStyle:.alert)
        a.addAction(UIAlertAction(title:"لغو",style:.cancel){_ in completionHandler(false)})
        a.addAction(UIAlertAction(title:"تأیید",style:.default){_ in completionHandler(true)});p.present(a,animated:true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?)->Void) {
        guard trusted(frame),let p = Self.presenter() else {completionHandler(nil);return}
        let a = UIAlertController(title:"تیتانلی",message:String(prompt.prefix(1500)),preferredStyle:.alert)
        a.addTextField {$0.text = defaultText}
        a.addAction(UIAlertAction(title:"لغو",style:.cancel){_ in completionHandler(nil)})
        a.addAction(UIAlertAction(title:"تأیید",style:.default){_ in completionHandler(a.textFields?.first?.text)});p.present(a,animated:true)
    }
}

// WKUserContentController retains handlers; this proxy prevents a WKWebView/model retain cycle.
@MainActor private final class WeakHandler: NSObject, WKScriptMessageHandler {
    weak var owner: BrowserModel?
    init(_ owner: BrowserModel) {self.owner = owner}
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {owner?.userContentController(userContentController,didReceive:message)}
}
