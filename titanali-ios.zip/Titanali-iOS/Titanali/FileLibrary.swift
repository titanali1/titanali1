import Foundation
import UIKit
import ImageIO

struct LibraryFile: Identifiable {
    let url: URL
    let size: Int
    var id: String { url.lastPathComponent }
    var name: String { String(url.deletingPathExtension().lastPathComponent.dropFirst(37)) }
    var thumbnail: UIImage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways:true,
                kCGImageSourceThumbnailMaxPixelSize:512,
                kCGImageSourceCreateThumbnailWithTransform:true
              ] as CFDictionary) else { return nil }
        return UIImage(cgImage:image)
    }
}

@MainActor final class FileLibrary: ObservableObject {
    @Published private(set) var files: [LibraryFile] = []
    let directory: URL
    let temporary: URL
    init(baseDirectory: URL? = nil) {
        let fm = FileManager.default
        directory = (baseDirectory ?? fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]).appendingPathComponent("Offline", isDirectory:true)
        temporary = (baseDirectory ?? fm.temporaryDirectory).appendingPathComponent("TitanaliExports", isDirectory:true)
        // Only our own temporary exports; never remove website storage or user-selected Files destinations.
        try? fm.removeItem(at:temporary)
        do {try protect(directory);try protect(temporary)} catch { }
        if baseDirectory == nil {protectWebData()}; refresh()
    }
    private func protect(_ url: URL) throws {
        try FileManager.default.createDirectory(at:url, withIntermediateDirectories:true, attributes:[.protectionKey:FileProtectionType.complete])
        var u = url;var r = URLResourceValues();r.isExcludedFromBackup = true;try u.setResourceValues(r)
    }
    func protectWebData() {
        // Exclude app Library (including WK local session data) from device/iCloud backup.
        guard var u = FileManager.default.urls(for:.libraryDirectory, in:.userDomainMask).first else {return}
        var r = URLResourceValues();r.isExcludedFromBackup = true;try? u.setResourceValues(r)
    }
    func refresh() {
        files = ((try? FileManager.default.contentsOfDirectory(at:directory, includingPropertiesForKeys:[.isRegularFileKey,.isSymbolicLinkKey,.fileSizeKey])) ?? []).compactMap {u in
            guard let v = try? u.resourceValues(forKeys:[.isRegularFileKey,.isSymbolicLinkKey,.fileSizeKey]),v.isRegularFile == true,v.isSymbolicLink != true else {return nil}
            return LibraryFile(url:u,size:v.fileSize ?? 0)
        }.sorted {$0.id < $1.id}
    }
    func temporaryFile(data: Data, name: String, mime: String) throws -> URL {
        guard !data.isEmpty, data.count <= NavigationPolicy.exportLimit, NavigationPolicy.extensions[mime] != nil else {throw FileError.invalid}
        let url = temporary.appendingPathComponent(UUID().uuidString+"-"+NavigationPolicy.filename(name,mime:mime))
        try data.write(to:url,options:[.atomic,.completeFileProtection]);return url
    }
    func save(_ source: URL, mime: String) throws {
        guard source.deletingLastPathComponent() == temporary else {throw FileError.invalid}
        let data = try Data(contentsOf:source)
        guard data.count <= NavigationPolicy.exportLimit,NavigationPolicy.matchesImage(data,mime:mime),
              let image = CGImageSourceCreateWithData(data as CFData,nil),CGImageSourceGetCount(image) > 0,
              let properties = CGImageSourceCopyPropertiesAtIndex(image,0,nil) as? [String:Any],
              let width = properties[kCGImagePropertyPixelWidth as String] as? Int,
              let height = properties[kCGImagePropertyPixelHeight as String] as? Int,
              width > 0,height > 0,width <= 16000,height <= 16000,Int64(width)*Int64(height) <= 64000000 else {throw FileError.invalid}
        let dest = directory.appendingPathComponent(source.lastPathComponent)
        guard !FileManager.default.fileExists(atPath:dest.path) else {return}
        refresh()
        guard files.count < NavigationPolicy.offlineCount,files.reduce(0,{$0+$1.size})+data.count <= NavigationPolicy.offlineLimit else {throw FileError.full}
        // Copy exact bytes; display thumbnails never replace this original.
        try data.write(to:dest,options:[.atomic,.completeFileProtection]);refresh()
    }
    func delete(_ item: LibraryFile) throws {
        guard item.url.deletingLastPathComponent() == directory else {throw FileError.invalid}
        try FileManager.default.removeItem(at:item.url);refresh()
    }
    func clear() throws {for file in files {try delete(file)}}
    enum FileError: LocalizedError {
        case invalid, full
        var errorDescription: String? {
            switch self {
            case .invalid: return "نوع، حجم یا محتوای فایل مجاز نیست."
            case .full: return "کتابخانهٔ آفلاین پر است؛ چند فایل را حذف کنید."
            }
        }
    }
}
