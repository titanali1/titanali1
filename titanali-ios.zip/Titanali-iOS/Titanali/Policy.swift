import Foundation

// No wildcard hosts, credentials, cleartext, custom ports or caller-supplied endpoints.
enum NavigationPolicy {
    static let hosts: Set<String> = ["titanali1.ir", "www.titanali1.ir"]
    static func isSite(_ url: URL?) -> Bool {
        guard let url, url.scheme?.lowercased() == "https", let host = url.host?.lowercased(),
              hosts.contains(host), url.port == nil || url.port == 443,
              url.user == nil, url.password == nil else { return false }
        return true
    }
    static func isExternalHTTPS(_ url: URL) -> Bool {
        url.scheme?.lowercased() == "https" && url.host != nil && url.user == nil && url.password == nil
    }
    static let exportLimit = 12 * 1024 * 1024
    static let offlineLimit = 96 * 1024 * 1024
    static let offlineCount = 100
    static let extensions = ["image/png":"png", "image/jpeg":"jpg", "image/webp":"webp",
                             "application/pdf":"pdf", "application/json":"json", "application/zip":"zip",
                             "application/octet-stream":"bin"]
    static func filename(_ input: String, mime: String) -> String {
        let unsafe = CharacterSet.controlCharacters.union(CharacterSet(charactersIn: "/\\:<>|?*\""))
        var stem = (input as NSString).deletingPathExtension.components(separatedBy: unsafe).joined(separator: "-")
        stem = String(stem.prefix(70)).trimmingCharacters(in: CharacterSet(charactersIn: ". "))
        if stem.isEmpty { stem = "titanali" }
        return stem + "." + (extensions[mime] ?? "bin")
    }
    static func matchesImage(_ data: Data, mime: String) -> Bool {
        let b = [UInt8](data.prefix(12))
        switch mime {
        case "image/png": return b.starts(with: [137,80,78,71,13,10,26,10])
        case "image/jpeg": return b.starts(with: [255,216,255])
        case "image/webp": return b.count == 12 && Array(b[0..<4]) == Array("RIFF".utf8) && Array(b[8..<12]) == Array("WEBP".utf8)
        default: return false
        }
    }
}

enum AppConfiguration {
    static let site = URL(string: "https://titanali1.ir/")!
    static var googleClientID: String { value("TAGoogleIOSClientID") }
    static var googleServerClientID: String { value("TAGoogleWebClientID") }
    static var googleScheme: String { value("TAGoogleReversedClientID") }
    private static func value(_ key: String) -> String {
        (Bundle.main.object(forInfoDictionaryKey: key) as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static var googleConfigured: Bool {
        [googleClientID, googleServerClientID].allSatisfy { $0.hasSuffix(".apps.googleusercontent.com") && !$0.contains("UNCONFIGURED") && !$0.contains("$(") }
        && googleScheme == "com.googleusercontent.apps." + String(googleClientID.dropLast(".apps.googleusercontent.com".count))
    }
}
