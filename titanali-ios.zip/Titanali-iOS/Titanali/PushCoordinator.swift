import UIKit
import UserNotifications
import Security

private struct PushRecord: Codable {
    var capability: String
    var ids: [String] = []
    var enabled = false
}
private final class PushNoRedirect: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
@MainActor final class PushCoordinator: NSObject, UNUserNotificationCenterDelegate {
    static let shared = PushCoordinator()
    private var busy = false
    private var currentToken: String?
    private var waiter: CheckedContinuation<String, Error>?
    private var waitingID: UUID?
    private var tapPending = false
    private var openGallery: (() -> Void)?
    private let service = "ir.titanali.push-device-v1"
    private let noRedirect = PushNoRedirect()
    private lazy var session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 15; c.timeoutIntervalForResource = 20
        c.httpCookieStorage = nil; c.urlCredentialStorage = nil
        return URLSession(configuration: c, delegate: noRedirect, delegateQueue: nil)
    }()
    static var configured: Bool { Bundle.main.object(forInfoDictionaryKey: "TANativePushEnabled") as? String == "YES" }
    static var environment: String { Bundle.main.object(forInfoDictionaryKey: "TAPushEnvironment") as? String == "production" ? "production" : "sandbox" }
    private func failure(_ message: String) -> Error { NSError(domain: "TitanaliPush", code: 1, userInfo: [NSLocalizedDescriptionKey: message]) }
    private func query() -> [String: Any] { [kSecClass as String:kSecClassGenericPassword, kSecAttrService as String:service, kSecAttrAccount as String:"device"] }
    private func read() throws -> PushRecord? {
        var q = query(); q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?; let result = SecItemCopyMatching(q as CFDictionary, &value)
        if result == errSecItemNotFound { return nil }
        guard result == errSecSuccess, let data = value as? Data else { throw failure("خواندن مجوز اعلان از Keychain ممکن نشد.") }
        return try JSONDecoder().decode(PushRecord.self, from: data)
    }
    private func write(_ record: PushRecord) throws {
        let data = try JSONEncoder().encode(record)
        var result = SecItemUpdate(query() as CFDictionary, [kSecValueData as String:data] as CFDictionary)
        if result == errSecItemNotFound {
            var q = query(); q[kSecValueData as String] = data
            q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            result = SecItemAdd(q as CFDictionary, nil)
        }
        guard result == errSecSuccess else { throw failure("ذخیرهٔ مجوز اعلان تأیید نشد.") }
    }
    private func record() throws -> PushRecord {
        if let r = try read() { return r }
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else { throw failure("ساخت مجوز امن ممکن نشد.") }
        let cap = Data(bytes).base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "")
        let r = PushRecord(capability: cap); try write(r); return r
    }
    private func api(_ action: String, _ body: [String: Any]? = nil) async throws -> [String: Any] {
        let base = AppConfiguration.site.appendingPathComponent("api.php")
        guard var c = URLComponents(url: base, resolvingAgainstBaseURL: false) else { throw failure("آدرس سرویس معتبر نیست.") }
        c.queryItems = [URLQueryItem(name: "action", value: action)]
        guard let url = c.url, NavigationPolicy.isSite(url) else { throw failure("آدرس سرویس معتبر نیست.") }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
        request.httpMethod = body == nil ? "GET" : "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, http.url == url, (200..<300).contains(http.statusCode), data.count < 32768,
              let result = try JSONSerialization.jsonObject(with: data) as? [String: Any], result["ok"] as? Bool == true else {
            throw failure("درخواست اعلان روی هاست تأیید نشد؛ اتصال، مجوز دستگاه و تنظیم APNs را بررسی کنید.")
        }
        return result
    }
    func status() async throws -> [String: Any] {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        let allowed = [UNAuthorizationStatus.authorized, .provisional, .ephemeral].contains(settings.authorizationStatus)
        // The desired opt-in remains visible when OS permission is revoked, so the
        // user can still remove their server subscription rather than being trapped.
        return ["enabled":try read()?.enabled ?? false, "permissionGranted":allowed, "configured":Self.configured]
    }
    private func token() async throws -> String {
        if let currentToken { return currentToken }
        guard waiter == nil else { throw failure("ثبت دستگاه دیگری در جریان است.") }
        return try await withCheckedThrowingContinuation { continuation in
            let id = UUID(); waitingID = id; waiter = continuation
            UIApplication.shared.registerForRemoteNotifications()
            Task { [weak self] in
                try? await Task.sleep(nanoseconds: 15_000_000_000)
                guard let self, self.waitingID == id else { return }
                self.waitingID = nil; self.waiter = nil
                continuation.resume(throwing: self.failure("توکن پوش دریافت نشد؛ امضای برنامه و اتصال APNs را بررسی کنید."))
            }
        }
    }
    private func sync(_ token: String) async throws {
        var r = try record()
        let result = try await api("push_subscription", ["kind":"apns", "token":token, "capability":r.capability,
            "topic":Bundle.main.bundleIdentifier ?? "", "environment":Self.environment])
        guard let id = result["id"] as? String, id.range(of: "^[a-f0-9]{64}$", options: .regularExpression) != nil else { throw failure("پاسخ ثبت اعلان معتبر نیست.") }
        let previous = r.ids; r.ids = Array(Set(previous + [id])); r.enabled = true
        do { try write(r) }
        catch { _ = try? await api("push_unsubscribe", ["id":id, "capability":r.capability]); throw error }
        // Keep failed old IDs in Keychain; later refresh/opt-out can retry removal.
        for old in previous where old != id {
            if (try? await api("push_unsubscribe", ["id":old, "capability":r.capability])) != nil {
                r.ids.removeAll { $0 == old }; try write(r)
            }
        }
    }
    func enable() async throws {
        guard !busy, Self.configured else { throw failure("این ساخت برای پوش فعال نشده است؛ ناشر باید نسخهٔ دارای امضا و مجوز APNs بسازد.") }
        busy = true; defer { busy = false }
        let cfg = try await api("push_config")
        guard cfg["enabled"] as? Bool == true, cfg["apnsReady"] as? Bool == true,
              cfg["apnsTopic"] as? String == Bundle.main.bundleIdentifier,
              cfg["apnsEnvironment"] as? String == Self.environment else { throw failure("ارسال بسته است یا تنظیم APNs هاست و این نسخه یکسان نیست.") }
        _ = try record()
        guard try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) else { throw failure("اجازهٔ اعلان داده نشد؛ در صورت تمایل از تنظیمات آیفون تغییر دهید.") }
        let deviceToken = try await token()
        try await sync(deviceToken)
    }
    func disable() async throws {
        guard !busy else { throw failure("عملیات قبلی در جریان است.") }
        busy = true; defer { busy = false }
        guard var r = try read() else { return }
        for id in r.ids { _ = try await api("push_unsubscribe", ["id":id, "capability":r.capability]) }
        r.enabled = false; r.ids = []; try write(r)
        UIApplication.shared.unregisterForRemoteNotifications(); currentToken = nil
    }
    func registered(_ data: Data) {
        let token = data.map { String(format:"%02x", $0) }.joined(); currentToken = token
        if let waiter { self.waiter = nil; waitingID = nil; waiter.resume(returning: token); return }
        guard !busy, Self.configured, let r = try? read(), r.enabled else { return }
        busy = true
        Task { defer { busy = false }; try? await sync(token) }
    }
    func registrationFailed() {
        guard let waiter else { return }; self.waiter = nil; waitingID = nil
        waiter.resume(throwing: failure("ثبت APNs ناموفق بود؛ امضا، entitlement و اینترنت را بررسی کنید."))
    }
    func resumeOptIn() {
        guard Self.configured, let r = try? read(), r.enabled else { return }
        UIApplication.shared.registerForRemoteNotifications() // Rotated tokens are synchronized; never prompts for permission.
    }
    func bindOpenGallery(_ action: @escaping () -> Void) {
        openGallery = action
        if tapPending { tapPending = false; action() }
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .list, .sound])
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        // No payload URL is ever opened; notification taps always open our gallery.
        Task { @MainActor in
            if let open = self.openGallery { open() } else { self.tapPending = true }
            completionHandler()
        }
    }
}
@MainActor final class PushAppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().delegate = PushCoordinator.shared
        PushCoordinator.shared.resumeOptIn(); return true
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) { PushCoordinator.shared.registered(deviceToken) }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) { PushCoordinator.shared.registrationFailed() }
}
