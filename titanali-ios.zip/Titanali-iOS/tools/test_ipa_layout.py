#!/usr/bin/env python3
"""ZIP/plist fixtures only; they are NOT compiled apps or install/signing tests."""
import plistlib
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path
from ipa_layout import inspect_layout, write_canonical_ipa


class LayoutTests(unittest.TestCase):
    def fixture(self, directory):
        app = Path(directory) / 'Titanali.app'
        (app / 'SDK.bundle').mkdir(parents=True)
        info = {'CFBundleIdentifier': 'example.fixture.ios',
                'CFBundleExecutable': 'Titanali', 'CFBundleSupportedPlatforms': ['iPhoneOS'],
                'CFBundleShortVersionString': '1.0', 'CFBundleVersion': '1',
                'CFBundleURLTypes': [{'CFBundleURLSchemes': ['example.fixture']}],
                'CFBundleDisplayName': 'نمونهٔ ساختار، نه برنامهٔ واقعی'}
        (app / 'Info.plist').write_bytes(plistlib.dumps(info, fmt=plistlib.FMT_BINARY))
        (app / 'Titanali').write_bytes(b'\xcf\xfa\xed\xfe' + b'FIXTURE NOT A REAL EXECUTABLE')
        (app / 'Titanali').chmod(0o755)
        (app / 'SDK.bundle' / 'Info.plist').write_bytes(plistlib.dumps({'fixture': True}))
        return app, Path(directory) / 'fixture.ipa', info

    def test_explicit_folders_and_main_info_precede_sdk_plists(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            report = write_canonical_ipa(app, ipa)
            with zipfile.ZipFile(ipa) as z:
                self.assertEqual(z.namelist()[:3], ['Payload/', 'Payload/Titanali.app/', 'Payload/Titanali.app/Info.plist'])
                self.assertIn('Payload/Titanali.app/SDK.bundle/', z.namelist())
            self.assertFalse(report['marketApproved'])
            self.assertFalse(report['signatureVerified'])

    def test_xml_conversion_preserves_every_plist_value(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, expected = self.fixture(d)
            before = (app / 'Info.plist').read_bytes()
            write_canonical_ipa(app, ipa)
            with zipfile.ZipFile(ipa) as z:
                data = z.read('Payload/Titanali.app/Info.plist')
                self.assertTrue(data.startswith(b'<?xml'))
                self.assertEqual(plistlib.loads(data), expected)
            self.assertEqual((app / 'Info.plist').read_bytes(), before)

    def test_executable_bytes_and_permissions_are_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            write_canonical_ipa(app, ipa)
            with zipfile.ZipFile(ipa) as z:
                self.assertEqual(z.read('Payload/Titanali.app/Titanali'), (app / 'Titanali').read_bytes())
                self.assertEqual(z.getinfo('Payload/Titanali.app/Titanali').external_attr >> 16, stat.S_IFREG | 0o755)
                self.assertEqual(z.getinfo('Payload/').external_attr >> 16, stat.S_IFDIR | 0o755)

    def test_old_implicit_directory_archive_is_not_reported_canonical(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            with zipfile.ZipFile(ipa, 'w') as z:
                for p in app.rglob('*'):
                    if p.is_file():
                        z.write(p, 'Payload/Titanali.app/' + p.relative_to(app).as_posix())
            with self.assertRaisesRegex(ValueError, 'explicit'):
                inspect_layout(ipa)

    def test_symlink_input_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            (app / 'alias').symlink_to(app / 'Titanali')
            with self.assertRaisesRegex(ValueError, 'Symlinks'):
                write_canonical_ipa(app, ipa)

    def test_source_zip_or_extra_root_info_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            write_canonical_ipa(app, ipa)
            with zipfile.ZipFile(ipa, 'a') as z:
                z.writestr('Info.plist', b'not a substitute for app Info.plist')
            with self.assertRaisesRegex(ValueError, 'Payload'):
                inspect_layout(ipa)

    def test_unsafe_extra_path_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            write_canonical_ipa(app, ipa)
            with zipfile.ZipFile(ipa, 'a') as z:
                z.writestr('Payload/Titanali.app/../escape', b'fixture')
            with self.assertRaisesRegex(ValueError, 'Unsafe'):
                inspect_layout(ipa)

    def test_nonexecutable_app_binary_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            app, ipa, _ = self.fixture(d)
            (app / 'Titanali').chmod(0o644)
            with self.assertRaisesRegex(ValueError, 'execute permission'):
                write_canonical_ipa(app, ipa)


if __name__ == '__main__':
    unittest.main()
