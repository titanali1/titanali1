#!/usr/bin/env python3
"""Structure-only inspection of a publisher-built IPA. Never proves a signature/install.
Does not extract files, contact a marketplace, import credentials, or create an IPA.
"""
import argparse, hashlib, json, plistlib, stat, zipfile
from pathlib import Path, PurePosixPath

MAX_UNCOMPRESSED = 2 * 1024**3

def inspect(path, bundle, version, build):
    with zipfile.ZipFile(path) as z:
        entries = z.infolist()
        if len(entries) > 20000 or sum(i.file_size for i in entries) > MAX_UNCOMPRESSED:
            raise ValueError('Archive exceeds inspection limits')
        names = [i.filename for i in entries]
        if len(names) != len(set(names)):
            raise ValueError('Duplicate ZIP entries')
        for i in entries:
            p = PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or stat.S_ISLNK(i.external_attr >> 16):
                raise ValueError('Unsafe archive path or symlink')
        roots = {n.split('/')[1] for n in names if n.startswith('Payload/') and len(n.split('/')) > 2 and n.split('/')[1].endswith('.app')}
        if len(roots) != 1:
            raise ValueError('Exactly one top-level Payload app is required')
        root = 'Payload/' + roots.pop() + '/'
        info = plistlib.loads(z.read(root + 'Info.plist'))
        for key, expected in [('CFBundleIdentifier', bundle), ('CFBundleShortVersionString', version), ('CFBundleVersion', build)]:
            if str(info.get(key)) != str(expected):
                raise ValueError('Unexpected ' + key)
        if 'iPhoneOS' not in info.get('CFBundleSupportedPlatforms', []):
            raise ValueError('Not an iPhoneOS device artifact')
        executable = info.get('CFBundleExecutable', '')
        if not executable or PurePosixPath(executable).name != executable or '\\' in executable:
            raise ValueError('Invalid executable name')
        with z.open(root + executable) as stream:
            magic = stream.read(4)
        if magic not in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca', b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'):
            raise ValueError('Expected device Mach-O container, not source or a renamed ZIP')
        if root + '_CodeSignature/CodeResources' not in names:
            raise ValueError('Signature resource envelope missing')
        has_profile = root + 'embedded.mobileprovision' in names
    return {'appRoot': root, 'bundleID': bundle, 'version': version, 'build': str(build),
            'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'embeddedProfilePresent': has_profile, 'structureOnly': True,
            'signatureVerified': False, 'installTested': False, 'storeApproved': False}

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('ipa'); p.add_argument('bundle'); p.add_argument('version'); p.add_argument('build')
    a = p.parse_args()
    try:
        print(json.dumps(inspect(a.ipa, a.bundle, a.version, a.build), indent=2))
    except (ValueError, KeyError, zipfile.BadZipFile, plistlib.InvalidFileException) as e:
        p.exit(1, 'IPA STRUCTURE CHECK FAILED: ' + str(e) + '\n')
