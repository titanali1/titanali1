#!/usr/bin/env python3
"""Package an ACTUALLY BUILT iPhoneOS arm64 .app, never a source ZIP.
Not signing, App Store export, device installation or iapps acceptance.
"""
import hashlib,json,os,plistlib,struct,sys,zipfile
from pathlib import Path
app=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleIdentifier']=='ir.titanali.ios'
assert 'iPhoneOS' in info['CFBundleSupportedPlatforms']
binary=app/info['CFBundleExecutable'];header=binary.read_bytes()[:32]
assert header[:4]==b'\xcf\xfa\xed\xfe','Expected an actual little-endian 64-bit Mach-O executable'
assert struct.unpack('<I',header[4:8])[0]==0x100000c,'Expected ARM64 iPhone binary'
assert (app/'native.js').is_file(),'Missing bundled native bridge'
assert not (app/'embedded.mobileprovision').exists(),'This build must not include a provisioning profile'
# Reject strong Swift WebKit overlay linkage in every built image. It aborts
# before main on iOS18.5; successful compilation alone does not catch this.
linkage_images=0
for image in app.rglob('*'):
 if not image.is_file():continue
 with image.open('rb') as f:magic=f.read(4)
 if magic!=b'\xcf\xfa\xed\xfe':continue
 data=image.read_bytes();linkage_images+=1;offset=32
 for _ in range(struct.unpack_from('<I',data,16)[0]):
  cmd,size=struct.unpack_from('<II',data,offset)
  assert size>=8 and offset+size<=len(data),'Malformed Mach-O load command'
  if cmd in (0xc,0x80000018,0x8000001f,0x80000023):
   name_offset=struct.unpack_from('<I',data,offset+8)[0]
   name=data[offset+name_offset:offset+size].split(b'\0')[0].decode()
   assert 'libswiftWebKit.dylib' not in name or cmd==0x80000018,'Strong Swift WebKit overlay dependency: '+str(image)
  offset+=size
assert linkage_images>0
ipa=out/'Titanali-unsigned.ipa'
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(app.rglob('*')):
  if f.is_file():
   assert not f.is_symlink(),'Unexpected symlink; inspect packaging before proceeding'
   z.write(f,'Payload/'+app.name+'/'+str(f.relative_to(app)))
with zipfile.ZipFile(ipa) as z:assert z.testzip() is None
sha=hashlib.sha256(ipa.read_bytes()).hexdigest();(out/'Titanali-unsigned.ipa.sha256').write_text(sha+'  '+ipa.name+'\n')
report={'bundleID':info['CFBundleIdentifier'],'version':info['CFBundleShortVersionString'],'build':info['CFBundleVersion'],'platform':'iPhoneOS','architecture':'arm64','xcodeDeviceBuildSucceeded':True,'webKitLinkageImagesChecked':linkage_images,'strongSwiftWebKitOverlayDependency':False,'publisherSigned':False,'physicalDeviceTested':False,'liveGoogleTested':False,'googleIOSClientConfigured':False,'marketAcceptedUnsignedInput':False,'productionReady':False,'gitCommit':os.environ.get('GITHUB_SHA',''),'ipaSHA256':sha,'ipaBytes':ipa.stat().st_size}
(out/'unsigned-build-report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'READ-ME-FIRST.txt').write_text('UNSIGNED DEBUG DEVICE BUILD — NOT READY FOR END-USER INSTALLATION\nBuilt by Xcode for real iPhoneOS ARM64, not a renamed source ZIP.\nPublisher signing is NOT included. iapps acceptance of unsigned/debug input is NOT confirmed.\nGoogle iOS client IDs are still placeholders; native Google sign-in is NOT configured.\nNo real iPhone/iPad installation, live account login or store approval has occurred.\nThis is a publisher assessment/build input, NOT a production-ready release.\n')
print(json.dumps(report,indent=2))
