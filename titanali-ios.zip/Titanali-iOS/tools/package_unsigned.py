#!/usr/bin/env python3
"""Package an ACTUALLY BUILT iPhoneOS arm64 .app, never a source ZIP.
Not signing, App Store export, device installation or iapps acceptance.
"""
import hashlib,json,os,plistlib,struct,sys,zipfile
from pathlib import Path
app=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleIdentifier']=='ir.titanali.ios'
assert 'iPhoneOS' in info['CFBundleSupportedPlatforms']
binary=app/info['CFBundleExecutable'];header=binary.read_bytes()[:32]
assert header[:4]==b'\xcf\xfa\xed\xfe','Expected an actual little-endian 64-bit Mach-O executable'
assert struct.unpack('<I',header[4:8])[0]==0x100000c,'Expected ARM64 iPhone binary'
assert (app/'native.js').is_file(),'Missing bundled native bridge'
assert not (app/'embedded.mobileprovision').exists(),'This build must not include a provisioning profile'
ipa=out/'Titanali-unsigned.ipa'
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(app.rglob('*')):
  if f.is_file():
   assert not f.is_symlink(),'Unexpected symlink; inspect packaging before proceeding'
   z.write(f,'Payload/'+app.name+'/'+str(f.relative_to(app)))
with zipfile.ZipFile(ipa) as z:assert z.testzip() is None
sha=hashlib.sha256(ipa.read_bytes()).hexdigest();(out/'Titanali-unsigned.ipa.sha256').write_text(sha+'  '+ipa.name+'\n')
report={'bundleID':info['CFBundleIdentifier'],'version':info['CFBundleShortVersionString'],'build':info['CFBundleVersion'],'platform':'iPhoneOS','architecture':'arm64','xcodeDeviceBuildSucceeded':True,'publisherSigned':False,'physicalDeviceTested':False,'liveGoogleTested':False,'googleIOSClientConfigured':False,'marketAcceptedUnsignedInput':False,'productionReady':False,'gitCommit':os.environ.get('GITHUB_SHA',''),'ipaSHA256':sha,'ipaBytes':ipa.stat().st_size}
(out/'unsigned-build-report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'READ-ME-FIRST.txt').write_text('UNSIGNED DEBUG DEVICE BUILD — NOT READY FOR END-USER INSTALLATION\nBuilt by Xcode for real iPhoneOS ARM64, not a renamed source ZIP.\nPublisher signing is NOT included. iapps acceptance of unsigned/debug input is NOT confirmed.\nGoogle iOS client IDs are still placeholders; native Google sign-in is NOT configured.\nNo real iPhone/iPad installation, live account login or store approval has occurred.\nThis is a publisher assessment/build input, NOT a production-ready release.\n')
print(json.dumps(report,indent=2))
