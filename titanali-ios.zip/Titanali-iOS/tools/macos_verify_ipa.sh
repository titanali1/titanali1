#!/bin/sh
# Publisher-local verification only; no signing, credential import, upload or deployment.
set -eu
if [ "$(uname -s)" != Darwin ] || ! command -v codesign >/dev/null 2>&1; then
  echo 'Signature verification requires the publisher Mac. No verification was performed.' >&2
  exit 1
fi
if [ "$#" -ne 5 ]; then
  echo 'Usage: sh tools/macos_verify_ipa.sh app.ipa registered.bundle.id version build TEAMID1234' >&2
  exit 1
fi
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT HUP INT TERM
python3 "$ROOT/tools/inspect_ipa.py" "$1" "$2" "$3" "$4" > "$WORK/structure.json"
# inspect_ipa rejects traversal, duplicates, symlinks and excessive uncompressed sizes before extraction.
python3 - "$1" "$WORK" <<'PY'
import sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:z.extractall(sys.argv[2]+'/extracted')
PY
APP=$(python3 - "$WORK" <<'PY'
import json,sys
from pathlib import Path
w=Path(sys.argv[1]);print(w/'extracted'/json.loads((w/'structure.json').read_text())['appRoot'])
PY
)
codesign --verify --deep --strict --verbose=2 -R="anchor apple generic" "$APP"
codesign -d --verbose=4 "$APP" 2> "$WORK/identity.txt"
codesign -d --entitlements :- "$APP" > "$WORK/entitlements.plist" 2> "$WORK/entitlements-note.txt"
if [ -f "$APP/embedded.mobileprovision" ]; then
  security cms -D -i "$APP/embedded.mobileprovision" > "$WORK/profile.plist"
fi
python3 - "$WORK" "$2" "$5" "$ROOT" <<'PY'
import json,plistlib,sys,datetime,fnmatch
from pathlib import Path
w=Path(sys.argv[1]);bundle=sys.argv[2];team=sys.argv[3];root=Path(sys.argv[4])
identity=(w/'identity.txt').read_text()
if 'Signature=adhoc' in identity or 'TeamIdentifier='+team not in identity.splitlines():
    sys.exit('Ad-hoc identity or unexpected signing team; not accepted as publisher-signed output.')
ent=plistlib.loads((w/'entitlements.plist').read_bytes())
if ent.get('com.apple.developer.team-identifier')!=team:
    sys.exit('Signed team entitlement does not match publisher team.')
app_id=ent.get('application-identifier','')
if not app_id.endswith('.'+bundle):sys.exit('Signed application identifier does not match bundle.')
channel=json.loads((root/'docs/distribution.json').read_text())
if type(channel.get('embeddedProfileRequiredByPublisher')) is not bool:
    sys.exit('Publisher must first declare the profile requirement in distribution.json.')
profile=w/'profile.plist'
if channel['embeddedProfileRequiredByPublisher'] and not profile.exists():sys.exit('Required profile is absent.')
if profile.exists():
    p=plistlib.loads(profile.read_bytes());expiry=p.get('ExpirationDate')
    if not isinstance(expiry,datetime.datetime) or expiry.replace(tzinfo=datetime.timezone.utc)<=datetime.datetime.now(datetime.timezone.utc):
        sys.exit('Provisioning profile is expired or has no expiry date.')
    if team not in p.get('TeamIdentifier',[]):sys.exit('Profile team does not match.')
    if not fnmatch.fnmatchcase(app_id,p.get('Entitlements',{}).get('application-identifier','')):
        sys.exit('Profile application identifier does not permit signed app.')
print('Local signature/team/profile checks passed. This does NOT prove device installation, current revocation status, distribution authorization or iapp acceptance. No submission occurred.')
PY
