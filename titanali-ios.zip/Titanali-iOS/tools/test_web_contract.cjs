'use strict';
// Execute the actual web33 frontend Google flow with the iOS bridge and MOCK server/SDK.
// No live Google, host, WKWebView, Swift or iapp execution is performed.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto'),path=require('path');
const root=path.resolve(__dirname,'..');const html=fs.readFileSync(process.argv[2]||process.env.TITANALI_WEB_INDEX,'utf8');
const contract=JSON.parse(fs.readFileSync(root+'/docs/web-contract.json','utf8'));
assert.equal(crypto.createHash('sha256').update(html).digest('hex'),contract.files['index.html']);
const adapter=fs.readFileSync(root+'/Titanali/Bridge/native.js','utf8');
const start=html.indexOf('function gsiLoad()'),end=html.indexOf('\nfunction ',html.indexOf('function googlePrepare(',start)+20);
assert(start>=0&&end>start);const functions=html.slice(start,end);const checks=[];const check=(n,v)=>{assert(v,n);checks.push(n)};const tick=()=>new Promise(r=>setImmediate(r));
function env({finishOK=true,member=null}={}){
 const calls=[],messages=[],timers=new Map();let nextTimer=0,removed=0,scriptRequests=0;
 const note={textContent:''},box={innerHTML:'',clientWidth:280,replaceChildren(button){this.button=button}},sheet={classList:{contains:x=>x==='open'}};
 const elements={'#googleNote':note,'#googleButton':box,'#regWrap':sheet};
 const doc={querySelector:s=>elements[s],addEventListener(){},createElement(type){if(type==='script'){scriptRequests++;throw Error('Embedded Google OAuth is forbidden in native fixture')};return {addEventListener(n,f){this[n]=f}}}};
 const ctx={document:doc,location:{hostname:'titanali1.ir',protocol:'https:',port:''},crypto:crypto.webcrypto,Map,Promise,Uint8Array,Blob,Error,String,Date,Math,btoa,AUTHSEQ:0,GSIPROMISE:null,REG:{ph:''},member,
  $:s=>elements[s],isFa:()=>true,regSheet(){},toast(){},savedStorage:()=> 'fixture-saved',localStorage:{removeItem(){removed++}},
  memSet(m){ctx.member=m},setTimeout:f=>{timers.set(++nextTimer,f);return nextTimer},clearTimeout:i=>timers.delete(i),addEventListener(){},
  webkit:{messageHandlers:{titanali:{postMessage:m=>messages.push(m)}}},
  taCall:async(action,payload)=>{calls.push({action,payload});if(action==='google_start')return {ok:true,id:'challenge-fixture',clientId:'web-fixture.apps.googleusercontent.com',nonce:'one-use-server-nonce-fixture'};
   return finishOK?{ok:true,phone:'fixture-customer-id',name:'مشتری آزمایشی',tok:'SERVER_MEMBER_FIXTURE',email:'fixture@example.invalid',provider:'google'}:{ok:false,error:'server rejected fixture'}}};
 ctx.window=ctx;ctx.top=ctx;vm.createContext(ctx);vm.runInContext(adapter,ctx);vm.runInContext(functions,ctx);
 return {ctx,calls,messages,box,note,get removed(){return removed},get scripts(){return scriptRequests},async prepare(purpose='login'){ctx.googlePrepare(purpose);await tick()},complete(error=null){const m=messages.at(-1);ctx.__titanaliIOSComplete(m.id,error?{}:{credential:'SDK_FIXTURE_NOT_A_TOKEN'},error)}};
}
(async()=>{
 let e=env();await e.prepare();check('Actual web33 loader uses native adapter without a remote GSI script',e.scripts===0&&!!e.box.button);
 check('Actual web33 flow obtains server challenge before SDK action',e.calls.length===1&&e.calls[0].action==='google_start');
 check('No member or SDK request before explicit customer action',e.ctx.member===null&&e.messages.length===0);
 const clicked=e.box.button.click();check('Original server nonce and web audience reach native request',e.messages[0].nonce==='one-use-server-nonce-fixture'&&e.messages[0].clientId==='web-fixture.apps.googleusercontent.com');
 check('No finish verification before SDK reply',e.calls.length===1);e.complete();await clicked;await tick();
 const finish=e.calls[1];check('Actual frontend sends SDK result to authoritative google_finish',finish.action==='google_finish'&&finish.payload.id==='challenge-fixture'&&finish.payload.credential==='SDK_FIXTURE_NOT_A_TOKEN');
 check('Customer identity comes from server reply, not local SDK claims',e.ctx.member?.tok==='SERVER_MEMBER_FIXTURE'&&e.ctx.member.ph==='fixture-customer-id');
 e=env({finishOK:false});await e.prepare();const rejected=e.box.button.click();e.complete();await rejected;await tick();check('Server rejection never creates a local member',e.ctx.member===null&&e.note.textContent==='server rejected fixture');
 e=env();await e.prepare();const cancelled=e.box.button.click();e.complete('fixture cancellation');await cancelled;await tick();check('SDK cancellation does not call google_finish or create a member',e.calls.length===1&&e.ctx.member===null);
 e=env({member:{tok:'existing-fixture'}});await e.prepare('delete');const deletion=e.box.button.click();e.complete();await deletion;await tick();
 check('Deletion uses a fresh server challenge with delete purpose',e.calls[0].payload.purpose==='delete'&&e.calls[1].payload.purpose==='delete');
 check('Server-confirmed deletion clears local membership and account Saved key',e.ctx.member===null&&e.removed===1);
 e=env();await e.prepare();const stale=e.box.button.click();e.ctx.AUTHSEQ++;e.complete();await stale;await tick();check('A superseded actual web33 flow cannot create a member',e.ctx.member===null&&e.calls.length===1);
 console.log(JSON.stringify({passed:checks.length,failed:0,checks,webSourceSHA256:contract.files['index.html'],serverAndSDKMocked:true,swiftCompiled:false,liveHostTested:false,physicalDeviceTested:false},null,2));
})().catch(e=>{console.error(e);process.exit(1)});
