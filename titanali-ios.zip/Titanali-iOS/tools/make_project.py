#!/usr/bin/env python3
"""Deterministic Xcode project; no XcodeGen, CocoaPods, secret or deploy machinery."""
from pathlib import Path
import hashlib,json,plistlib
ROOT=Path(__file__).resolve().parents[1]
objects={}
def ident(s):return hashlib.sha256(s.encode()).hexdigest()[:24].upper()
def obj(object_key,isa,**fields):
 i=ident(object_key);objects[i]={'isa':isa,**fields};return i
sources=[];resources=[];test_sources=[];refs=[]
for name in ['Policy.swift','FileLibrary.swift','BrowserModel.swift','TitanaliApp.swift']:
 f=obj('ref:'+name,'PBXFileReference',lastKnownFileType='sourcecode.swift',path='Titanali/'+name,sourceTree='<group>');refs.append(f)
 sources.append(obj('build:'+name,'PBXBuildFile',fileRef=f))
for name,typ in [('Titanali/Bridge/native.js','sourcecode.javascript'),('Titanali/Resources/Assets.xcassets','folder.assetcatalog'),('Titanali/Resources/PrivacyInfo.xcprivacy','text.xml')]:
 f=obj('ref:'+name,'PBXFileReference',lastKnownFileType=typ,path=name,sourceTree='<group>');refs.append(f);resources.append(obj('build:'+name,'PBXBuildFile',fileRef=f))
for name in ['PolicyTests.swift','FileLibraryTests.swift']:
 f=obj('ref:'+name,'PBXFileReference',lastKnownFileType='sourcecode.swift',path='TitanaliTests/'+name,sourceTree='<group>');refs.append(f);test_sources.append(obj('build:'+name,'PBXBuildFile',fileRef=f))
config_ref=obj('config','PBXFileReference',lastKnownFileType='text.xcconfig',path='Config/App.xcconfig',sourceTree='<group>');refs.append(config_ref)
info_ref=obj('info','PBXFileReference',lastKnownFileType='text.plist.xml',path='Titanali/Resources/Info.plist',sourceTree='<group>');refs.append(info_ref)
app_product=obj('app-product','PBXFileReference',explicitFileType='wrapper.application',includeInIndex=0,path='Titanali.app',sourceTree='BUILT_PRODUCTS_DIR')
test_product=obj('test-product','PBXFileReference',explicitFileType='wrapper.cfbundle',includeInIndex=0,path='TitanaliTests.xctest',sourceTree='BUILT_PRODUCTS_DIR')
products=obj('products','PBXGroup',children=[app_product,test_product],name='Products',sourceTree='<group>')
main=obj('main-group','PBXGroup',children=refs+[products],sourceTree='<group>')
package=obj('google-package','XCRemoteSwiftPackageReference',repositoryURL='https://github.com/google/GoogleSignIn-iOS.git',requirement={'kind':'exactVersion','version':'10.0.0'})
product=obj('google-product','XCSwiftPackageProductDependency',package=package,productName='GoogleSignIn')
google_build=obj('google-framework','PBXBuildFile',productRef=product)
source_phase=obj('sources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=sources,runOnlyForDeploymentPostprocessing=0)
resource_phase=obj('resources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=resources,runOnlyForDeploymentPostprocessing=0)
framework_phase=obj('frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=[google_build],runOnlyForDeploymentPostprocessing=0)
gate=obj('gate','PBXShellScriptBuildPhase',buildActionMask=2147483647,files=[],inputPaths=['$(SRCROOT)/tools/release_gate.py','$(SRCROOT)/docs/release-checklist.json','$(SRCROOT)/docs/distribution.json'],outputPaths=[],runOnlyForDeploymentPostprocessing=0,shellPath='/bin/sh',shellScript='if [ "$CONFIGURATION" = "Release" ]; then /usr/bin/python3 "$SRCROOT/tools/release_gate.py"; fi\n',alwaysOutOfDate=1,name='Release readiness gate')
common={'IPHONEOS_DEPLOYMENT_TARGET':'16.0','SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','CLANG_ENABLE_MODULES':'YES','CLANG_ENABLE_OBJC_ARC':'YES','CODE_SIGN_STYLE':'Automatic','TARGETED_DEVICE_FAMILY':'1,2','ENABLE_USER_SCRIPT_SANDBOXING':'YES','SWIFT_STRICT_CONCURRENCY':'minimal'}
proj_configs=[];app_configs=[];test_configs=[]
for name in ['Debug','Release']:
 base={**common,'DEBUG_INFORMATION_FORMAT':'dwarf' if name=='Debug' else 'dwarf-with-dsym','SWIFT_OPTIMIZATION_LEVEL':'-Onone' if name=='Debug' else '-O','ONLY_ACTIVE_ARCH':'YES' if name=='Debug' else 'NO','ENABLE_TESTABILITY':'YES' if name=='Debug' else 'NO'}
 if name=='Debug':base['SWIFT_ACTIVE_COMPILATION_CONDITIONS']='DEBUG'
 proj_configs.append(obj('project-'+name,'XCBuildConfiguration',buildSettings=base,name=name))
 app={'PRODUCT_NAME':'Titanali','INFOPLIST_FILE':'Titanali/Resources/Info.plist','GENERATE_INFOPLIST_FILE':'NO','ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','LD_RUNPATH_SEARCH_PATHS':'$(inherited) @executable_path/Frameworks','SUPPORTED_PLATFORMS':'iphoneos iphonesimulator','SUPPORTS_MACCATALYST':'NO','SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD':'NO'}
 app_configs.append(obj('app-'+name,'XCBuildConfiguration',baseConfigurationReference=config_ref,buildSettings=app,name=name))
 tests={'PRODUCT_NAME':'TitanaliTests','PRODUCT_BUNDLE_IDENTIFIER':'ir.titanali.ios.tests','GENERATE_INFOPLIST_FILE':'YES','TEST_HOST':'$(BUILT_PRODUCTS_DIR)/Titanali.app/Titanali','BUNDLE_LOADER':'$(TEST_HOST)','LD_RUNPATH_SEARCH_PATHS':'$(inherited) @executable_path/Frameworks @loader_path/Frameworks','CODE_SIGN_STYLE':'Automatic'}
 test_configs.append(obj('test-'+name,'XCBuildConfiguration',buildSettings=tests,name=name))
def config_list(name,configs):return obj(name,'XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Debug')
app_list=config_list('app-configs',app_configs);test_list=config_list('test-configs',test_configs);project_list=config_list('project-configs',proj_configs)
app_id=ident('app-target');test_id=ident('test-target');project_id=ident('project')
proxy=obj('proxy','PBXContainerItemProxy',containerPortal=project_id,proxyType=1,remoteGlobalIDString=app_id,remoteInfo='Titanali')
dependency=obj('dependency','PBXTargetDependency',target=app_id,targetProxy=proxy)
test_phase=obj('test-sources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=test_sources,runOnlyForDeploymentPostprocessing=0)
test_frameworks=obj('test-frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=[],runOnlyForDeploymentPostprocessing=0)
obj('app-target','PBXNativeTarget',buildConfigurationList=app_list,buildPhases=[gate,source_phase,framework_phase,resource_phase],buildRules=[],dependencies=[],name='Titanali',packageProductDependencies=[product],productName='Titanali',productReference=app_product,productType='com.apple.product-type.application')
obj('test-target','PBXNativeTarget',buildConfigurationList=test_list,buildPhases=[test_phase,test_frameworks],buildRules=[],dependencies=[dependency],name='TitanaliTests',productName='TitanaliTests',productReference=test_product,productType='com.apple.product-type.bundle.unit-test')
obj('project','PBXProject',attributes={'BuildIndependentTargetsInParallel':'YES','LastUpgradeCheck':'1600','TargetAttributes':{app_id:{'CreatedOnToolsVersion':'16.0'},test_id:{'CreatedOnToolsVersion':'16.0','TestTargetID':app_id}}},buildConfigurationList=project_list,compatibilityVersion='Xcode 14.0',developmentRegion='fa',hasScannedForEncodings=0,knownRegions=['fa','en','Base'],mainGroup=main,packageReferences=[package],productRefGroup=products,projectDirPath='',projectRoot='',targets=[app_id,test_id])
def render(x,depth=0):
 if isinstance(x,dict):return '{\n'+''.join('\t'*(depth+1)+json.dumps(str(k))+ ' = '+render(v,depth+1)+';\n' for k,v in x.items())+'\t'*depth+'}'
 if isinstance(x,list):return '(\n'+''.join('\t'*(depth+1)+render(v,depth+1)+',\n' for v in x)+'\t'*depth+')'
 if isinstance(x,int):return str(x)
 return json.dumps(x,ensure_ascii=False)
project={'archiveVersion':1,'classes':{},'objectVersion':56,'objects':objects,'rootObject':project_id}
(ROOT/'Titanali.xcodeproj/project.pbxproj').write_text('// !$*UTF8*$!\n'+render(project)+'\n')
scheme=f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_id}" BuildableName="Titanali.app" BlueprintName="Titanali" ReferencedContainer="container:Titanali.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{test_id}" BuildableName="TitanaliTests.xctest" BlueprintName="TitanaliTests" ReferencedContainer="container:Titanali.xcodeproj"/></TestableReference></Testables></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_id}" BuildableName="Titanali.app" BlueprintName="Titanali" ReferencedContainer="container:Titanali.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{app_id}" BuildableName="Titanali.app" BlueprintName="Titanali" ReferencedContainer="container:Titanali.xcodeproj"/></BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>'''
(ROOT/'Titanali.xcodeproj/xcshareddata/xcschemes/Titanali.xcscheme').write_text(scheme)
info={'CFBundleDevelopmentRegion':'fa','CFBundleDisplayName':'تیتانلی','CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'Titanali','CFBundlePackageType':'APPL','CFBundleShortVersionString':'$(MARKETING_VERSION)','CFBundleVersion':'$(CURRENT_PROJECT_VERSION)','LSRequiresIPhoneOS':True,'UIApplicationSupportsIndirectInputEvents':True,'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False,'UISceneConfigurations':{}},'UILaunchScreen':{},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],'UISupportedInterfaceOrientations~ipad':['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],'NSAppTransportSecurity':{'NSAllowsArbitraryLoads':False},'ITSAppUsesNonExemptEncryption':False,'TAGoogleIOSClientID':'$(GOOGLE_IOS_CLIENT_ID)','TAGoogleWebClientID':'$(GOOGLE_WEB_CLIENT_ID)','TAGoogleReversedClientID':'$(GOOGLE_REVERSED_CLIENT_ID)','CFBundleURLTypes':[{'CFBundleTypeRole':'Editor','CFBundleURLSchemes':['$(GOOGLE_REVERSED_CLIENT_ID)']}],'NSCameraUsageDescription':'فقط اگر خودتان هنگام بارگذاری، گرفتن عکس یا ویدئو را انتخاب کنید، دوربین استفاده می‌شود.','NSMicrophoneUsageDescription':'فقط اگر خودتان ضبط ویدئو هنگام بارگذاری را انتخاب کنید، صدای ویدئو ضبط می‌شود.','NSPhotoLibraryUsageDescription':'برای انتخاب عکس یا فایل تصویری که خودتان می‌خواهید بارگذاری کنید.','NSPhotoLibraryAddUsageDescription':'فقط به درخواست شما برای نگهداری تصویر در گالری آیفون.'}
(ROOT/'Titanali/Resources/Info.plist').write_bytes(plistlib.dumps(info,sort_keys=False))
privacy={'NSPrivacyTracking':False,'NSPrivacyTrackingDomains':[],'NSPrivacyAccessedAPITypes':[],'NSPrivacyCollectedDataTypes':[{'NSPrivacyCollectedDataType':kind,'NSPrivacyCollectedDataTypeLinked':True,'NSPrivacyCollectedDataTypeTracking':False,'NSPrivacyCollectedDataTypePurposes':['NSPrivacyCollectedDataTypePurposeAppFunctionality']} for kind in ['NSPrivacyCollectedDataTypeName','NSPrivacyCollectedDataTypeEmailAddress','NSPrivacyCollectedDataTypePhoneNumber','NSPrivacyCollectedDataTypeUserID','NSPrivacyCollectedDataTypePhotosorVideos','NSPrivacyCollectedDataTypeOtherUserContent']]}
(ROOT/'Titanali/Resources/PrivacyInfo.xcprivacy').write_bytes(plistlib.dumps(privacy,sort_keys=False))
print('Generated project, shared scheme and plist metadata')
