#!/usr/bin/env python3
"""Publisher-channel and IPA STRUCTURE fixtures, not Apple/iapp validation."""
import copy, json, plistlib, subprocess, sys, tempfile, unittest, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import release_gate, inspect_ipa

class IappTests(unittest.TestCase):
    def env(self):
        return {'DEVELOPMENT_TEAM':'MOCKTEAM00','PRODUCT_BUNDLE_IDENTIFIER':'example.fixture.ios',
                'GOOGLE_IOS_CLIENT_ID':'ios-fixture.apps.googleusercontent.com',
                'GOOGLE_WEB_CLIENT_ID':'web-fixture.apps.googleusercontent.com',
                'GOOGLE_REVERSED_CLIENT_ID':'com.googleusercontent.apps.ios-fixture'}
    def checklist(self):
        return {**{k:True for k in release_gate.REQUIRED},'authenticationResolution':'publisher-reviewed-channel',
                'nonAppStoreAuthenticationReview':'UNIT TEST ONLY, not a real review. '+('x'*160)}
    def channel(self):
        return {'channel':'iapp','artifactRequested':'native-ipa','publisherAuthorizationVerified':True,
                'marketInstructionsReviewed':True,'marketServiceURL':'https://fixture.invalid',
                'marketInstructionsReference':'UNIT TEST ONLY, no actual instructions.',
                'distributionMethod':'fixture-authorized-route','embeddedProfileRequiredByPublisher':True,
                'distributionAuthorizationEvidence':'UNIT TEST ONLY, no real authorization. '+('x'*160)}
    def test_owner_choices_are_recorded_without_inventing_approval(self):
        d=json.loads((ROOT/'docs/distribution.json').read_text())
        self.assertEqual(d['channel'],'iapp');self.assertEqual(d['appAudience'],'customers')
        self.assertTrue(d['publisherAvailableReportedByOwner']);self.assertFalse(d['publisherAuthorizationVerified'])
        self.assertEqual(d['artifactRequested'],'native-ipa');self.assertFalse(d['marketInstructionsReviewed'])
    def test_iapp_defaults_cannot_release_even_with_other_checkboxes_set(self):
        self.assertTrue(release_gate.evaluate(self.checklist(),self.env()))
    def test_configured_fixture_passes_only_as_local_workflow_check(self):
        self.assertEqual(release_gate.evaluate(self.checklist(),self.env(),self.channel()),[])
        for key in ('publisherAuthorizationVerified','marketInstructionsReviewed'):
            d=self.channel();d[key]=False;self.assertTrue(release_gate.evaluate(self.checklist(),self.env(),d))
        for key in ('marketServiceURL','marketInstructionsReference','distributionMethod','distributionAuthorizationEvidence'):
            d=self.channel();d[key]='';self.assertTrue(release_gate.evaluate(self.checklist(),self.env(),d))
    def test_pwa_or_enterprise_is_not_assumed_a_public_customer_ipa(self):
        for artifact in ('pwa','unconfirmed',''):
            d=self.channel();d['artifactRequested']=artifact
            self.assertTrue(release_gate.evaluate(self.checklist(),self.env(),d))
        d=self.channel();d['distributionMethod']='enterprise'
        self.assertTrue(release_gate.evaluate(self.checklist(),self.env(),d))
    def test_channel_auth_review_cannot_bypass_app_store_requirements(self):
        self.assertTrue(release_gate.evaluate(self.checklist(),self.env(),{'channel':'app-store'}))
        d=self.checklist();d['nonAppStoreAuthenticationReview']=''
        self.assertTrue(release_gate.evaluate(d,self.env(),self.channel()))
    def fixture(self,path,extra=None,remove=None,platform='iPhoneOS'):
        info={'CFBundleIdentifier':'example.fixture.ios','CFBundleShortVersionString':'1.0.1','CFBundleVersion':'2',
              'CFBundleExecutable':'Titanali','CFBundleSupportedPlatforms':[platform]}
        files={'Payload/Titanali.app/Info.plist':plistlib.dumps(info),
               'Payload/Titanali.app/Titanali':b'\xcf\xfa\xed\xfe'+b'FIXTURE, NOT AN EXECUTABLE',
               'Payload/Titanali.app/_CodeSignature/CodeResources':b'FIXTURE, NOT A SIGNATURE'}
        if remove:files.pop(remove)
        files.update(extra or {})
        with zipfile.ZipFile(path,'w') as z:
            for n,b in files.items():z.writestr(n,b)
    def test_ipa_shape_fixture_never_claims_a_real_signature_or_install(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture.ipa';self.fixture(p)
            result=inspect_ipa.inspect(p,'example.fixture.ios','1.0.1','2')
            self.assertTrue(result['structureOnly']);self.assertFalse(result['signatureVerified'])
            self.assertFalse(result['installTested']);self.assertFalse(result['storeApproved'])
            with self.assertRaises(ValueError):inspect_ipa.inspect(p,'wrong.fixture.ios','1.0.1','2')
    def test_unsafe_or_simulator_or_unsigned_or_renamed_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixture.ipa'
            cases=[{'extra':{'../escape':b'x'}},{'extra':{'/absolute':b'x'}},
                   {'platform':'iPhoneSimulator'},{'remove':'Payload/Titanali.app/_CodeSignature/CodeResources'},
                   {'extra':{'Payload/Titanali.app/Titanali':b'print("not an executable")'}}]
            for case in cases:
                self.fixture(p,**case)
                with self.assertRaises(ValueError):inspect_ipa.inspect(p,'example.fixture.ios','1.0.1','2')
            with zipfile.ZipFile(p,'w') as z:z.writestr('README.md','source only')
            with self.assertRaises(ValueError):inspect_ipa.inspect(p,'example.fixture.ios','1.0.1','2')
    def test_mac_verification_script_is_syntax_valid_and_cannot_upload(self):
        script=ROOT/'tools/macos_verify_ipa.sh';subprocess.run(['sh','-n',str(script)],check=True)
        s=script.read_text();self.assertIn('codesign --verify --deep --strict',s)
        self.assertNotIn('-exportArchive',s);self.assertNotIn('altool',s)
        self.assertNotIn('curl ',s);self.assertNotIn('security import',s)
        if sys.platform!='darwin':
            result=subprocess.run(['sh',str(script)],capture_output=True,text=True)
            self.assertEqual(result.returncode,1);self.assertIn('No verification was performed',result.stderr)
    def test_current_customer_version_and_handoff_documents(self):
        s=(ROOT/'Config/App.xcconfig').read_text();self.assertIn('MARKETING_VERSION = 1.0.4',s)
        self.assertIn('CURRENT_PROJECT_VERSION = 5',s);self.assertNotIn('android-admin',(ROOT/'Titanali/Policy.swift').read_text())
        for n in ('docs/IAPP.fa.md','docs/IAPP-PUBLISHER.md','docs/iapp-metadata.json','docs/web-contract.json'):
            self.assertTrue((ROOT/n).is_file(),n)

if __name__=='__main__':unittest.main(verbosity=2)
