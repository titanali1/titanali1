#!/bin/bash
# Build-only input for publisher assessment. No signing, secrets, publishing or host deployment.
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]] || ! command -v xcodebuild >/dev/null; then
  echo 'Mac and Xcode are required; no IPA was built.' >&2; exit 1
fi
OUT="${TA_BUILD_OUTPUT:-$PWD/release-output}"
DERIVED="${TA_DERIVED_DATA:-$OUT/DerivedData-device}"
SPM="${TA_SPM_CACHE:-$OUT/SourcePackages}"
mkdir -p "$OUT"
xcodebuild -version | tee "$OUT/xcode-version.txt"
xcodebuild -project Titanali.xcodeproj -scheme Titanali -configuration Debug \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED" -clonedSourcePackagesDirPath "$SPM" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
  DEVELOPMENT_TEAM='' ARCHS=arm64 ONLY_ACTIVE_ARCH=NO build \
  2>&1 | tee "$OUT/device-build.log"
APP="$DERIVED/Build/Products/Debug-iphoneos/Titanali.app"
xcrun lipo -info "$APP/Titanali" | tee "$OUT/architecture.txt"
python3 tools/package_unsigned.py "$APP" "$OUT"
if [[ -f Titanali.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved ]]; then
  cp Titanali.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved "$OUT/Package.resolved"
fi
