#!/usr/bin/env python3
"""Local source/configuration tests only. No Swift type checking, Apple SDK or live OAuth."""
import unittest,sys,json,plistlib,subprocess,hashlib,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import release_gate
from openstep_plist import loads
from PIL import Image
from tree_sitter import Language,Parser
import tree_sitter_swift

class ProjectTests(unittest.TestCase):
 def test_xcode_graph_has_app_test_targets_and_shared_scheme(self):
  graph=loads((ROOT/'Titanali.xcodeproj/project.pbxproj').read_text());objects=graph['objects'];project=objects[graph['rootObject']]
  self.assertEqual(project['isa'],'PBXProject');self.assertEqual(len(project['targets']),2)
  for target in project['targets']:
   self.assertEqual(objects[target]['isa'],'PBXNativeTarget')
   self.assertIn(objects[target]['productReference'],objects)
   for phase in objects[target]['buildPhases']:self.assertIn(phase,objects)
  import xml.etree.ElementTree as ET
  scheme=ET.parse(ROOT/'Titanali.xcodeproj/xcshareddata/xcschemes/Titanali.xcscheme')
  for x in scheme.findall('.//BuildableReference'):self.assertIn(x.attrib['BlueprintIdentifier'],project['targets'])
 def test_source_and_resource_references_exist(self):
  graph=loads((ROOT/'Titanali.xcodeproj/project.pbxproj').read_text())
  for obj in graph['objects'].values():
   if obj['isa']=='PBXFileReference' and obj.get('sourceTree')=='<group>':self.assertTrue((ROOT/obj['path']).exists(),obj['path'])
  phases=[x for x in graph['objects'].values() if x['isa']=='PBXResourcesBuildPhase']
  refs=[graph['objects'][graph['objects'][i]['fileRef']]['path'] for x in phases for i in x['files']]
  self.assertIn('Titanali/Bridge/native.js',refs);self.assertIn('Titanali/Resources/PrivacyInfo.xcprivacy',refs)
 def test_project_generation_is_deterministic(self):
  paths=['Titanali.xcodeproj/project.pbxproj','Titanali.xcodeproj/xcshareddata/xcschemes/Titanali.xcscheme','Titanali/Resources/Info.plist','Titanali/Resources/PrivacyInfo.xcprivacy']
  before={p:(ROOT/p).read_bytes() for p in paths}
  subprocess.run([sys.executable,str(ROOT/'tools/make_project.py')],check=True,stdout=subprocess.DEVNULL)
  self.assertEqual(before,{p:(ROOT/p).read_bytes() for p in paths})
 def test_swift_grammar_only(self):
  parser=Parser(Language(tree_sitter_swift.language()));files=list(ROOT.rglob('*.swift'));self.assertEqual(len(files),7)
  for f in files:self.assertFalse(parser.parse(f.read_bytes()).root_node.has_error,f.name)
 def test_ats_and_usage_descriptions(self):
  d=plistlib.loads((ROOT/'Titanali/Resources/Info.plist').read_bytes())
  self.assertIs(d['NSAppTransportSecurity']['NSAllowsArbitraryLoads'],False)
  self.assertNotIn('NSAllowsArbitraryLoadsInWebContent',d['NSAppTransportSecurity'])
  self.assertTrue(d['NSCameraUsageDescription']);self.assertTrue(d['NSPhotoLibraryUsageDescription'])
  self.assertEqual(d['CFBundleURLTypes'][0]['CFBundleURLSchemes'],['$(GOOGLE_REVERSED_CLIENT_ID)'])
  self.assertIn('UIApplicationSceneManifest',d)
 def test_privacy_manifest_parses_and_no_tracking_permission(self):
  d=plistlib.loads((ROOT/'Titanali/Resources/PrivacyInfo.xcprivacy').read_bytes())
  self.assertFalse(d['NSPrivacyTracking']);self.assertEqual(d['NSPrivacyTrackingDomains'],[])
  self.assertTrue(all(not x['NSPrivacyCollectedDataTypeTracking'] for x in d['NSPrivacyCollectedDataTypes']))
  info=plistlib.loads((ROOT/'Titanali/Resources/Info.plist').read_bytes());self.assertNotIn('NSUserTrackingUsageDescription',info)
 def test_icon_is_opaque_square_1024_and_matches_manifest(self):
  path=ROOT/'Titanali/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png';im=Image.open(path)
  self.assertEqual(im.size,(1024,1024));self.assertEqual(im.mode,'RGB');im.close()
  metadata=json.loads((ROOT/'docs/branding.json').read_text());self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),metadata['outputSHA256'])
  self.assertEqual(metadata['sourceSHA256'],'7f8f052b14e74a1f4c98c96b8e5e9b80eb50ee3e00ebd6156254e15f824c6b2c')
 def test_exact_google_package_and_nonce_api_contract(self):
  graph=loads((ROOT/'Titanali.xcodeproj/project.pbxproj').read_text());packages=[x for x in graph['objects'].values() if x['isa']=='XCRemoteSwiftPackageReference']
  self.assertEqual(len(packages),1);self.assertEqual(packages[0]['requirement'],{'kind':'exactVersion','version':'10.0.0'})
  code=(ROOT/'Titanali/BrowserModel.swift').read_text();self.assertIn('nonce:request.nonce',code);self.assertIn('serverClientID:request.clientID',code)
  self.assertIn('service.signOut()',code);self.assertNotIn('gmail.readonly',code)
 def test_release_is_blocked_with_supplied_defaults(self):
  d=json.loads((ROOT/'docs/release-checklist.json').read_text());errors=release_gate.evaluate(d,{})
  completed={'packageDependenciesResolvedAndArchived'}
  self.assertEqual({x for x in release_gate.REQUIRED if d[x]},completed)
  for key in set(release_gate.REQUIRED)-completed:self.assertIn('Unfinished: '+key,errors)
  self.assertTrue(errors)
  result=subprocess.run([sys.executable,str(ROOT/'tools/release_gate.py')],capture_output=True,text=True,env={})
  self.assertEqual(result.returncode,1);self.assertIn('RELEASE BLOCKED',result.stderr)
 def test_completed_readiness_facts_have_matching_native_evidence(self):
  d=json.loads((ROOT/'docs/release-checklist.json').read_text())
  proof=json.loads((ROOT/'docs/cloud-build-status.json').read_text())
  self.assertTrue(proof['xcodeDeviceBuildSucceeded']);self.assertIn(proof['simulatorXCTestPassed'],(6,7))
  self.assertEqual(proof['simulatorXCTestFailed'],0)
  self.assertFalse(d['debugSimulatorBuiltAndUnitTestsPassed'])
  self.assertEqual(d['historicalBuildBeforePush'],proof['buildRunURL'])
  lock=ROOT/d['completionEvidence']['packageDependenciesResolvedAndArchived']['file']
  self.assertEqual(hashlib.sha256(lock.read_bytes()).hexdigest(),proof['evidenceSHA256']['Package.resolved'])
  for key in ('publisherSigned','physicalDeviceTested','productionReady'):
   self.assertFalse(proof[key])
 def test_owner_google_ids_and_scheme_are_consistent_in_source(self):
  values={}
  for line in (ROOT/'Config/App.xcconfig').read_text().splitlines():
   if ' = ' in line:
    k,v=line.split(' = ',1);values[k]=v
  ios=values['GOOGLE_IOS_CLIENT_ID'];web=values['GOOGLE_WEB_CLIENT_ID']
  self.assertEqual(ios,'255964558475-151gk5kv8fqdbvv111i6edmst4ckvml2.apps.googleusercontent.com')
  self.assertEqual(web,'255964558475-9neruvlnp7a2phakdjj7uf0695ujnsae.apps.googleusercontent.com')
  self.assertNotEqual(ios,web)
  self.assertEqual(values['GOOGLE_REVERSED_CLIENT_ID'],'com.googleusercontent.apps.'+ios.removesuffix('.apps.googleusercontent.com'))
  model=(ROOT/'Titanali/BrowserModel.swift').read_text()
  self.assertIn('clientID == AppConfiguration.googleServerClientID',model)
  self.assertNotIn('UNCONFIGURED',ios+web)
 def test_release_build_really_runs_gate(self):
  graph=loads((ROOT/'Titanali.xcodeproj/project.pbxproj').read_text());app=next(x for x in graph['objects'].values() if x['isa']=='PBXNativeTarget' and x['name']=='Titanali')
  first=graph['objects'][app['buildPhases'][0]];self.assertEqual(first['isa'],'PBXShellScriptBuildPhase')
  self.assertIn('"$CONFIGURATION" = "Release"',first['shellScript']);self.assertIn('release_gate.py',first['shellScript'])
  for path in first['inputPaths']:self.assertTrue((ROOT/path.replace('$(SRCROOT)/','')).exists())
 def test_apple_auth_cannot_be_claimed_implemented_by_checkbox(self):
  d={x:True for x in release_gate.REQUIRED};d.update(authenticationResolution='sign-in-with-apple',appleBackendAndRevocationTestsEvidence='fixture')
  e=release_gate.evaluate(d,self.valid_environment(),{'channel':'app-store'});self.assertTrue(any('absent' in x for x in e))
 def test_gate_distinguishes_configured_fixture_from_real_store_approval(self):
  d={x:True for x in release_gate.REQUIRED};d.update(authenticationResolution='documented-applicable-exception',appReviewAuthenticationExceptionRationale='UNIT TEST FIXTURE ONLY. Not a real policy exception or store approval. '+('x'*150))
  self.assertEqual(release_gate.evaluate(d,self.valid_environment(),{'channel':'app-store'}),[])
  for key in release_gate.REQUIRED:
   copy=dict(d);copy[key]=False;self.assertTrue(release_gate.evaluate(copy,self.valid_environment(),{'channel':'app-store'}))
  env=self.valid_environment();env['GOOGLE_WEB_CLIENT_ID']=env['GOOGLE_IOS_CLIENT_ID'];self.assertTrue(release_gate.evaluate(d,env,{'channel':'app-store'}))
 def test_mac_script_is_syntax_valid_and_does_not_upload(self):
  p=ROOT/'tools/macos_validate.sh';subprocess.run(['sh','-n',str(p)],check=True)
  text=p.read_text();self.assertNotIn('altool',text);self.assertNotIn('notarytool',text);self.assertNotIn('-exportArchive',text)
  self.assertIn('-configuration Debug',text);self.assertIn('CODE_SIGNING_ALLOWED=NO',text)
 def test_native_boundaries_present_not_runtime_proof(self):
  code=(ROOT/'Titanali/BrowserModel.swift').read_text();library=(ROOT/'Titanali/FileLibrary.swift').read_text()
  self.assertIn('frame.isMainFrame',code);self.assertIn('origin.protocol == "https"',code);self.assertIn('NavigationPolicy.isSite(web.url)',code)
  self.assertIn('weak var owner',code);self.assertIn('completedUnitCount',code);self.assertIn('download.cancel',code)
  self.assertIn('isExcludedFromBackup = true',library);self.assertIn('.completeFileProtection',library)
  self.assertNotIn('jpegData(',library);self.assertNotIn('pngData(',library)
  self.assertNotIn('URLCredential(trust:',code);self.assertNotIn('print(',code)
 @staticmethod
 def valid_environment():
  return {'DEVELOPMENT_TEAM':'MOCKTEAM00','PRODUCT_BUNDLE_IDENTIFIER':'example.fixture.ios','GOOGLE_IOS_CLIENT_ID':'ios-fixture.apps.googleusercontent.com','GOOGLE_WEB_CLIENT_ID':'web-fixture.apps.googleusercontent.com','GOOGLE_REVERSED_CLIENT_ID':'com.googleusercontent.apps.ios-fixture'}

if __name__=='__main__':unittest.main(verbosity=2)
