#!/usr/bin/env python3
"""Canonical unsigned IPA ZIP layout. Does not sign, compile or approve an app."""
import plistlib
import stat
import time
import zipfile
from pathlib import Path, PurePosixPath


def inspect_layout(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise ValueError('Duplicate ZIP entries or bad CRC')
        for entry in archive.infolist():
            parts = PurePosixPath(entry.filename).parts
            if (not parts or parts[0] != 'Payload' or '..' in parts
                    or '\\' in entry.filename or entry.filename.startswith('/')
                    or stat.S_ISLNK(entry.external_attr >> 16)):
                raise ValueError('Unsafe or non-Payload ZIP entry')
        roots = {PurePosixPath(n).parts[1] for n in names
                 if len(PurePosixPath(n).parts) > 1}
        if len(roots) != 1 or not next(iter(roots)).endswith('.app'):
            raise ValueError('Expected exactly one app directly inside Payload')
        app = 'Payload/' + next(iter(roots)) + '/'
        info_path = app + 'Info.plist'
        if names[:3] != ['Payload/', app, info_path]:
            raise ValueError('Expected explicit Payload/app folders followed by app-root Info.plist')
        for name in names:
            entry = archive.getinfo(name)
            if name.endswith('/'):
                if not stat.S_ISDIR(entry.external_attr >> 16):
                    raise ValueError('Directory entry lacks directory attributes')
            else:
                for parent in PurePosixPath(name).parents:
                    if str(parent) != '.' and str(parent) + '/' not in names:
                        raise ValueError('Implicit directory: ' + str(parent))
        data = archive.read(info_path)
        if not data.startswith(b'<?xml'):
            raise ValueError('App-root Info.plist must use XML for reader compatibility')
        info = plistlib.loads(data)
        executable = info.get('CFBundleExecutable', '')
        if not executable or '/' in executable or '\\' in executable:
            raise ValueError('Invalid CFBundleExecutable')
        executable_path = app + executable
        if not archive.getinfo(executable_path).external_attr >> 16 & 0o111:
            raise ValueError('App executable lacks execute permission')
        if archive.read(executable_path)[:4] != b'\xcf\xfa\xed\xfe':
            raise ValueError('Expected built 64-bit Mach-O executable')
        if info.get('CFBundleSupportedPlatforms') != ['iPhoneOS']:
            raise ValueError('Not an iPhoneOS device app')
        return {
            'appRoot': app, 'infoPlistPath': info_path,
            'appInfoPlistFormat': 'xml', 'explicitDirectoryEntries': True,
            'appInfoPlistIsFirstFile': True, 'zipCRCVerified': True,
            'bundleID': info['CFBundleIdentifier'],
            'version': info['CFBundleShortVersionString'],
            'build': info['CFBundleVersion'],
            'directoryEntries': sum(n.endswith('/') for n in names),
            'fileEntries': sum(not n.endswith('/') for n in names),
            'signatureVerified': False, 'marketApproved': False,
        }


def write_canonical_ipa(app, output):
    app, output = Path(app), Path(output)
    if not app.is_dir() or not app.name.endswith('.app') or app.is_symlink():
        raise ValueError('Expected a real app directory')
    info_path = app / 'Info.plist'
    info = plistlib.loads(info_path.read_bytes())
    xml = plistlib.dumps(info, fmt=plistlib.FMT_XML, sort_keys=False)
    if plistlib.loads(xml) != info:
        raise ValueError('Info.plist conversion changed its meaning')
    files, directories = {}, {'Payload/', 'Payload/' + app.name + '/'}
    for source in sorted(app.rglob('*')):
        if source.is_symlink():
            raise ValueError('Symlinks need explicit review before packaging')
        if not source.is_file():
            continue
        name = 'Payload/' + app.name + '/' + source.relative_to(app).as_posix()
        files[name] = source
        for parent in PurePosixPath(name).parents:
            if str(parent) != '.':
                directories.add(str(parent) + '/')
    info_name = 'Payload/' + app.name + '/Info.plist'
    timestamp = time.localtime(info_path.stat().st_mtime)[:6]
    if timestamp[0] < 1980:
        timestamp = (1980, 1, 1, 0, 0, 0)

    def put(archive, name, source=None):
        entry = zipfile.ZipInfo(name, timestamp)
        entry.create_system = 3
        entry.compress_type = zipfile.ZIP_DEFLATED
        if source is None:
            entry.external_attr = ((stat.S_IFDIR | 0o755) << 16) | 0x10
            data = b''
        else:
            permissions = 0o755 if source.stat().st_mode & 0o111 else 0o644
            entry.external_attr = (stat.S_IFREG | permissions) << 16
            data = xml if name == info_name else source.read_bytes()
        archive.writestr(entry, data)

    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        put(archive, 'Payload/')
        put(archive, 'Payload/' + app.name + '/')
        put(archive, info_name, info_path)
        for directory in sorted(directories, key=lambda n: (n.count('/'), n)):
            if directory not in ('Payload/', 'Payload/' + app.name + '/'):
                put(archive, directory)
        for name, source in sorted(files.items()):
            if name != info_name:
                put(archive, name, source)
    return inspect_layout(output)
