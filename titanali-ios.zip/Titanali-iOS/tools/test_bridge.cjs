'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const source=fs.readFileSync(require('path').join(__dirname,'../Titanali/Bridge/native.js'),'utf8');
let passed=0;const checks=[];const check=(name,v)=>{assert(v,name);checks.push(name);passed++};
function environment({host='titanali1.ir',protocol='https:',port='',iframe=false,channel=true}={}){
 const messages=[],listeners={},timers=new Map(),alerts=[];let timerID=0;
 const note={textContent:''};
 const document={querySelector:()=>note,addEventListener:(name,cb)=>{listeners[name]=cb},createElement:()=>({disabled:false,addEventListener(name,cb){this[name]=cb}})};
 const window={document,location:{hostname:host,protocol,port},alert:s=>alerts.push(s),addEventListener:(name,cb)=>{listeners[name]=cb}};
 window.top=iframe?{}:window;
 if(channel)window.webkit={messageHandlers:{titanali:{postMessage:message=>messages.push(message)}}};
 const context={window,document,location:window.location,crypto:crypto.webcrypto,Map,Promise,Uint8Array,Blob,Error,String,
   setTimeout:cb=>{timers.set(++timerID,cb);return timerID},clearTimeout:id=>timers.delete(id),btoa,
   fetch:async()=>new Response(Buffer.from([137,80,78,71,13,10,26,10]),{headers:{'Content-Type':'image/png'}})};
 vm.runInNewContext(source,context);
 return {window,document,messages,listeners,timers,alerts,note,context,render(options){const box={replaceChildren(button){this.button=button}};window.google.accounts.id.initialize(options);window.google.accounts.id.renderButton(box);return box.button}};
}
(async()=>{
 for(const config of [{host:'titanali1.ir.evil.example'},{host:'evil.example'},{protocol:'http:'},{port:'444'},{iframe:true},{channel:false}]){
  const e=environment(config);check('No native adapter in forbidden context '+JSON.stringify(config),!e.window.__titanaliIOSInstalled&&!e.window.google);
 }
 for(const host of ['titanali1.ir','www.titanali1.ir']){const e=environment({host});check('Exact HTTPS origin is supported '+host,!!e.window.google)}
 let e=environment();const adapter=e.window.google;vm.runInNewContext(source,e.context);check('Injection is idempotent',e.window.google===adapter);
 let received=null;
 const options={client_id:'web-public-id',nonce:'server-one-use-nonce',callback:r=>{received=r}};
 let button=e.render(options);check('Google adapter renders a user-action button',button.type==='button'&&typeof button.click==='function');
 check('No sign-in or account callback before user action',e.messages.length===0&&received===null);
 const click=button.click();check('Button disables during native authentication',button.disabled);
 const request=e.messages[0];check('Native request has UUID, original nonce and web audience',/^[a-f0-9-]{36}$/.test(request.id)&&request.nonce===options.nonce&&request.clientId===options.client_id&&request.type==='google');
 check('No account callback before SDK completion',received===null);
 e.window.__titanaliIOSComplete('unknown',{credential:'wrong'},null);check('Unknown callback is ignored',received===null);
 e.window.__titanaliIOSComplete(request.id,{credential:'SDK_FIXTURE_NOT_A_REAL_TOKEN'},null);await click;
 check('SDK credential reaches existing server-verification callback',received?.credential==='SDK_FIXTURE_NOT_A_REAL_TOKEN');
 check('Successful auth clears timeout and enables button',e.timers.size===0&&!button.disabled);
 received=null;e.window.__titanaliIOSComplete(request.id,{credential:'replay'},null);check('Native reply is single-use',received===null);
 e=environment();button=e.render(options);const rejected=button.click();e.window.__titanaliIOSComplete(e.messages[0].id,{},'Cancelled by user');await rejected;
 check('Cancelled auth shows error, reenables button and creates no member',e.note.textContent==='Cancelled by user'&&!button.disabled&&received===null);
 e=environment();let old=null;button=e.render({...options,callback:r=>{old=r}});const stale=button.click();e.render({...options,nonce:'new'});
 e.window.__titanaliIOSComplete(e.messages[0].id,{credential:'old'},null);await stale;check('Stale initialization cannot sign in a newer form',old===null);
 e=environment();button=e.render(options);const timed=button.click();for(const callback of [...e.timers.values()])callback();await timed;
 check('Native auth timeout displays retryable error',e.note.textContent.includes('زمان')&&!button.disabled);
 e=environment();button=e.render(options);const departed=button.click();e.listeners.pagehide();await departed;
 check('Page close cancels pending callback and timeout',e.timers.size===0&&e.note.textContent.includes('بسته'));
 e=environment();const calls=[];let stopped=false,prevented=false;
 const bytes=Buffer.from([137,80,78,71,13,10,26,10]);
 const event={target:{closest:()=>({href:'blob:https://titanali1.ir/uuid',download:'original.png'})},preventDefault(){prevented=true},stopImmediatePropagation(){stopped=true}};
 const exporting=e.listeners.click(event);await new Promise(resolve=>setImmediate(resolve));
 const file=e.messages[0];check('Blob download intercepts browser action',prevented&&stopped);
 check('Native export retains exact original PNG bytes',file.type==='export'&&file.name==='original.png'&&file.mime==='image/png'&&Buffer.from(file.base64,'base64').equals(bytes));
 e.window.__titanaliIOSComplete(file.id,{prepared:true},null);await exporting;check('Export preparation completes without false saved message',e.alerts.length===0&&e.timers.size===0);
 e=environment();e.context.fetch=async()=>({ok:true,blob:async()=>({size:12*1024*1024+1})});await e.listeners.click(event);
 check('Oversized blob rejected before decoding or messaging',e.messages.length===0&&e.alerts[0].includes('۱۲'));
 e=environment();e.context.fetch=async()=>({ok:true,blob:async()=>({size:0})});await e.listeners.click(event);
 check('Empty blob rejected',e.messages.length===0&&e.alerts.length===1);
 e=environment();e.context.fetch=async()=>{throw new Error('Network fixture')};await e.listeners.click(event);
 check('Failed blob fetch cannot report success',e.messages.length===0&&e.alerts[0]==='Network fixture');
 e=environment();await e.listeners.click({target:{closest:()=>({href:'https://titanali1.ir/media/a.png',download:'a.png'})},preventDefault(){throw Error('must remain WKDownload')}});
 check('HTTP downloads remain with WKDownload',e.messages.length===0);
 e=environment();let push=e.window.TitanaliNativePush.status();check('Native push status uses guarded request channel',e.messages[0].type==='push_status');e.window.__titanaliIOSComplete(e.messages[0].id,{enabled:false,configured:false},null);let status=await push;check('Unsigned native push remains explicitly gated',status.enabled===false&&status.configured===false);
 push=e.window.TitanaliNativePush.enable();check('Native opt-in does not use browser PushManager',e.messages[1].type==='push_enable');e.window.__titanaliIOSComplete(e.messages[1].id,{enabled:true},null);status=await push;check('Native opt-in waits for coordinator confirmation',status.enabled===true);
 push=e.window.TitanaliNativePush.disable();check('Native opt-out uses native coordinator',e.messages[2].type==='push_disable');e.window.__titanaliIOSComplete(e.messages[2].id,{enabled:false},null);status=await push;check('Native opt-out completes without leaking token or capability',status.enabled===false&&!('token' in status)&&!('capability' in status));
 console.log(JSON.stringify({passed,failed:0,checks,nativeSDKTested:false,swiftCompiled:false,physicalDeviceTested:false},null,2));
})().catch(error=>{console.error(error);process.exit(1)});
