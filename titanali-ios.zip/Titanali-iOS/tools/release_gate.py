#!/usr/bin/env python3
"""Fail closed: a development project is not a signed, reviewed IPA.
Uses only local files/public build identifiers. No uploads, credential lookup or deployment.
"""
import json,os,re,sys
from urllib.parse import urlsplit
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REQUIRED=(
 'eligiblePublisherAccountConfirmed','bundleIDAndSigningRegistered','googleIOSClientMatchesBundle',
 'nativeGoogleLoginAndFreshDeletionDeviceTested','authenticationComplianceResolved',
 'debugSimulatorBuiltAndUnitTestsPassed','physicalIPhoneAndIPadQAComplete',
 'privacyPolicyAndAppPrivacyAudited','userContentModerationReviewed',
 'screenshotsAndStoreMetadataComplete','marketDistributionRulesConfirmed',
 'packageDependenciesResolvedAndArchived','releaseExportComplianceReviewed'
)
def evaluate(checklist,env,distribution=None):
 if distribution is None:distribution=json.loads((ROOT/'docs/distribution.json').read_text())
 errors=[]
 channel=distribution.get('channel')
 if channel not in ('iapp','app-store'):errors.append('Unknown distribution channel')
 if channel=='iapp':
  if distribution.get('artifactRequested')!='native-ipa':errors.append('Publisher must confirm that iapp accepts a native IPA; PWA-only is a different deliverable')
  for key in ('publisherAuthorizationVerified','marketInstructionsReviewed'):
   if distribution.get(key) is not True:errors.append('Unconfirmed iapp requirement: '+key)
  try:
   url=urlsplit(distribution.get('marketServiceURL',''));valid_url=url.scheme=='https' and bool(url.hostname) and not url.username and not url.password
  except ValueError:valid_url=False
  if not valid_url:errors.append('Publisher-confirmed HTTPS marketplace service URL is required')
  if len(distribution.get('marketInstructionsReference',''))<20:errors.append('Current iapp instruction reference is required')
  method=distribution.get('distributionMethod','').strip()
  if not method:errors.append('Publisher must specify the authorized distribution/export method')
  if method.lower()=='enterprise':errors.append('Public customer distribution cannot use an employee-only Enterprise route')
  if len(distribution.get('distributionAuthorizationEvidence',''))<120:errors.append('Documented authorization for the actual distribution route is required')
  if type(distribution.get('embeddedProfileRequiredByPublisher')) is not bool:errors.append('Publisher must declare the embedded-profile requirement')
 for key in REQUIRED:
  if checklist.get(key) is not True:errors.append('Unfinished: '+key)
 if not re.fullmatch(r'[A-Z0-9]{10}',env.get('DEVELOPMENT_TEAM','')):errors.append('A real Apple team is not configured')
 bundle=env.get('PRODUCT_BUNDLE_IDENTIFIER','')
 if not re.fullmatch(r'[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+){2,}',bundle):errors.append('Registered bundle identifier is required')
 ios=env.get('GOOGLE_IOS_CLIENT_ID','');web=env.get('GOOGLE_WEB_CLIENT_ID','');suffix='.apps.googleusercontent.com'
 for label,value in [('iOS',ios),('web',web)]:
  if not value.endswith(suffix) or 'UNCONFIGURED' in value or '$(' in value:errors.append(label+' Google client is not configured')
 if ios==web:errors.append('Google iOS and web clients must be distinct')
 if env.get('GOOGLE_REVERSED_CLIENT_ID')!='com.googleusercontent.apps.'+ios.removesuffix(suffix):errors.append('Google return scheme does not match iOS client')
 resolution=checklist.get('authenticationResolution','')
 # This delivery has Google native code, but not Sign in with Apple. A checkbox cannot implement that feature.
 if resolution=='sign-in-with-apple':
  if not (ROOT/'Titanali/AppleAuthentication.swift').is_file() or not checklist.get('appleBackendAndRevocationTestsEvidence'):
   errors.append('Apple sign-in/server validation/revocation implementation and test evidence are absent')
 elif channel=='iapp' and resolution=='publisher-reviewed-channel':
  if len(checklist.get('nonAppStoreAuthenticationReview',''))<120:errors.append('Document current iapp/publisher authentication requirements; no App Store exception is inferred')
 elif channel=='app-store' and resolution=='documented-applicable-exception':
  if len(checklist.get('appReviewAuthenticationExceptionRationale',''))<120:errors.append('A documented applicable exception rationale is required; no exception is assumed')
 else:errors.append('Authentication compliance is unresolved for the selected channel')
 return errors
if __name__=='__main__':
 checklist=json.loads((ROOT/'docs/release-checklist.json').read_text())
 distribution=json.loads((ROOT/'docs/distribution.json').read_text())
 errors=evaluate(checklist,os.environ,distribution)
 if errors:
  print('RELEASE BLOCKED — this is an unsigned, uncompiled development source project.',file=sys.stderr)
  for error in errors:print('- '+error,file=sys.stderr)
  sys.exit(1)
 print('Local readiness gate passed; this is NOT iapp/Apple approval or proof of signing/device testing.')
