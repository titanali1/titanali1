#!/bin/sh
# Publisher-only Debug validation. No credentials, archive, uploads or automatic deployment.
set -eu
cd "$(dirname "$0")/.."
if [ "$(uname -s)" != Darwin ] || ! command -v xcodebuild >/dev/null 2>&1; then
  echo 'Mac + full Xcode required; iOS cannot be compiled/tested by this Linux environment.' >&2
  exit 1
fi
mkdir -p release-output
xcodebuild -version
xcodebuild -resolvePackageDependencies -project Titanali.xcodeproj -scheme Titanali
# Select an actually available iPhone simulator instead of inventing a model/UDID.
DEVICE_ID=$(xcrun simctl list devices available -j | /usr/bin/python3 -c 'import json,sys;d=json.load(sys.stdin);phones=[x["udid"] for runtime,items in d["devices"].items() if "iOS" in runtime for x in items if "iPhone" in x["name"] and x.get("isAvailable")];sys.exit("No iPhone simulator installed") if not phones else print(phones[0])')
RESULT="release-output/Debug-$(date +%Y%m%d-%H%M%S).xcresult"
xcodebuild -project Titanali.xcodeproj -scheme Titanali -configuration Debug \
  -destination "platform=iOS Simulator,id=$DEVICE_ID" -resultBundlePath "$RESULT" \
  -derivedDataPath release-output/DerivedData CODE_SIGNING_ALLOWED=NO test
printf '\nDebug build/test completed. Still required: physical-device QA, native auth, Apple auth compliance, signing and store review.\n'
