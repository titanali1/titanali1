import XCTest
@testable import Titanali

final class PolicyTests: XCTestCase {
    func testOriginsFailClosed() {
        for string in ["https://titanali1.ir/", "https://www.titanali1.ir/api.php", "https://titanali1.ir:443/"] {
            XCTAssertTrue(NavigationPolicy.isSite(URL(string:string)),string)
        }
        for string in ["http://titanali1.ir", "https://titanali1.ir.evil.example", "https://evil-titanali1.ir", "https://titanali1.ir:444", "https://user:password@titanali1.ir", "file:///tmp/a", "javascript:alert(1)", "https://evil.example/?https://titanali1.ir"] {
            XCTAssertFalse(NavigationPolicy.isSite(URL(string:string)),string)
        }
        XCTAssertFalse(NavigationPolicy.isSite(nil))
    }
    func testSafeNamesAndMIME() {
        let name = NavigationPolicy.filename("../../photo.exe",mime:"image/png")
        XCTAssertFalse(name.contains("/"));XCTAssertFalse(name.hasPrefix("."));XCTAssertTrue(name.hasSuffix(".png"))
        XCTAssertEqual(NavigationPolicy.filename("",mime:"application/pdf"),"titanali.pdf")
        XCTAssertLessThan(NavigationPolicy.filename(String(repeating:"a",count:600),mime:"image/jpeg").count,80)
    }
    func testImageMagicNotFilename() {
        XCTAssertTrue(NavigationPolicy.matchesImage(Data([137,80,78,71,13,10,26,10]),mime:"image/png"))
        XCTAssertTrue(NavigationPolicy.matchesImage(Data([255,216,255,1]),mime:"image/jpeg"))
        XCTAssertTrue(NavigationPolicy.matchesImage(Data("RIFF0000WEBP".utf8),mime:"image/webp"))
        XCTAssertFalse(NavigationPolicy.matchesImage(Data("<svg/>".utf8),mime:"image/png"))
        XCTAssertFalse(NavigationPolicy.matchesImage(Data(),mime:"image/png"))
    }
}
