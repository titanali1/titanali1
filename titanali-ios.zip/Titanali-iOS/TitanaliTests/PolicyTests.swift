import XCTest
@testable import Titanali

final class PolicyTests: XCTestCase {
    // Reads the ACTUAL built app Info.plist in the XCTest host; no Google login or token is mocked here.
    func testGooglePublicConfigurationAndCallbackScheme() throws {
        XCTAssertTrue(AppConfiguration.googleConfigured)
        XCTAssertEqual(AppConfiguration.googleClientID,"255964558475-151gk5kv8fqdbvv111i6edmst4ckvml2.apps.googleusercontent.com")
        XCTAssertEqual(AppConfiguration.googleServerClientID,"255964558475-9neruvlnp7a2phakdjj7uf0695ujnsae.apps.googleusercontent.com")
        XCTAssertNotEqual(AppConfiguration.googleClientID,AppConfiguration.googleServerClientID)
        XCTAssertEqual(AppConfiguration.googleScheme,"com.googleusercontent.apps." + AppConfiguration.googleClientID.replacingOccurrences(of:".apps.googleusercontent.com",with:""))
        let types = try XCTUnwrap(Bundle.main.object(forInfoDictionaryKey:"CFBundleURLTypes") as? [[String:Any]])
        let schemes = types.flatMap { $0["CFBundleURLSchemes"] as? [String] ?? [] }
        XCTAssertTrue(schemes.contains(AppConfiguration.googleScheme))
    }
    func testUnsignedPushIsDisabledByDefault() {
        // Build configuration only; no permission prompt or APNs delivery is simulated.
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey:"TANativePushEnabled") as? String,"NO")
        XCTAssertEqual(Bundle.main.object(forInfoDictionaryKey:"TAPushEnvironment") as? String,"development")
    }
    func testOriginsFailClosed() {
        for string in ["https://titanali1.ir/", "https://www.titanali1.ir/api.php", "https://titanali1.ir:443/"] {
            XCTAssertTrue(NavigationPolicy.isSite(URL(string:string)),string)
        }
        for string in ["http://titanali1.ir", "https://titanali1.ir.evil.example", "https://evil-titanali1.ir", "https://titanali1.ir:444", "https://user:password@titanali1.ir", "file:///tmp/a", "javascript:alert(1)", "https://evil.example/?https://titanali1.ir"] {
            XCTAssertFalse(NavigationPolicy.isSite(URL(string:string)),string)
        }
        XCTAssertFalse(NavigationPolicy.isSite(nil))
    }
    func testSafeNamesAndMIME() {
        let name = NavigationPolicy.filename("../../photo.exe",mime:"image/png")
        XCTAssertFalse(name.contains("/"));XCTAssertFalse(name.hasPrefix("."));XCTAssertTrue(name.hasSuffix(".png"))
        XCTAssertEqual(NavigationPolicy.filename("",mime:"application/pdf"),"titanali.pdf")
        XCTAssertLessThan(NavigationPolicy.filename(String(repeating:"a",count:600),mime:"image/jpeg").count,80)
    }
    func testImageMagicNotFilename() {
        XCTAssertTrue(NavigationPolicy.matchesImage(Data([137,80,78,71,13,10,26,10]),mime:"image/png"))
        XCTAssertTrue(NavigationPolicy.matchesImage(Data([255,216,255,1]),mime:"image/jpeg"))
        XCTAssertTrue(NavigationPolicy.matchesImage(Data("RIFF0000WEBP".utf8),mime:"image/webp"))
        XCTAssertFalse(NavigationPolicy.matchesImage(Data("<svg/>".utf8),mime:"image/png"))
        XCTAssertFalse(NavigationPolicy.matchesImage(Data(),mime:"image/png"))
    }
}
