import XCTest
@testable import Titanali

final class FileLibraryTests: XCTestCase {
    @MainActor func testOriginalBytesPersistenceAndDelete() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        let store = FileLibrary(baseDirectory:root)
        let bytes = Data(base64Encoded:"iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGO8s8mMgYGBiYGBgYGBAQAWAAHIh8BaJQAAAABJRU5ErkJggg==")!
        let temporary = try store.temporaryFile(data:bytes,name:"../original.png",mime:"image/png")
        try store.save(temporary,mime:"image/png");XCTAssertEqual(store.files.count,1)
        let saved = try XCTUnwrap(store.files.first)
        XCTAssertEqual(try Data(contentsOf:saved.url),bytes)
        try store.save(temporary,mime:"image/png");XCTAssertEqual(store.files.count,1)
        let reopened = FileLibrary(baseDirectory:root);XCTAssertEqual(reopened.files.count,1)
        XCTAssertEqual(try Data(contentsOf:try XCTUnwrap(reopened.files.first).url),bytes)
        try reopened.clear();XCTAssertEqual(reopened.files.count,0)
    }
    @MainActor func testInvalidAndOversizedExportsAreRejected() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        let store = FileLibrary(baseDirectory:root)
        XCTAssertThrowsError(try store.temporaryFile(data:Data(),name:"a",mime:"image/png"))
        XCTAssertThrowsError(try store.temporaryFile(data:Data([1]),name:"a",mime:"text/html"))
        XCTAssertThrowsError(try store.temporaryFile(data:Data(repeating:0,count:NavigationPolicy.exportLimit+1),name:"a",mime:"application/zip"))
        let fake = try store.temporaryFile(data:Data("<svg/>".utf8),name:"fake.png",mime:"image/png")
        XCTAssertThrowsError(try store.save(fake,mime:"image/png"));XCTAssertTrue(store.files.isEmpty)
    }
    @MainActor func testOfflineCountLimitDoesNotLoseFiles() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer {try? FileManager.default.removeItem(at:root)}
        let store = FileLibrary(baseDirectory:root)
        let bytes = Data(base64Encoded:"iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGO8s8mMgYGBiYGBgYGBAQAWAAHIh8BaJQAAAABJRU5ErkJggg==")!
        for _ in 0..<NavigationPolicy.offlineCount {
            let f = try store.temporaryFile(data:bytes,name:"a",mime:"image/png");try store.save(f,mime:"image/png")
        }
        let extra = try store.temporaryFile(data:bytes,name:"b",mime:"image/png")
        XCTAssertThrowsError(try store.save(extra,mime:"image/png"))
        XCTAssertEqual(store.files.count,NavigationPolicy.offlineCount)
        XCTAssertTrue(store.files.allSatisfy {(try? Data(contentsOf:$0.url)) == bytes})
    }
}
