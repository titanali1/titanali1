# Notices / rights to verify before distribution

- Owner artwork: existing private native19 `branding/logo-original.png`, unchanged except resizing to an opaque1024px RGB AppIcon. No new generated artwork. Publishing entity must hold the necessary brand/content rights.
- GoogleSignIn for iOS: official SDK repository https://github.com/google/GoogleSignIn-iOS, exact top-level tag10.0.0, Apache2.0. Resolved transitive packages, licenses, privacy manifests and SDK signatures must be audited and retained in the real Mac build. They are not vendored in this source archive and were not built here.
- Swift/SwiftUI/UIKit/WebKit/QuickLook/Authentication system presentation are platform frameworks; comply with Apple's SDK/distribution agreements.
- Local Python test tooling (not shipped in an app binary): openstep-plist, Pillow, tree-sitter and tree-sitter-swift. Versions are in tools/requirements-test.txt.
- Persian PDF guide only: Noto Naskh Arabic, SIL Open Font License1.1, original font from https://github.com/notofonts/noto-fonts . Font notice and complete license are appended to the PDF and included as Noto-OFL.txt. The font is NOT added to the application and does not alter its branding.

Official store/policy links in BUILD.md are references for the publisher to re-check, not evidence of current store approval. This archive contains no signing identity, certificate, mobileprovision, client secret or live account records.

The refreshed Persian phone guide uses Vazirmatn (SIL Open Font License1.1), https://github.com/google/fonts/tree/main/ofl/vazirmatn . The font is not bundled into the iOS app; PDF font embedding is for the guide only.
