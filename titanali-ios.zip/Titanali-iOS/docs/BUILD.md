# Selected channel: iapp / customer app / 1.0.3 (4)

See IAPP-PUBLISHER.md first. The verified target is https://iapps.ir/ and its developer form requires IPA. Acceptance of unsigned Debug input and its current signing route remain unconfirmed. The owner reports a publisher; we do not claim verified signing access. Channel-specific checks are mandatory in distribution.json. The App Store section below applies only if actually distributing through App Store; no App Store exception is assumed for iapp.

# Publisher / Mac handoff

STATUS: real Xcode iPhoneOS ARM64 Debug build and seven simulator XCTest methods PASSED. IPA is unsigned. NOT physical-device-tested, signed, submitted or approved. See cloud-build-status.json for run/commit/hash evidence.

## Toolchain
Use a supported Mac with Xcode 16+ (GoogleSignIn10 uses Swift tools6), the iOS SDK, Python3 and the then-current App Store-required SDK/Xcode. iOS deployment target16. Swift language mode5; no CocoaPods, XcodeGen, shell deployment, Github Actions or server credentials required. Open `Titanali.xcodeproj`; shared scheme `Titanali` includes a host app and seven XCTest methods. Resolve official GoogleSignIn10.0.0 via Swift Package Manager. Top-level version is exact; the actual transitive Package.resolved from the Mac build is included. Re-review resolved SDK privacy manifests before release.

## Local settings (public IDs only)
Copy `Config/Signing.local.xcconfig.sample` to `Config/Signing.local.xcconfig` and fill the commented settings with real values. The default `ir.titanali.ios` bundle identifier is proposed, NOT registered or guaranteed available. Configure the same registered identifier in the Apple team, Google iOS client and store record. The UI test target has its own identifier. Keep development/signing credentials in the publisher's local Keychain, not the project, chat, Drive or repository.

Google OAuth: create an **iOS** client, not Web/Android, with this bundle ID. Configure `GOOGLE_IOS_CLIENT_ID`, its reversed scheme `com.googleusercontent.apps.PREFIX`, and `GOOGLE_WEB_CLIENT_ID` equal to the existing server registration Web client. No client secret. The server challenge supplies a one-use nonce; the pinned SDK10 API supports `signIn(withPresenting:hint:additionalScopes:nonce:completion:)` and returns an ID token for the server audience. This actual SDK/Google behavior must be verified on a device; header/API inspection and mocked JS tests are NOT evidence of live login.

Native adapter runs at document start on exact HTTPS site origins, main frame only. It implements the limited `google.accounts.id.initialize/renderButton` contract used in web33. The native sheet uses Google's real `GIDSignInButton`. This is an adapter to the native SDK, NOT a mocked verifier: no JWT decoding/acceptance, no account minted locally. The existing web33 `google_start/google_finish` routes still own policy, one-use challenges, verification, membership, fresh confirmation deletion and account bookmarks. Cancellation, SDK failure, page changes and unknown callback IDs never create an account. SDK is signed out after each attempt; there is no refresh-token storage in app code, no silent sign-in, mailbox scope or token logging.

Future web markup/auth changes require revalidation of the adapter contract. Site HTML/JS remains a privileged part of this hybrid architecture, so review XSS/CSP and backend authentication; origin checks do not defend against a compromised first-party page.

## Local Mac validation
Run `sh tools/macos_validate.sh` (or open Xcode and build Debug/test the shared scheme). This script intentionally builds only Debug on an available iPhone simulator and saves results. It does not archive, sign, upload, install distribution profiles or contact any store for submission. A full Google/nonce/device run, not just XCTest, remains mandatory.

For a device, choose the proper team in Xcode and a connected iPhone/iPad, then Run Debug using Apple's normal signing UI. Include real Google success/cancel/blocked-account/method-policy/fresh-deletion tests, photos, microphone/camera only when explicitly chosen, original-file SHA256 comparison, offline/data protection, navigation after backgrounding/locking, limited Photos selection, keyboard, landscape, VoiceOver, large text, poor connection, popups/external URLs and file limits. See `DEVICE-QA.md`.

## App Store gate — intentionally blocked
`docs/release-checklist.json` records facts, not guesses. All fields start false. A Release build executes `tools/release_gate.py` as its first app build phase and fails while prerequisites are unresolved. Debug is available for development. Sign in with Apple is **not implemented**. For actual App Store distribution with public Google login, do not assume a 4.8 exception: implement native Apple auth plus server signature/JWKS, audience, nonce, expiry, stable identity, deletion/revocation and tests, or document a genuinely applicable exception after reviewing the current policy. Checking a box cannot implement it. The gate also requires real signing IDs, iOS Google config, simulator/device evidence, privacy and moderation audit, store materials and channel rules. It is a local workflow safeguard, not an Apple approval guarantee.

## Archive / export (after the gate passes)
Use Xcode Product > Archive, Organizer > Validate and Distribute App for the actual channel under the publisher's authorized account. Use App Store Connect/TestFlight for App Store builds, with real screenshots and a review account that has working backend content and no private owner credentials. Complete privacy, export compliance, age rating, support and policy URLs using measured behavior of the resolved app and SDKs. `ITSAppUsesNonExemptEncryption=false` is a starting value for standard OS HTTPS/SDK crypto, not a legal classification; publisher must confirm or change it.

Iranian marketplaces: obtain that service's current legitimate enrollment, signing, update, device support, fee, review and revocation rules. An App Store IPA is not a universal installable IPA. Do not use an Enterprise certificate to distribute publicly in violation of Apple's terms; no borrowed Apple ID, fake region, leaked certificate or revocation workaround. The Android dmj74 signing identity is unrelated and must remain untouched.

Official references to re-check at publication time: https://developer.apple.com/app-store/review/guidelines/ (4.2 minimum functionality, 4.8 login, 5.1.1 privacy/deletion, 1.2 user content), https://developer.apple.com/help/app-store-connect/, https://developers.google.com/identity/sign-in/ios/start-integrating and https://github.com/google/GoogleSignIn-iOS/tree/10.0.0 . These links are references, not a claim of current store approval.

## Optional cross-platform source checks (not an iOS build)
With Python3.11+ install `tools/requirements-test.txt`, then run `python3 tools/test_project.py`; with Node22+ run `node tools/test_bridge.cjs`. Swift grammar parsing is not type checking or linking. 23 project/channel/IPA-structure fixture tests, 29 mocked bridge checks and 12 actual-web33-frontend checks with mocked server/SDK are recorded in the local report; seven XCTest methods exist but were NOT run. `make_project.py` regenerates the checked-in Xcode graph/plists; customize public identifiers via the local xcconfig rather than editing generated settings, and preserve any intentional project edits when regenerating.


## WebKit launch regression
The first simulator attempt failed before tests with a missing libswiftWebKit.dylib. BrowserModel now calls the public Objective-C NS_REFINED_FOR_SWIFT entry __callAsyncJavaScript rather than the Swift-only overlay. Fixed JavaScript source, structured arguments, content world and origin restrictions remain unchanged. No missing dylib is copied into the app and iOS16 support is retained. package_unsigned.py rejects strong linkage to the missing overlay in every built Mach-O image. The corrected real device build checked three images and all six simulator tests then passed. Local regression replay rejects the first built IPA and accepts the corrected one.


## Current public OAuth IDs
Owner-provided iOS/Web IDs are now present in App.xcconfig and built Info.plist. A real native test checks them and the registered callback scheme. The post-build public server registration GET matched the Web client, with no host write. Live Google login, Console consent/type/bundle verification and physical-device QA are not completed. See docs/server-registration-check.json and cloud-build-status.json.
