# iapp customer application — publisher handoff, 1.0.3 (4)

STATUS: actual unsigned Debug iPhoneOS ARM64 IPA1.0.3 build4, Xcode16.4, seven passing XCTest methods on iOS18.5. The owner-provided public Google iOS and Web client IDs and reversed callback scheme are embedded and checked in the real built Info.plist. A post-build unauthenticated public registration GET matched the server Web client to the app and reported googleReady=true. No server configuration/data changes occurred. This does NOT verify Google Console client type/bundle/consent, a live sign-in/token exchange/deletion, physical-device QA, signing or marketplace approval. Compiled source commit: 51985eb1a9e1cc8bfef5e44096aee9b2219a9886. Evidence: https://github.com/titanali1/titanali1/actions/runs/40048325074. Treat the IPA as unsigned Debug assessment input, not a production release. No signing secrets or authenticated panel access were used. See cloud-build-status.json, server-registration-check.json and PHONE.fa.md.

## 1. Resolve the channel before signing

Complete `docs/distribution.json` using the service's actual current instructions. Record its verified HTTPS URL, instruction reference/date, accepted artifact, authorized export/distribution method and evidence of the publisher's authorization. Never put passwords, certificate/profile bytes, Apple account credentials or device UDID lists in the file. `publisherAvailableReportedByOwner=true` is NOT verification of any account or contract.

The native Release gate requires `artifactRequested=native-ipa`. If the actual service is PWA-only, stop this native route and use the existing website/PWA after testing its current behavior with that service. Do not invent a universal IPA or claim a renamed source ZIP is installable. This package does not change the website or its existing PWA branding.

Public customer distribution must comply with the actual authorized route. An employee-only Enterprise certificate is not a public-market distribution route. No borrowed credentials, leaked certificates, fake signing identities, security-disabling instructions or revocation workarounds are supplied. The method is not guessed in an ExportOptions plist; the publisher chooses the current Xcode Organizer workflow approved for the real channel.

## 2. Configure only in the publisher environment

- Mac + full Xcode 16 or newer, supported iOS SDK and Python3; use the SDK required by the channel at actual submission time. Deployment target stays iOS16. The owner-authorized GitHub build has completed; no automatic deployment exists. Build-only manual workflow remains, with no signing credentials.
- Open `Titanali.xcodeproj`, shared scheme `Titanali`. Proposed bundle `ir.titanali.ios` is NOT registered by this delivery. Match the publisher's actual registered Bundle ID across Apple team, service record and Google iOS configuration; retain any existing production identifier/version continuity.
- Copy the commented sample `Config/Signing.local.xcconfig.sample` to the ignored `Signing.local.xcconfig`, uncomment and set the PUBLIC identifiers. Fill DEVELOPMENT_TEAM and, if necessary, registered PRODUCT_BUNDLE_IDENTIFIER. Default version is 1.0.3 build4; publisher must increase it if their existing distributed version requires that.
- Configure an actual Google **iOS** OAuth client for that Bundle ID, its reversed URL scheme, and the existing website **Web** client/audience. Never replace the existing server Web client, embed Client Secret, reuse an Android OAuth client as iOS, or create/reset customer accounts.
- Resolve the pinned official GoogleSignIn10.0.0 package on the Mac. Review/archive the actual transitive Package.resolved and privacy manifests. The real Xcode build resolved and linked the graph; its Package.resolved is included. Recheck the graph/privacy at actual release time.
- Certificate keys/profiles belong in the authorized publisher's secure Keychain/build environment, not chat, source ZIP, Drive or repository. Android dmj74 signing has no role in iOS.

## 3. Build and test before checking off release readiness

Run `sh tools/macos_validate.sh` to build/test Debug on an available iPhone simulator. Debug does not require the readiness checklist to be falsely completed. Save the xcresult. Then perform `docs/DEVICE-QA.md` on real iPhone and iPad: cold launch, first run and relaunch, foreground/background, navigation, TLS/error/offline states, native Google success/cancel/failure, server nonce/audience validation, registration/method policy, fresh-confirmation deletion, private Saved, original uploads/downloads, Files/share sheet, library deletion, Photos permissions, keyboard, accessibility and orientation. Never use the owner's admin password as a review account.

The bridge was source-reviewed against web33 (`docs/web-contract.json`); live hosted deployment was not inspected. Confirm the hosted frontend/API are compatible. The server remains the authentication/authorization authority. No first-party XSS or host compromise is mitigated merely by origin checks; review the real server's CSP, access control and session policy.

The local offline library is separate from account bookmarks. User-selected originals are not re-encoded, but thumbnails are generated. Account deletion does not automatically delete copies a customer exported to Files. Audit this in policy/store disclosures and test it; no broad claim of universal deletion is made.

## 4. Channel-aware authentication and privacy review

All readiness facts default false. For this iapp route, a publisher may record `authenticationResolution=publisher-reviewed-channel` ONLY after documenting actual current channel requirements in `nonAppStoreAuthenticationReview` and completing the other review facts. This does NOT assert an App Store guideline4.8 exception. If the chosen channel requires Apple sign-in, implement and test native login plus server token verification, identity linkage, deletion and revocation before release; that implementation is not present.

If later targeting App Store, switch channel to `app-store` and separately satisfy its authentication requirements. A non-App-Store review cannot pass that gate. Do not relabel it an Apple approval. Privacy/SDK audit, account deletion, moderation appropriate to the actual private/public content, disclosures, encryption classification, screenshots from the running app and support contact remain publisher tasks.

`docs/iapp-metadata.json` is proposed customer-facing copy, not submitted/approved metadata. The original owner icon is retained exactly; choose only service-requested resizing/export without redrawing it. Do not invent runtime screenshots or acceptance badges.

## 5. Archive, inspect, verify and submit

Once actual prerequisites are complete, fill `docs/release-checklist.json` and the channel record with evidence. The first Release build phase runs `tools/release_gate.py`; missing IDs/reviews stop it. This workflow guard is not a signing authority or security boundary and cannot replace real evidence.

Archive using Xcode, validate and export with the actual authorized channel/account. Keep the xcarchive, resolved dependencies, build logs, xcresult and export configuration privately with the publisher. No store-upload command or credentials are embedded here.

For a produced IPA, `python3 tools/inspect_ipa.py FILE.ipa REGISTERED.BUNDLE VERSION BUILD` checks only archive shape, identity/version/platform, Mach-O container marker and presence of a signature envelope. It explicitly does NOT verify signing or installation and rejects traversal/duplicates/symlinks, simulator packages and renamed source ZIPs.

On the publisher's Mac, `sh tools/macos_verify_ipa.sh FILE.ipa REGISTERED.BUNDLE VERSION BUILD TEAMID1234` additionally invokes codesign verification and checks team entitlements and an embedded profile's expiry/identifier, when present/required by the declared channel. This is still NOT evidence of current online revocation status, legal distribution authority, device installation or marketplace acceptance. Perform the actual installation/update/launch through the agreed route on real devices and obtain the service's approval separately.

Deliver: signed IPA when appropriate, SHA256, exact Bundle ID/version/build, actual install/launch test evidence, auth/delete/download QA, current signing/distribution ownership and renewal responsibility, and the final approved service link. Never deliver the developer's signing private key or profile/device list to public Drive. Do not call simulator unit tests physical-device QA or mark the unsigned Debug IPA as production-ready.


## Current Google integration evidence
The exact owner-provided public IDs and derived return scheme are in Config/App.xcconfig and in the built Info.plist. Native GooglePublicConfigurationAndCallbackScheme XCTest passed. BrowserModel still rejects a server audience mismatch and requires the original server nonce before SDK invocation. The public server Web client already matches; do not replace it or change existing accounts. Console registration/consent and real sign-in/cancel/delete/device tests remain required.
